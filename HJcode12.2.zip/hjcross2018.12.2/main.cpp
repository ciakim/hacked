﻿#include "widget.h"
#include <QApplication>
#include <QPalette>
#include <QTextCodec>
#pragma execution_character_set("utf-8")

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    QApplication::addLibraryPath("./plugins");
    w.setWindowTitle("人工交叉验证软件");
    QPalette pal(w.palette());
    pal.setColor(QPalette::Background, QColor(0,69,107));
    w.setAutoFillBackground(true);
    w.setPalette(pal);
    w.show();


    return a.exec();
}
