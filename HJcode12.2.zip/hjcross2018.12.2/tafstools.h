﻿#ifndef TAFSTOOLS_H
#define TAFSTOOLS_H

#include <qt_windows.h>
#include <QFileInfoList>
#include "ShipDectResult.h"
#include "strconvert.h"
#include <string>
#include "ftpmanager.h"
#include <map>
#include "tinyxml.h"
#include <sstream>
#include <string>
#include <map>

#include <QString>
using namespace std;

class TAFSTools
{
private:
        TCHAR* szCurDir;
        string szDirectory;        //远程路径
        string lcDirectory;		   //本地路径
        FTPManager ftp;
        string panXmlFile;
        string mulXmlFile;
        string panImage;
        string mulImage;
        ShipDectResult sdr;
        StrConvert sc;
public:
        TAFSTools();
        bool Preload();
        ShipDectResult loadFiles(string path,int* tmp, bool& flag);   //图像加载
        bool setSliceInf(ShipDectResult sdr, bool mark);     //切片信息更新
        QFileInfoList findFolders(string path);
        ShipDectResult AnalysisShipDectResultXML(string xmlFile);
        string findXML(vector<string> files);
        vector<string> findImageFolder(vector<string> files,string str);
        void UpdateShipDectResultXML(char* inputFile,ShipDectResult* sdr);
        bool complete();
        bool cancelLock(string remotepath);
        void delete_dir(string path);
        char* check(const char* tmp);
        map<string,int> getSliceInf(ShipDectResult sdr);
        bool removeFolderContent(const QString folderDir);
        bool AppendRecord(ShipDectResult* sdr, string* Array,bool mark);
        bool SetNode(TiXmlElement* element, string key, string value);
        string ftoa(double value);
};

#endif // TAFSTOOLS_H
