﻿#ifndef MYLABEL_H
#define MYLABEL_H
#include <QWidget>
#include <QLabel>
#include <QPointF>
#include <QRectF>
#include <QApplication>
#include <QPainter>
#pragma execution_character_set("utf-8")

class myLabel : public QLabel
{
    Q_OBJECT

public:
    explicit myLabel(QWidget *parent = 0);
    myLabel(const QString &text, QWidget *parent=0, Qt::WindowFlags f=0);
    ~myLabel();
    void showRec();
    void cancelShowRec();
    QRectF getRec();
    QPixmap loadPixmap, capturePixmap;
    float labelWidth, labelHeight;
    float recWidth = 31;//红框的长
    float recHeight = 42;//红框的高
    float getx();
    void moveRec(double x, double y);
    void resizeRec(double x, double y);
    QPointF recPosition();
    int scaleFlag = 10;//默认是10，用来控制兴趣域放大区的缩放,只能从1放大到20
    bool isShowRec = false;

    float sRecWidth = 1;//切片框的长与高
    float sRecHeight = 1;
    void addRec(double x, double y);//每有一个切片，就增加一个框

    QPainterPath recPath;//把所有切片框出来
    QPainterPath whitePath;//空白图，用于更新

Q_SIGNALS:
    void signalCompleteCature(QPixmap catureImage);

protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
    void wheelEvent(QWheelEvent *);

private slots:
    void onWheelUp();
    void onWheelDown();
    void onTimeout();
    void onSignalDrag(QPointF dragBeginPoint, QPointF dragEndPoint, int bWidth, int type);

private:

//    QPointF leftPoint;//矩形的左上角点坐标
    QPointF beginPoint;//移动前鼠标坐标
    QPointF endPoint;//移动后鼠标坐标
    QPainterPath path;
//    qreal factorx, factory;
//    QRectF selectedRec;
    float extrax, extray;//修正后实际矩形位置和鼠标移动矩形位置之前的差异
    float increaseWidth = 12;
    float decreaseWidth = 12;
    float increaseHeight = recHeight/recWidth*increaseWidth;
    float decreaseHeight = recHeight/recWidth*decreaseWidth;
    double pastX=0;
    double pastY=0;
    double pastPathX=0;
    double pastPathY=0;
//    QPainter painter;
};



#endif // MYLABEL_H
