﻿#include "tafstools.h"
//#include "io.h"
#include <iostream>
#include <iomanip>
#include <io.h>
#include <QFile>
#include <QFileInfoList>
#include <QDebug>
#include <JlCompress.h>
#include "ShipDectResult.h"
#include "tinyxml.h"
#include <QDir>
#include <QApplication>
TAFSTools::TAFSTools(){
     szDirectory = "draft/";
     lcDirectory = "c:/sharefolder/";
}

bool TAFSTools::removeFolderContent(const QString folderDir)
{
    QDir dir(folderDir);
    QFileInfoList fileList;
    QFileInfo curFile;
    if(!dir.exists())  {return false;}//文件不存，则返回false
    fileList=dir.entryInfoList(QDir::Dirs|QDir::Files
                               |QDir::Readable|QDir::Writable
                               |QDir::Hidden|QDir::NoDotAndDotDot
                               ,QDir::Name);
    while(fileList.size()>0)
    {
        int infoNum=fileList.size();
        for(int i=infoNum-1;i>=0;i--)
        {
            curFile=fileList[i];
            if(curFile.isFile())//如果是文件，删除文件
            {
                QFile fileTemp(curFile.filePath());
                fileTemp.remove();
                fileList.removeAt(i);
            }
            if(curFile.isDir())//如果是文件夹
            {
                QDir dirTemp(curFile.filePath());
                QFileInfoList fileList1=dirTemp.entryInfoList(QDir::Dirs|QDir::Files
                                                              |QDir::Readable|QDir::Writable
                                                              |QDir::Hidden|QDir::NoDotAndDotDot
                                                              ,QDir::Name);
                if(fileList1.size()==0)//下层没有文件或文件夹
                {
                    dirTemp.rmdir(".");
                    fileList.removeAt(i);
                }
                else//下层有文件夹或文件
                {
                    for(int j=0;j<fileList1.size();j++)
                    {
                        if(!(fileList.contains(fileList1[j])))
                            fileList.append(fileList1[j]);
                    }
                }
            }
        }
    }
    return true;
}

void TAFSTools::delete_dir(string path)
{
    long hFile = 0;
    struct _finddata_t fileInfo;
    StrConvert sc;
    string pathName, exdName;
    // \\* 代表要遍历所有的类型
    if ((hFile = _findfirst(pathName.assign(path).append("*").c_str(), &fileInfo)) == -1) {
        //cout << "error no file!" << endl;
        return;
    }
    do
    {
        //判断文件的属性是文件夹还是文件
        //cout << fileInfo.name << (fileInfo.attrib&_A_SUBDIR ? "[folder]" : "[file]") << endl;
        //如果是文件夹就进入文件夹，迭代
        if (fileInfo.attrib&_A_SUBDIR) {
            {//遍历文件系统时忽略"."和".."文件
                //qDebug()<<fileInfo<<endl;
                if (strcmp(fileInfo.name, ".") != 0 && strcmp(fileInfo.name, "..") != 0) {
                    string tmp;
                    tmp = path +"/" + fileInfo.name;
                    delete_dir(tmp);

                    LPCWSTR cc = sc.CharToLPCWSTR(sc.ConstToChar(tmp.c_str()));

                    //sc.CharToLPCWSTR(sc.ConstToChar(tmp.c_str()));
                    RemoveDirectory(cc);
                }
            }

        }
        //是文件的话就查看文件名，不是“back1.bmp”就删除
        else {
            //delete file
            if (strcmp(fileInfo.name, ".") != 0 && strcmp(fileInfo.name, "..") != 0) {
                if (strcmp(fileInfo.name, "back1.bmp")) {
                    string delpath = path + "/" + fileInfo.name;
                    if (remove(delpath.c_str()) != 0)//删除失败就报错
                        perror("Error deleting file");
                    else {
                        //cout << fileInfo.name << "deleted" << endl;
                    }
                }
            }
        }
    } while (_findnext(hFile, &fileInfo) == 0);
    _findclose(hFile);
    return;
}

QFileInfoList TAFSTools::findFolders(string path){
    QDir dir(QString::fromStdString(path));
    QFileInfoList folder_list = dir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);

    return folder_list;
}

vector<string> TAFSTools::findImageFolder(vector<string> files,string str){
    vector<string> tmp;
    for(int i=0; i<files.size(); i++){
        string filename = files[i];
        if(filename.find("PMS") < filename.size() && filename.find(str.c_str()) < filename.size()){
            tmp.push_back(filename);
        }
    }
    return tmp;
}

bool TAFSTools::Preload(){

    bool mark = ftp.Connection();
    if(!mark) return mark;

    string xmlpath = "c:\\CrossValidation\\";

    string mulName = "multispectral\\";

    string panName = "panchromatic\\";

    vector<string> files = ftp.getRemoteDirections("result");

    vector<string> mulFiles = findImageFolder(files,"MSS");

    vector<string> mssFiles = findImageFolder(files,"MUX");

    mulFiles.insert(mulFiles.end(),mssFiles.begin(),mssFiles.end());

    vector<string> panFiles = findImageFolder(files,"PAN");
    //多光谱图像
    QFileInfoList folder = findFolders(xmlpath + mulName);

    int counter = 0;
    for(int i=0; i<mulFiles.size(); i++){
        counter = 0;
        for(int j=0; j<folder.size(); j++){
            string s = folder.at(j).fileName().toStdString();
            if(mulFiles[i] == s)
                break;
            counter++;
            QApplication::processEvents();
        }
        if(counter == folder.size()){
            string s = xmlpath + mulName + mulFiles[i];
            QDir dir;
            dir.mkdir(QString::fromStdString(s));
        }
        QApplication::processEvents();
    }

    for(int i=0; i<folder.size(); i++){
        counter = 0;
        string s = folder.at(i).fileName().toStdString();
        for(int j=0; j<mulFiles.size(); j++){
            if(s == mulFiles[j])
                break;
            counter++;
            QApplication::processEvents();
        }
        if(counter == mulFiles.size()){
            QDir dir(QString::fromStdString(xmlpath+mulName));
            dir.rmdir(QString::fromStdString(s));
        }
        QApplication::processEvents();
    }
    //全色图像
    folder = findFolders(xmlpath + panName);

    counter = 0;
    for(int i=0; i<panFiles.size(); i++){
        counter = 0;
        for(int j=0; j<folder.size(); j++){
            string s = folder.at(j).fileName().toStdString();
            if(panFiles[i] == s)
                break;
            counter++;
        }
        if(counter == folder.size()){
            string s = xmlpath + panName + panFiles[i];
            QDir dir(QString::fromStdString(s));
            dir.mkdir(QString::fromStdString(s));
        }
    }
    QApplication::processEvents();

    for(int i=0; i<folder.size(); i++){
        counter = 0;
        string s = folder.at(i).fileName().toStdString();
        for(int j=0; j<panFiles.size(); j++){
            if(s == panFiles[j])
                break;
            counter++;
            QApplication::processEvents();
        }
        if(counter == panFiles.size()){      
            QDir dir(QString::fromStdString(xmlpath+panName));
            dir.rmdir(QString::fromStdString(s));
        }
        QApplication::processEvents();
    }
}

string TAFSTools::findXML(vector<string> files){
    int size = (int)files.size();
    for(int i=0; i<size; i++){
        if(files[i].find("xml") != -1){
            return files[i];
        }
    }
    return "";
}

char* TAFSTools::check(const char* tmp){

    char* index = new char[255];
    index[0] = '\0';
    if(!tmp)
        return index;
    strcpy_s(index,255,tmp);
    return index;
}

ShipDectResult TAFSTools::AnalysisShipDectResultXML(string xmlFile){
    try
    {
        TiXmlDocument *myDocument = new TiXmlDocument(xmlFile.c_str());
        myDocument->LoadFile(TIXML_ENCODING_UTF8);
        TiXmlElement *rootElm= myDocument ->RootElement();

        TiXmlElement* BaseInfo =rootElm->FirstChildElement("BaseInfo");
        TiXmlElement* result = rootElm->FirstChildElement("result");

        TiXmlAttribute * pAttr = rootElm->FirstAttribute();
        if(pAttr->Value())
            sdr.setSatellite(sc.ConstToChar(pAttr->Value()));
        pAttr = pAttr->Next();
        if(pAttr->Value()){
            string s = pAttr->Value();
            sdr.setImagingtime(sc.ConstToChar(s.c_str()));
        }
        pAttr = pAttr->Next();
        if(pAttr->Value())
            sdr.setResolution(sc.ConstToChar(pAttr->Value()));
        pAttr = BaseInfo->FirstAttribute();
        sdr.setName(sc.ConstToChar(pAttr->Value()));
        pAttr = pAttr->Next();
        sdr.setID(sc.ConstToChar(pAttr->Value()));
        pAttr = pAttr->Next();
        sdr.setDescription(sc.ConstToChar(pAttr->Value()));

        int DetectNumber = atoi(result->FirstChildElement("DetectNumber")->GetText());
        sdr.setDetectNumber(DetectNumber);
        int blockNumber = atoi(result->FirstChildElement("BlockNumber")->GetText());
        sdr.setBlockNumber(blockNumber);
        ShipSlic* slices = new ShipSlic[2*DetectNumber+20];

        TiXmlElement* Element = result->FirstChildElement("DetectResult");
        for(int i=0; i<DetectNumber; i++){
            slices[i].setResultID(check(Element->FirstChildElement("ResultID")->GetText()));
            slices[i].setBlockOrder(atoi(Element->FirstChildElement("BlockOrder")->GetText()));
            slices[i].setLocation(check(Element->FirstChildElement("Location")->GetText()));
            slices[i].setCenterLonLat(check(Element->FirstChildElement("CenterLonLat")->GetText()));
            slices[i].setLength(atof(check(Element->FirstChildElement("Length")->GetText())));
            slices[i].setWidth(atof(check(Element->FirstChildElement("Width")->GetText())));
            slices[i].setArea(atof(check(Element->FirstChildElement("Area")->GetText())));
            slices[i].setAngle(atof(check(Element->FirstChildElement("Angle")->GetText())));
            slices[i].setProbability(atof(check(Element->FirstChildElement("Probability")->GetText())));
            slices[i].setResultImagePath(check(Element->FirstChildElement("ResultImagePath")->GetText()));
            slices[i].setValidationName(check(Element->FirstChildElement("ValidationName")->GetText()));
            TiXmlElement* shape = Element->FirstChildElement("Shape");
            TiXmlElement* point = shape->FirstChildElement("Point");
            slices[i].setLefttop(point->GetText());
            point = point->NextSiblingElement("Point");
            slices[i].setRighttop(point->GetText());
            point = point->NextSiblingElement("Point");
            slices[i].setRightbottom(point->GetText());
            point = point->NextSiblingElement("Point");
            slices[i].setLeftbottom(point->GetText());

            string s = Element->FirstChildElement("TopLeft")->GetText();
            int index = s.find(",");
            slices[i].setTopLeftX(atof(s.substr(0, index).c_str()));
            slices[i].setTopLeftY(atof(s.substr(index+1).c_str()));

            s = Element->FirstChildElement("BottomRight")->GetText();
            index = s.find(",");
            slices[i].setBottomRightX(atof(s.substr(0, index).c_str()));
            slices[i].setBottomRightY(atof(s.substr(index+1).c_str()));

            PossibleResults* pr = new PossibleResults();

            TiXmlElement* possibility = Element->FirstChildElement("PossibleResults");
            pr->setType(check(possibility->FirstChildElement("Type")->GetText()));
            if(possibility->FirstChildElement("Reliability")->GetText())
                pr->setReliability(atof(possibility->FirstChildElement("Reliability")->GetText()));
            else
                pr->setReliability(0);
            slices[i].setPR(*pr);
            Element = Element->NextSiblingElement("DetectResult");
        }
        sdr.setSlices(slices);
    }
    catch (string e){
    }
    return sdr;
}

ShipDectResult TAFSTools::loadFiles(string path,int* tmp, bool& flag){
    ShipDectResult sdr;
    bool mark = ftp.Connection();

    if(!mark) {
        flag = false;
        return sdr;
    }

    if(path.find("PAN") < path.size()){
        mark = true;
        panImage = path;
    }else{
        mark = false;
        mulImage = path;
    }
    tmp[0] = 1;
    string localpath = lcDirectory,xmlFile;

    vector<string> files = ftp.getRemoteFilename(path);

    for(int i=0; i<files.size(); i++){
           if(files[i] == "lock"){
               tmp[0] = 0;
               return sdr;
           }
    }
    //这一部分是不是只需要在本地添加lock锁就可以
    QString index = QString::fromStdString(lcDirectory + "lock");
    QFile file(index);
    file.open(QIODevice::WriteOnly);
    file.close();
    vector<string> lock;
    lock.push_back("lock");
    ftp.uploadFile(lock,"result/" + path, localpath);

    xmlFile = findXML(files);
    if(mark)
        panXmlFile = xmlFile;
    else
        mulXmlFile = xmlFile;
    files.clear();
    files.push_back(xmlFile);
    ftp.downloadFile(files, path);
    QApplication::processEvents();

    vector<string> slicefiles = ftp.getRemoteFilename(path+"slices/");

    ftp.downloadFile(slicefiles, path+"slices/");
    QApplication::processEvents();

    for(int i=0; i<slicefiles.size(); i++){
        string tmpfile = localpath + path + "slices/" + slicefiles[i];
        string tmpdir = localpath + path + "slices/";
        JlCompress::extractDir(tmpfile.c_str(), tmpdir.c_str());
        remove(tmpfile.c_str());
        QApplication::processEvents();
    }

    if(xmlFile != ""){
        string a =lcDirectory + path + xmlFile;
        cout<<lcDirectory + path + "/" + xmlFile<<endl;
        sdr = AnalysisShipDectResultXML(lcDirectory + path + "/" + xmlFile);
    }
    QApplication::processEvents();
    return sdr;
}

bool TAFSTools::cancelLock(string remotepath){

    vector<string> files;
    files.push_back("lock");
    bool mark = ftp.removeFile(files, remotepath);
    return mark;

}

void TAFSTools::UpdateShipDectResultXML(char* inputFile,ShipDectResult* sdr){
    //把sdr中的内容重新写入到xml文件中

    TiXmlDocument *pDoc = new TiXmlDocument();
    if (NULL==pDoc)
    {
        return;
    }

    pDoc->LoadFile(inputFile);

    TiXmlElement* pRootElement = pDoc->RootElement();

    ShipSlic* slices = sdr->getSlices();
    int size = sdr->getDetectNumber();

    TiXmlElement* result = pRootElement->FirstChildElement("result");

    TiXmlElement* DetectResult = result->FirstChildElement("DetectResult");

    for(int i=0; i<size; i++){
        DetectResult->RemoveChild(DetectResult->FirstChildElement("Probability"));
        TiXmlElement* Probability = new TiXmlElement("Probability");
        Probability->LinkEndChild(new TiXmlText(sc.DoubleToStr(slices[i].getProbability()).c_str()));
        DetectResult->LinkEndChild(Probability);
        DetectResult = DetectResult->NextSiblingElement("DetectResult");
    }

    pDoc->SaveFile(inputFile);
}

bool TAFSTools::setSliceInf(ShipDectResult sdr, bool mark){   //path上传文件的远程共享文件夹，filename,
    //修改切片的名称加入了虚警信息
    StrConvert sc;
    string path = mark ? lcDirectory + "/" + panImage + "/" + panXmlFile:lcDirectory + "/" + mulImage + "/" + mulXmlFile;
    UpdateShipDectResultXML(sc.ConstToChar(path.c_str()),&sdr);
    return true;
}

map<string,int> TAFSTools::getSliceInf(ShipDectResult sdr){

    map<string,int> Map;
    ShipSlic* slices = sdr.getSlices();
    for(int i=0; i<sdr.getDetectNumber(); i++){
        Map[slices[i].getValidationName()] = i;
    }
    return Map;
}

bool TAFSTools::complete(){
    bool mark = ftp.Connection();
    if(!mark) return mark;
    string localpath, remotepath;
    vector<string> files;
    if(mulImage.size() > 3){
        localpath = lcDirectory + mulImage;
        remotepath = mulImage ;
        files.push_back(mulXmlFile);
        ftp.uploadFile(files, "result/" + remotepath,localpath);
    }
    if(panImage.size() > 3){
        files.clear();
        localpath = lcDirectory + panImage;
        remotepath = panImage;
        files.push_back(panXmlFile);
        qDebug()<<QString::fromStdString(remotepath)<<"       "<<QString::fromStdString(localpath)<<"      "<<QString::fromStdString(panXmlFile)<<endl;
        ftp.uploadFile(files, "result/" + remotepath,localpath);
    }
    return true;
}

string TAFSTools::ftoa(double value){
    stringstream ss;
    string str;

    ss << fixed << setprecision(6)<<value;
    ss >> str;
    return str;
}


bool TAFSTools::SetNode(TiXmlElement* element, string key, string value){
    TiXmlElement* keyElement = new TiXmlElement(key.c_str());
    keyElement->LinkEndChild(new TiXmlText(value.c_str()));
    element->LinkEndChild(keyElement);
    return true;
}


bool TAFSTools::AppendRecord(ShipDectResult* sdr, string* Array,bool mark){
    ShipSlic slice;
    string center = Array[4];
    slice.setLefttop(Array[0].replace(Array[0].find("_"), 1, ", "));
    slice.setLeftbottom(Array[1].replace(Array[1].find("_"), 1, ", "));
    slice.setRighttop(Array[2].replace(Array[2].find("_"), 1, ", "));
    slice.setRightbottom(Array[3].replace(Array[3].find("_"), 1, ", "));
    slice.setCenterLonLat(Array[4].replace(Array[4].find("_"), 1, ", "));
    char buffer[20];
    itoa(sdr->getDetectNumber()+1, buffer,10);
    string index = buffer;
    slice.setResultID(index);
    slice.setProbability(1);
    slice.setValidationName(center + ".tiff");
    ShipSlic* slices = sdr->getSlices();
    slices[sdr->getDetectNumber()] = slice;
    sdr->setSlices(slices);
    sdr->setDetectNumber(sdr->getDetectNumber()+1);

    //将切片信息添加至xml中
    TiXmlDocument *pDoc = new TiXmlDocument();
    if (NULL==pDoc){
        return false;
    }

    string xml = mark?lcDirectory + panImage + panXmlFile:lcDirectory + mulImage + mulXmlFile;
    pDoc->LoadFile(xml.c_str());

    TiXmlElement* pRootElement = pDoc->RootElement();

    TiXmlElement* result = pRootElement->FirstChildElement("result");
    TiXmlElement* DetectResult = new TiXmlElement("DetectResult");
    TiXmlElement* DetectNumber = result->FirstChildElement("DetectNumber");
    DetectNumber->Clear();
    itoa(sdr->getDetectNumber(), buffer,10);
    index = buffer;
    DetectNumber->LinkEndChild(new TiXmlText(index.c_str()));
    SetNode(DetectResult, "ResultID", slice.getResultID());
    TiXmlElement* shape = new TiXmlElement("Shape");
    SetNode(shape, "Point", slice.getLefttop());
    SetNode(shape, "Point", slice.getRighttop());
    SetNode(shape, "Point", slice.getRightbottom());
    SetNode(shape, "Point", slice.getLeftbottom());
    DetectResult->LinkEndChild(shape);
    SetNode(DetectResult, "Location", "NoKnown");
    SetNode(DetectResult, "TopLeft", Array[5]);
    SetNode(DetectResult, "BottomRight", Array[6]);
    SetNode(DetectResult, "BlockOrder", Array[7]);
    SetNode(DetectResult, "CenterLonLat", slice.getCenterLonLat());
    SetNode(DetectResult, "Length", "0.0");
    SetNode(DetectResult, "Width", "0.0");
    SetNode(DetectResult, "Area", "0.0");
    SetNode(DetectResult, "Angle", "0.0");
    SetNode(DetectResult, "Probability", "1");
    SetNode(DetectResult, "ResultImagePath", "1");    //填写绝对路径还是相对路径
    SetNode(DetectResult, "ValidationName", slice.getValidationName());
    TiXmlElement* PossibleResults = new TiXmlElement("PossibleResults");
    SetNode(PossibleResults, "Type", "");
    SetNode(PossibleResults, "Reliability", "0");
    DetectResult->LinkEndChild(PossibleResults);
    result->LinkEndChild(DetectResult);

    pDoc->SaveFile(xml.c_str());
    return true;
}
