﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QListWidget>
#include <QApplication>
#include <QEventLoop>
#include <iostream>
#include <QLibrary>
#include "gdal_priv.h"
#include "proj_api.h"
//#include "ogr_srs_api.h"
#include "ogr_spatialref.h"
#include "TAFSTools.h"
#include <JlCompress.h>
#include <QCloseEvent>
#include <math.h>
#pragma execution_character_set("utf-8")
//#include "ftpmanager.h"
using namespace std;

typedef unsigned short ushort;
typedef unsigned char uchar;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    void closeEvent(QCloseEvent *event);
    ~Widget();
    void showPic1(QString fileName);
    void showTable(ShipSlic *slices);
    void listSlice(string shipname, string centerlonlat, string lefttop, string leftbottom, string righttop, string rightbottom);
    void listSlicePic(QString fileName);
    void readMark(QString fileName);
    void writeMark(QString fileName);
    void rewriteMark(QString fileName);
    void forbidUI();
    void cancelForbidUI();
    TAFSTools tools;
    ShipDectResult sdr;
    ShipSlic *slices;
    string lockFileName;
    OGRSpatialReference fRef, tRef;
    int nXSize, nYSize;
    OGRCoordinateTransformation *coordTrans;
    OGRCoordinateTransformation *coordTransInverse;//经纬度坐标转换为平面坐标
    QImage imgAll;
    double topw, bottomw, leftj, rightj;//获得图片经纬度
    double mouseJ, mouseW; //获得鼠标经纬度
    double picWidth, picHeight;
    double adfGeoTransform[6];
    double dTemp;//用于经纬度变坐标
    //double getPixels(double &jnum,double &wnum);//根据经纬度获得在原图中的像素位置
    double getPosX(double jnum,double wnum);//根据切片经纬度在缩略图中定位
    double getPosY(double jnum,double wnum);
    double getSPosX(double jnum,double wnum);//根据切片经纬度在缩略图中定位小框
    double getSPosY(double jnum,double wnum);
    double getPixel(double pixel);//根据像素位置得到在缩略图中的位置
    double getRecPosX(double jnum,double wnum);//根据切片经纬度在方框图中定位（获取的是中心点位置）
    double getRecPosY(double jnum,double wnum);
    double getRecLength(double lenght);//根据像素点获得在方框图中的位置&长度
    void getMouseJ(double mouseX);//根据鼠标位置获取该位置经纬度
    void getMouseW(double mouseY);
    double getJ(double x);//任意的坐标来算在原图中的像素点，这里是用于新增切片的
    double getW(double y);
    QString sliceFolder;//用来记录切片应该被保存的文件夹

    void addListItem(QPixmap captureImage, QString fileName);
    void loadNewSlice(QPixmap capturePixmap, QString fileName);
    string doubleToString(double num);

    int type = 0;//设置当前状态，为0时在下载，为1时在提交，为2时在制图
    map<string, int> Map;//标注数组，为1时表示是船，背景为白色，为0时表示是虚警，背景为海蓝
    int* tmp = new int[1];//tmp[1]=3,已经有任务打开，需要关闭；为0，该任务有锁；为2，该任务已经被下载；默认为1
    void readPic(const char* srcfile);
    void Piecewise_linear_16to8(const char *inFilename, const char *dstFilename);

    QString folder;//记录文件所在的文件夹

    QImage baseImage;//原始图像，也是背景图
    QImage recImage;//标志着船的方框图，也是覆盖图
    QImage whiteImage;//一块用来用画方框的白画布
    void AddRec();//把整个加方框的过程单独写一个函数
    void addRecInSmall();//在缩略图中加方框
    void addRecInBig();//在兴趣域放大区中加方框
    void reCalcul();//重新计算缩略图中的数值以便画框
    void drawRecImage(int x, int y, int width, int height);//给recImage添加方框,注意这里的xy是中心点坐标
    void createImageWithOverlay(QImage underImage, QImage overlayImage);//将两张图重叠显示

    //由谢师姐侯师姐提供的像素点进行换算
    double blockHeight;//每一个分块的高度
    double deviation;//每一个分块重叠的像素
    int blockNumber;//每一张图片里分块的个数
    double blockY2allY(int i);//由分块时的像素点Y坐标得到全图时的像素点Y坐标
    double allY2BlockY(double y);//由全图时的像素点Y坐标得到分块时的像素点Y坐标

    double recInfo[10000][10];
    int threadId;
    void addRecInPic1(double x, double y);
    static void AddRecInThread(Widget *_widget);


private slots:
    void onCompleteCature(QPixmap captureImage);
    void onMouseMove(QPointF mousePoint);//跟踪鼠标在兴趣域放大区中的位置，根据位置在界面上显示经纬度
    void onSliceCapture(QPixmap catureImage, QPointF topLeft, QPointF bottomRight);//确定了要增加的切片后要执行的操作
    void on_dkBtn_clicked();
    void on_ztBtn_clicked();
    void on_tjBtn_clicked();
    void on_gbBtn_clicked();
    void on_zjBtn_clicked();
    void slotTimeout();

protected:
    void paintEvent(QPaintEvent *);

private:
    Ui::Widget *ui;

public slots:
    void slotItemDoubleClicked(QListWidgetItem *item);
    void slotItemClicked(QListWidgetItem *item);
};

#endif // WIDGET_H
