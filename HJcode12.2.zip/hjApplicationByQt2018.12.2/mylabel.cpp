﻿#include "mylabel.h"
#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <qDebug>
#include <QRectF>
#include <QPixmap>
#include <QTimer>

myLabel::myLabel(QWidget *parent):
    QLabel(parent)
{
    beginPoint.setX(0);
    beginPoint.setY(0);
    endPoint.setX(0);
    endPoint.setY(0);
//    path.moveTo(50,50);
//    path.lineTo(100,200);
//    selectedRec = QRectF(100,100,200,200);
    path.addRect(QRectF(0,0,recWidth,recHeight));
//    path.addRect(100,100,200,200);//画矩形
//    painter.drawPath(path);
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(onTimeout()));
    timer->start(1000);
}

myLabel::myLabel(const QString &text, QWidget *parent, Qt::WindowFlags f):QLabel(text,parent,f)
{

}

myLabel::~myLabel()
{

}

void myLabel::onTimeout()
{
    this->repaint();
}

void myLabel::paintEvent(QPaintEvent *event)
{
    QLabel::paintEvent(event);//先调用父类的paintEvent为了显示'背景'!!!
//    painter.begin(this);
//    painter.drawPixmap(0,0,loadPixmap);
    if(!isShowRec)
    {
//        //qDebug()<<"oops!";
        return;
    }
    QPainter painter(this);
    painter.setPen(QPen(QColor(0,69,107),2));
    QPointF s_topLeft = getRec().topLeft();
    QPointF s_bottomRight = getRec().bottomRight();//在小图里矩形所在的位置
//    //qDebug()<<"s_topLeft："<<s_topLeft;
//    //qDebug()<<"path："<<path.currentPosition();
    painter.drawPath(path);
    path.translate(endPoint.x()-beginPoint.x()+extrax,endPoint.y()-beginPoint.y()+extray);//移动(可理解为向量移动)
    beginPoint = endPoint;
//    //qDebug()<<"beginPoint: "<<beginPoint<<"  endPoint:"<<endPoint;
//    if(selectedRec.isNull())//qDebug("selectedRec isNull");
    //在大图里矩形所在的位置
    QPointF b_topLeft = QPointF(s_topLeft.x()/labelWidth*loadPixmap.width(), s_topLeft.y()/labelHeight*loadPixmap.height());
    QPointF b_bottomRight = QPointF(s_bottomRight.x()/labelWidth*loadPixmap.width(), s_bottomRight.y()/labelHeight*loadPixmap.height());
//    //qDebug()<<"s_topLeft.x(): "<<s_topLeft.x()<<"  labelWidth: "<<labelWidth<<"  loadPixmap.width(): "<<loadPixmap.width();
//    //qDebug()<<"s_topLeft.x()/labelWidth*loadPixmap.width():"<<s_topLeft.x()/labelWidth*loadPixmap.width();
    QRect selectedRec = QRectF(b_topLeft, b_bottomRight).toRect();
    capturePixmap = loadPixmap.copy(selectedRec);
    signalCompleteCature(capturePixmap);
//    if(capturePixmap.isNull())//qDebug("isNull");
    painter.setPen(QPen(QColor(0,107,22),1));
    painter.drawPath(recPath);
    painter.end();
}

QRectF myLabel::getRec()
{
    float x = path.currentPosition().x();
    float y = path.currentPosition().y();
    qDebug()<<"原来的x: "<<x<<" 原来的y: "<<y;
    qDebug()<<"recWidth: "<<recWidth<<" recHeight: "<<recHeight;
    //判断有没有越左界
    x = path.currentPosition().x()<0? 0:x;
    y = path.currentPosition().y()<0? 0:y;
    //判断有没有越右界
    x = (path.currentPosition().x()+recWidth)>labelWidth? (labelWidth-recWidth):x;
    y = (path.currentPosition().y()+recHeight)>labelHeight? (labelHeight-recHeight):y;
    qDebug()<<"x: "<<x<<" y: "<<y;
    qDebug()<<"labelWidth: "<<labelWidth<<" labelHeight: "<<labelHeight;
    qDebug()<<"path.currentPosition: "<<path.currentPosition();
    extrax = x - path.currentPosition().x();
    extray = y - path.currentPosition().y();
//    //qDebug()<<"extrax: "<<extrax<<" extray: "<<extray;
    QRectF selectedRec = QRectF(x, y, recWidth, recHeight);
//    if (selectedRec.width() == 0)
//    {
//        selectedRec.setWidth(1);
//    }
//    if (selectedRec.height() == 0)
//    {
//        selectedRec.setHeight(1);
//    }
    return selectedRec;
}

void myLabel::showRec()
{
    isShowRec = true;
}

void myLabel::cancelShowRec()
{
    isShowRec = false;
}

void myLabel::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        beginPoint = event->pos();
        endPoint = beginPoint;
    }
}

void myLabel::mouseMoveEvent(QMouseEvent *event)
{
    if(event->buttons() == Qt::LeftButton)
    {
        endPoint = event->pos();
//        //qDebug()<<"move: "<<endPoint.x();
//        if(endPoint.x()<0)
//        endPoint.setX(endPoint.x()<0?0:endPoint.x());
        update();//拖动时有痕迹
    }
}

void myLabel::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        endPoint = event->pos();
//        //qDebug()<<"release: "<<endPoint.x();
        update();
    }
}

void myLabel::moveRec(double x, double y)
{
    beginPoint = path.currentPosition();
    endPoint = QPointF(x,y);
//    //qDebug()<<"beginPoint: "<<beginPoint << "   endPoint:" <<endPoint;
    repaint();
    repaint();
}

void myLabel::addRec(double x, double y)
{
    recPath.addRect(QRectF(x,y,sRecWidth,sRecHeight));
    repaint();
}

void myLabel::resizeRec(double x, double y)
{
    path = QPainterPath();
    path.addRect(QRectF(x,y,recWidth,recHeight));
    //qDebug()<<path.currentPosition();
//    //qDebug()<<"beginPoint: "<<beginPoint << "   endPoint:" <<endPoint;
    repaint();
}

QPointF myLabel::recPosition()
{
    return path.currentPosition();
}

void myLabel::onWheelDown()
{
//    if(scaleFlag>=20)
//        return;

    if( recHeight+increaseHeight>=labelHeight || recWidth+increaseWidth>=labelWidth)
        return;
    increaseHeight = recHeight/recWidth*increaseWidth;
    scaleFlag += 1;
    double tmpRecHeight = recHeight;
    double tmpRecWidth = recWidth;
    recHeight += increaseHeight;
    recWidth += increaseWidth;
    recHeight = (recHeight>=labelHeight)? labelHeight : recHeight;
    recWidth = (recWidth>=labelWidth)? labelWidth : recWidth;
    double tmpX = path.currentPosition().x() - (recWidth - tmpRecWidth)/2;
    double tmpY = path.currentPosition().y() - (recHeight - tmpRecHeight)/2;
    //qDebug()<<"tmpX: "<<tmpX << "tmpY: "<<tmpY;
    resizeRec(tmpX, tmpY);
    //qDebug()<<path.currentPosition();
}

void myLabel::onWheelUp()
{
//    if(scaleFlag<=1)
//        return;
    //qDebug()<<"recHeight: "<<recHeight << "    recWidth:"<<recWidth;
    if(recHeight-decreaseHeight<=2 || recWidth-decreaseWidth<=2)
        return;
    scaleFlag -= 1;
    decreaseHeight = recHeight/recWidth*decreaseWidth;
    double tmpRecHeight = recHeight;
    double tmpRecWidth = recWidth;
    recHeight -= decreaseHeight;
    recWidth -= decreaseWidth;
    recHeight = (recHeight<=2)? 2 : recHeight;
    recWidth = (recWidth<=2)? 2 : recWidth;
    double tmpX = path.currentPosition().x() + (tmpRecWidth - recWidth)/2;
    double tmpY = path.currentPosition().y() + (tmpRecHeight - recHeight)/2;
    resizeRec(tmpX,tmpY);
    //qDebug()<<path.currentPosition();
}

void myLabel::wheelEvent(QWheelEvent *event)
{
    if(event->delta()>0)//如果滚轮往上滚
    {
        onWheelUp();
    }
    else
    {
        onWheelDown();
    }
}

void myLabel::onSignalDrag(QPointF dragBeginPoint, QPointF dragEndPoint, int bWidth, int type)
{
//    qDebug()<<"拖动信号"<<"   dragBeginPoint:"<<dragBeginPoint <<"   dragEndPoint:"<< dragEndPoint;
    if(type == 1)
    {
        pastX = dragBeginPoint.x();
        pastY = dragBeginPoint.y();
        pastPathX = path.currentPosition().x();
        pastPathY = path.currentPosition().y();
    }
//    qDebug()<<"   pastX:"<<pastX <<"   pastY:"<< pastY;
//    qDebug()<<"   pastPathX:"<<pastPathX <<"   pastPathY:"<< pastPathY;
    double bDragWidth = dragEndPoint.x() - pastX;//放大区里鼠标拖动的宽度
    double bDragHeight = dragEndPoint.y() - pastY;//放大区里鼠标拖动的高度
//    qDebug()<<"   bDragWidth:"<<bDragWidth <<"   bDragHeight:"<< bDragHeight;
    if(bDragHeight==0 && bDragWidth==0)
        return;
    double ratio = recWidth / bWidth;//缩略图和放大区的比例关系
    //接下来将放大区中鼠标拖动的距离换算到缩略图中
    double dragWidth = bDragWidth * ratio;
    double dragHeight = bDragHeight *ratio;\
//    qDebug()<<"   dragWidth:"<<dragWidth <<"   dragHeight:"<< dragHeight;
    //算现在矩形应该在的位置
    double x = pastPathX - dragWidth;
    double y = pastPathY - dragHeight;
    //移动矩形
    moveRec(x,y);
//    qDebug()<<"   x:"<<x <<"   y:"<< y;

}
