﻿#ifndef NoticeXML_H
#define NoticeXML_H

#include<string>

using namespace std;

class NoticeXML{
	private:
		string inputImage;
		string satelliteName;
		string sensorName;
		string imagingTime;
		string targetID;
		string targetName;
		double longitude;
		double latitude;
		string detXml;
	public:
		
		string getInputImage(){
			return this->inputImage;
		}

		void setInputImage(string inputImage){
			this->inputImage = inputImage;
		}

		string getSatelliteName(){
			return this->satelliteName;
		}

		void setSatelliteName(string satelliteName){
			this->satelliteName = satelliteName;
		}

		string getSensorName(){
			return this->sensorName;
		}

		void setSensorName(string sensorName){
			this->sensorName = sensorName;
		}

		string getImagingTime(){
			return this->imagingTime;
		}

		void setImagingTime(string imagingTime){
			this->imagingTime = imagingTime;
		}

		string getTargetID(){
			return this->targetID;
		}

		void setTargetID(string targetID){
			this->targetID = targetID;
		}

		string getTargetName(){
			return this->targetName;
		}

		void setTargetName(string targetName){
			this->targetName = targetName;
		}

		double getLongitude(){
			return this->longitude;
		}

		void setLongitude(double longitude){
			this->longitude = longitude;
		}

		double getLatitude(){
			return this->latitude;
		}

		void setLatitude(double latitude){
			this->latitude = latitude;
		}

		string getDetXml(){
			return this->detXml;
		}

		void setDetXml(string detXml){
			this->detXml = detXml;
		}
	
		string getword(string word){
				StrConvert sc;
				if(word == "InputImage")
					return this->inputImage;
				if(word == "SatelliteName")
					return this->satelliteName;
				if(word == "SensorName")				
					return this->sensorName;
				if(word == "ImagingTime")		
					return this->imagingTime;
				if(word == "TargetID")	
					return this->targetID;
				if(word == "TargetName")	
					return this->targetName;
				if(word == "Longitude")	
					return sc.DoubleToStr(this->longitude);
				if(word == "Latitude")	
					return sc.DoubleToStr(this->latitude);
				if(word == "DetXml")	
					return this->detXml;
			return "";
		}
};
#endif
