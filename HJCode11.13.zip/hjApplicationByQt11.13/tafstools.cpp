﻿#include "tafstools.h"
#include <iostream>
#include <iomanip>
#include <io.h>
#include <QApplication>
#include <QFile>
#include <QFileInfoList>
#include <JlCompress.h>
#include "ShipDectResult.h"
#include "NoticeXML.h"
#include <QDir>
#include <QDebug>
using namespace  std;

TAFSTools::TAFSTools(){
     draftDirectory = "draft/";
     lcDirectory = "c:/sharefolder/";
     resultDirectory = "result/";
}

bool TAFSTools::removeFolderContent(const QString folderDir)
{
    QDir dir(folderDir);
    QFileInfoList fileList;
    QFileInfo curFile;
    if(!dir.exists())  {return false;}//文件不存，则返回false
    fileList=dir.entryInfoList(QDir::Dirs|QDir::Files
                               |QDir::Readable|QDir::Writable
                               |QDir::Hidden|QDir::NoDotAndDotDot
                               ,QDir::Name);
    while(fileList.size()>0)
    {
        int infoNum=fileList.size();
        for(int i=infoNum-1;i>=0;i--)
        {
            curFile=fileList[i];
            if(curFile.isFile())//如果是文件，删除文件
            {
                QFile fileTemp(curFile.filePath());
                fileTemp.remove();
                fileList.removeAt(i);
            }
            if(curFile.isDir())//如果是文件夹
            {
                QDir dirTemp(curFile.filePath());
                QFileInfoList fileList1=dirTemp.entryInfoList(QDir::Dirs|QDir::Files
                                                              |QDir::Readable|QDir::Writable
                                                              |QDir::Hidden|QDir::NoDotAndDotDot
                                                              ,QDir::Name);
                if(fileList1.size()==0)//下层没有文件或文件夹
                {
                    dirTemp.rmdir(".");
                    fileList.removeAt(i);
                }
                else//下层有文件夹或文件
                {
                    for(int j=0;j<fileList1.size();j++)
                    {
                        if(!(fileList.contains(fileList1[j])))
                            fileList.append(fileList1[j]);
                    }
                }
            }
        }
    }
    return true;
}

void TAFSTools::delete_dir(string path)
{
    long hFile = 0;
    struct _finddata_t fileInfo;
    StrConvert sc;
    string pathName;
    // \\* 代表要遍历所有的类型
    if ((hFile = _findfirst(pathName.assign(path).append("*").c_str(), &fileInfo)) == -1) {
        return;
    }
    do
    {
        //判断文件的属性是文件夹还是文件
        //如果是文件夹就进入文件夹，迭代
        if (fileInfo.attrib&_A_SUBDIR) {
            {//遍历文件系统时忽略"."和".."文件
                ////qDebug()<<fileInfo<<endl;
                if (strcmp(fileInfo.name, ".") != 0 && strcmp(fileInfo.name, "..") != 0) {
                    string tmp;
                    tmp = path +"/" + fileInfo.name;
                    delete_dir(tmp);

                    LPCWSTR cc = sc.CharToLPCWSTR(sc.ConstToChar(tmp.c_str()));

                    RemoveDirectory(cc);
                }
            }
        }
        //是文件的话就查看文件名，不是“back1.bmp”就删除
        else {
            if (strcmp(fileInfo.name, ".") != 0 && strcmp(fileInfo.name, "..") != 0) {
                if (strcmp(fileInfo.name, "back1.bmp")) {
                    string delpath = path + "/" + fileInfo.name;
                    if (remove(delpath.c_str()) != 0)//删除失败就报错
                        perror("Error deleting file");
                }
            }
        }
    } while (_findnext(hFile, &fileInfo) == 0);
    _findclose(hFile);
    return;
}

QFileInfoList TAFSTools::findFolders(string path){
    QDir dir(QString::fromStdString(path));
    QFileInfoList folder_list = dir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);

    return folder_list;
}

string TAFSTools::findXML(vector<string> files){
    int size = (int)files.size();
    for(int i=0; i<size; i++){
        if(files[i].find("xml") != -1){
            return files[i];
        }
    }
    return "";
}

char* TAFSTools::check(const char* tmp){

    char* index = new char[255];
    index[0] = '\0';
    if(!tmp)
        return index;
    strcpy_s(index,255,tmp);
    return index;
}

ShipDectResult TAFSTools::AnalysisShipDectResultXML(string xmlFile){

    try
    {
        //以DOM的格式把xml文件全部读入到TiXMLDocument的对象中
        TiXmlDocument *myDocument = new TiXmlDocument(xmlFile.c_str());
        myDocument->LoadFile(TIXML_ENCODING_UTF8);
        TiXmlElement *rootElm= myDocument ->RootElement();

        TiXmlElement* BaseInfo =rootElm->FirstChildElement("BaseInfo");
        TiXmlElement* result = rootElm->FirstChildElement("result");

        TiXmlAttribute * pAttr = rootElm->FirstAttribute();
        if(pAttr->Value())
            sdr.setSatellite(sc.ConstToChar(pAttr->Value()));
        pAttr = pAttr->Next();
        if(pAttr->Value()){
            string s = pAttr->Value();
            sdr.setImagingtime(sc.ConstToChar(s.c_str()));
        }
        pAttr = pAttr->Next();
        if(pAttr->Value())
            sdr.setResolution(sc.ConstToChar(pAttr->Value()));
        pAttr = BaseInfo->FirstAttribute();
        sdr.setName(sc.ConstToChar(pAttr->Value()));
        pAttr = pAttr->Next();
        sdr.setID(sc.ConstToChar(pAttr->Value()));
        pAttr = pAttr->Next();
        sdr.setDescription(sc.ConstToChar(pAttr->Value()));

        int DetectNumber = atoi(result->FirstChildElement("DetectNumber")->GetText());
        int blockNumber = atoi(result->FirstChildElement("BlockNumber")->GetText());
        sdr.setDetectNumber(DetectNumber);
        sdr.setBlockNumber(blockNumber);
        ShipSlic* slices = new ShipSlic[2*DetectNumber+100];

        TiXmlElement* Element = result->FirstChildElement("DetectResult");
        for(int i=0; i<DetectNumber; i++){
            slices[i].setResultID(check(Element->FirstChildElement("ResultID")->GetText()));
            slices[i].setLocation(check(Element->FirstChildElement("Location")->GetText()));
            slices[i].setCenterLonLat(check(Element->FirstChildElement("CenterLonLat")->GetText()));
            slices[i].setLength(atof(check(Element->FirstChildElement("Length")->GetText())));
            slices[i].setWidth(atof(check(Element->FirstChildElement("Width")->GetText())));
            slices[i].setArea(atof(check(Element->FirstChildElement("Area")->GetText())));
            slices[i].setAngle(atof(check(Element->FirstChildElement("Angle")->GetText())));
            slices[i].setProbability(atof(check(Element->FirstChildElement("Probability")->GetText())));
            slices[i].setResultImagePath(check(Element->FirstChildElement("ResultImagePath")->GetText()));
            slices[i].setValidationName(check(Element->FirstChildElement("ValidationName")->GetText()));
            cout<<slices[i].getValidationName()<<endl;
            TiXmlElement* shape = Element->FirstChildElement("Shape");
            TiXmlElement* point = shape->FirstChildElement("Point");
            slices[i].setLefttop(point->GetText());
            point = point->NextSiblingElement("Point");
            slices[i].setRighttop(point->GetText());
            point = point->NextSiblingElement("Point");
            slices[i].setRightbottom(point->GetText());
            point = point->NextSiblingElement("Point");
            slices[i].setLeftbottom(point->GetText());

            string s = Element->FirstChildElement("TopLeft")->GetText();
            int index = s.find(",");
            slices[i].setTopLeftY(atof(s.substr(0, index).c_str()));
            slices[i].setTopLeftX(atof(s.substr(index+1).c_str()));

            s = Element->FirstChildElement("BottomRight")->GetText();
            index = s.find(",");
            slices[i].setBottomRightY(atof(s.substr(0, index).c_str()));
            slices[i].setBottomRightX(atof(s.substr(index+1).c_str()));

            slices[i].setBlockOrder(atoi(Element->FirstChildElement("BlockOrder")->GetText()));

            PossibleResults* pr = new PossibleResults();
            TiXmlElement* possibility = Element->FirstChildElement("PossibleResults");
            pr->setType(check(possibility->FirstChildElement("Type")->GetText()));
            if(possibility->FirstChildElement("Reliability")->GetText())
                pr->setReliability(atof(possibility->FirstChildElement("Reliability")->GetText()));
            else
                pr->setReliability(0);
            slices[i].setPR(*pr);
            Element = Element->NextSiblingElement("DetectResult");
        }
        sdr.setSlices(slices);
    }
    catch (string e){
    }
    return sdr;
}

ShipDectResult TAFSTools::loadFiles(string path,int* tmp, bool& mark){
    image = path;
    tmp[0] = 1;
    string localpath = lcDirectory;

    ShipDectResult sdr;
    mark = ftp.Connection();
    if(!mark) return sdr;

    vector<string> files = ftp.getRemoteFilename(path);
    QApplication::processEvents();
    for(int i=0; i<files.size(); i++){
           if(files[i] == "lock"){
               tmp[0] = 0;
               return sdr;
           }
    }
    //这一部分是不是只需要在本地添加lock锁就可以
    QString index = QString::fromStdString(lcDirectory + "lock");
    QFile file(index);
    file.open(QIODevice::WriteOnly);
    file.close();
    vector<string> lock;
    lock.push_back("lock");
    ftp.uploadFile(lock,resultDirectory + path, localpath);
    QApplication::processEvents();
    xmlFile = findXML(files);
    files.clear();
    files.push_back(xmlFile);
    ftp.downloadFile(files, path);

    vector<string> slicefiles = ftp.getRemoteFilename(path+"slices/");

    ftp.downloadFile(slicefiles, path+"slices/");

    for(int i=0; i<slicefiles.size(); i++){
        string tmpfile = localpath + path + "slices/" + slicefiles[i];
        string tmpdir = localpath + path + "slices/";
        JlCompress::extractDir(tmpfile.c_str(), tmpdir.c_str());
        remove(tmpfile.c_str());
	QApplication::processEvents();
    }

    if(xmlFile != ""){
        string a =lcDirectory + path + xmlFile;
        sdr = AnalysisShipDectResultXML(lcDirectory + path + "/" + xmlFile);
    }

    return sdr;
}

bool TAFSTools::cancelLock(string remotepath){
    vector<string> files;
    files.push_back("lock");
    bool mark = ftp.removeFile(files, remotepath);
    return mark;

}

string TAFSTools::createNoticeXML(ShipDectResult sdr, string detxml){
    string img = image.substr(0,image.find("/"));
    string t = img + "/" + img + ".xml";

    NoticeXML notice;

    notice.setInputImage(resultDirectory + image + image.substr(0,image.size()-1) + ".tiff");
    notice.setDetXml(resultDirectory + detxml);
    notice.setSatelliteName(sdr.getSatellite());
    notice.setImagingTime(sdr.getImagingtime());
    ShipSlic slice = sdr.getSlices()[0];
    string inf = slice.getCenterLonLat();
    notice.setLatitude(atof((inf.substr(0,inf.find(","))).c_str()));
    if(inf.find(", ") < inf.size())
        notice.setLongitude(atof((inf.substr(inf.find(", "), inf.size())).c_str()));
    else
        notice.setLongitude(atof((inf.substr(inf.find(","), inf.size())).c_str()));
    notice.setSensorName("xxx");
    notice.setTargetID("xxxxxxxxx");
    notice.setTargetName("xxxxxx");

    TiXmlDeclaration* xmlDec=new TiXmlDeclaration("1.0","UTF-8","yes");
    TiXmlDocument *xmlDoc = new TiXmlDocument();
    xmlDoc->LinkEndChild(xmlDec);

    string element[9] = {"InputImage","SatelliteName","SensorName","ImagingTime","TargetID","TargetName","Longitude","Latitude","DetXml"};
    TiXmlElement *taskElm=new TiXmlElement("Params");
    for(int i=0; i<9; i++){
        TiXmlElement *Element=new TiXmlElement(element[i].c_str());
        Element->LinkEndChild(new TiXmlText(notice.getword(element[i]).c_str()));
        taskElm->LinkEndChild(Element);
    }

    xmlDoc->LinkEndChild(taskElm);

    string str = lcDirectory + t;

    xmlDoc->SaveFile(str.c_str());
    //qDebug()<<QString::fromStdString(img + ".xml")<<endl;
    return img + ".xml";

}

bool TAFSTools::draft(ShipDectResult sdr){//其实还需要共享文件夹下的制图文件夹

    vector<string> files;

    string noticeXML = createNoticeXML(sdr, image + xmlFile);

    files.push_back(noticeXML);

    bool mark = ftp.uploadFile(files,draftDirectory,lcDirectory + "/" + image);

    remove((lcDirectory + image + "/" + noticeXML).c_str());

    return mark;
}

void TAFSTools::UpdateShipDectResultXML(char* inputFile,ShipDectResult* sdr){
    //把sdr中的内容重新写入到xml文件中

    TiXmlDocument *pDoc = new TiXmlDocument();
    if (NULL==pDoc)
    {
        return;
    }

    pDoc->LoadFile(inputFile);

    TiXmlElement* pRootElement = pDoc->RootElement();

    ShipSlic* slices = sdr->getSlices();
    int size = sdr->getDetectNumber();

    TiXmlElement* result = pRootElement->FirstChildElement("result");

    TiXmlElement* DetectResult = result->FirstChildElement("DetectResult");

    for(int i=0; i<size; i++){
        DetectResult->RemoveChild(DetectResult->FirstChildElement("Probability"));
        TiXmlElement* Probability = new TiXmlElement("Probability");
        Probability->LinkEndChild(new TiXmlText(sc.DoubleToStr(slices[i].getProbability()).c_str()));
        DetectResult->LinkEndChild(Probability);
        DetectResult = DetectResult->NextSiblingElement("DetectResult");
    }

    pDoc->SaveFile(inputFile);
}

bool TAFSTools::setSliceInf(ShipDectResult sdr){   //path上传文件的远程共享文件夹，filename,
    //修改切片的名称加入了虚警信息
    bool mark = true;
    StrConvert sc;
    string path = lcDirectory + "/" + image + "/" + xmlFile;
    UpdateShipDectResultXML(sc.ConstToChar(path.c_str()),&sdr);
    return mark;
}

map<string,int> TAFSTools::getSliceInf(ShipDectResult sdr){

    map<string,int> Map;
    ShipSlic* slices = sdr.getSlices();
    for(int i=0; i<sdr.getDetectNumber(); i++){
        Map[slices[i].getValidationName()] = i;
        qDebug()<<QString::fromStdString(slices[i].getValidationName())<<"  "<<Map[slices[i].getValidationName()]<<endl;
    }
    return Map;
}

bool TAFSTools::complete(){

    string localpath = lcDirectory + image;
    string remotepath = image ;
    vector<string> files;
    files.push_back(xmlFile);
    bool mark = ftp.uploadFile(files, resultDirectory + remotepath,localpath);
    return mark;
}

bool TAFSTools::SetNode(TiXmlElement* element, string key, string value){
    TiXmlElement* keyElement = new TiXmlElement(key.c_str());
    keyElement->LinkEndChild(new TiXmlText(value.c_str()));
    element->LinkEndChild(keyElement);
    return true;
}

string TAFSTools::ftoa(double value){
    stringstream ss;
    string str;

    ss << fixed << setprecision(6)<<value;
    ss >> str;
    return str;
}

bool TAFSTools::AppendRecord(ShipDectResult* sdr, string* Array){
    ShipSlic slice;
    string center = Array[4];
    slice.setLefttop(Array[0].replace(Array[0].find("_"), 1, ", "));
    slice.setRighttop(Array[2].replace(Array[2].find("_"), 1, ", "));
    slice.setRightbottom(Array[3].replace(Array[3].find("_"), 1, ", "));
    slice.setLeftbottom(Array[1].replace(Array[1].find("_"), 1, ", "));
    slice.setCenterLonLat(Array[4].replace(Array[4].find("_"), 1, ", "));
    char buffer[20];
    itoa(sdr->getDetectNumber()+1, buffer,10);
    string index = buffer;
    slice.setResultID(index);
    slice.setProbability(1);
    slice.setValidationName(center + ".tiff");
    ShipSlic* slices = sdr->getSlices();
    slices[sdr->getDetectNumber()] = slice;
    sdr->setSlices(slices);
    sdr->setDetectNumber(sdr->getDetectNumber()+1);

    //将切片信息添加至xml中
    TiXmlDocument *pDoc = new TiXmlDocument();
    if (NULL==pDoc)
    {
        return false;
    }
    string xml = lcDirectory + image + "/" + xmlFile;
    pDoc->LoadFile(xml.c_str());

    TiXmlElement* pRootElement = pDoc->RootElement();

    TiXmlElement* result = pRootElement->FirstChildElement("result");
    TiXmlElement* DetectResult = new TiXmlElement("DetectResult");
    TiXmlElement* DetectNumber = result->FirstChildElement("DetectNumber");
    DetectNumber->Clear();
    itoa(sdr->getDetectNumber(), buffer,10);
    index = buffer;
    DetectNumber->LinkEndChild(new TiXmlText(index.c_str()));
    SetNode(DetectResult, "ResultID", slice.getResultID());
    TiXmlElement* shape = new TiXmlElement("Shape");
    SetNode(shape, "Point", slice.getLefttop());
    SetNode(shape, "Point", slice.getRighttop());
    SetNode(shape, "Point", slice.getRightbottom());
    SetNode(shape, "Point", slice.getLeftbottom());
    SetNode(shape, "Point", slice.getLefttop());
    DetectResult->LinkEndChild(shape);
    SetNode(DetectResult, "TopLeft", Array[5]);
    SetNode(DetectResult, "BottomRight", Array[6]);
    SetNode(DetectResult, "BlockOrder", Array[7]);
    SetNode(DetectResult, "Location", "NoKnown");
    SetNode(DetectResult, "CenterLonLat", slice.getCenterLonLat());
    SetNode(DetectResult, "Length", "0.0");
    SetNode(DetectResult, "Width", "0.0");
    SetNode(DetectResult, "Area", "0.0");
    SetNode(DetectResult, "Angle", "0.0");
    SetNode(DetectResult, "Probability", "1");
    SetNode(DetectResult, "ResultImagePath", "1");    //填写绝对路径还是相对路径
    SetNode(DetectResult, "ValidationName", slice.getValidationName());
    TiXmlElement* PossibleResults = new TiXmlElement("PossibleResults");
    SetNode(PossibleResults, "Type", "");
    SetNode(PossibleResults, "Reliability", "0");
    DetectResult->LinkEndChild(PossibleResults);
    result->LinkEndChild(DetectResult);

    pDoc->SaveFile(xml.c_str());

    return true;
}
