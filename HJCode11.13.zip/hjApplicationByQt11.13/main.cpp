﻿#include "widget.h"
#include <QApplication>
#include <QPalette>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    QApplication::addLibraryPath("./plugins");
    w.setWindowTitle("人工虚警排除软件");
    QPalette pal(w.palette());
    pal.setColor(QPalette::Background, QColor(0,69,107));
    w.setAutoFillBackground(true);
    w.setPalette(pal);
    w.show();
    return a.exec();
}
