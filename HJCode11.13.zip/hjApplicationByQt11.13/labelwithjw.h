﻿#ifndef LABELWITHJW_H
#define LABELWITHJW_H
#include <QWidget>
#include <QLabel>
#include <QPointF>
#include <QRectF>
#include <QPainter>
#include <math.h>
#pragma execution_character_set("utf-8")

class LabelWithJW : public QLabel
{
    Q_OBJECT

public:
    explicit LabelWithJW(QWidget *parent = 0);
    LabelWithJW(const QString &text, QWidget *parent=0, Qt::WindowFlags f=0);
    ~LabelWithJW();
    void showJW();
    void cancelShowJW();
    void toRepaint();
    QRectF getRec();
    QPixmap getCapturePixmap();
    bool isShowRec = false;//点击界面上的增加切片按钮，会开放画矩形的功能
    QPixmap loadPixmap, capturePixmap;
    bool isShowJW = false;
    bool isFinishCapture = false;
//    QRectF getRec();
//    QPixmap loadPixmap, capturePixmap;



Q_SIGNALS:
    void signalMouseMove(QPointF mousePoint);
    void signalSliceCapture(QPixmap captureImage, QPointF topLeft, QPointF bottomRight);
    void signalWheelUp();
    void signalWheelDown();
    void signalDrag(QPointF dragBeginPoint, QPointF dragEndPoint, int width, int type);//type表示当前状态，为1表示刚按下，为2表示离开

protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
    void wheelEvent(QWheelEvent *);
//    void keyPressEvent(QKeyEvent *);

private:
    bool isMousePress = false;
    bool isDrag = false;
    QPointF beginPoint;//移动前鼠标坐标
    QPointF endPoint;//移动后鼠标坐标
    QPointF dragBeginPoint;//拖动前鼠标坐标
    QPointF dragEndPoint;//拖动后鼠标坐标
    QPainterPath path;
    QPainter painter;
//    qreal factorx, factory;
//    QRectF selectedRec;
};



#endif // LABELWITHJW_H
