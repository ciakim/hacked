﻿#include "strconvert.h"
#include <qt_windows.h>
#include <sstream>
#include <string>
#include <QDebug>
using namespace std;
StrConvert::StrConvert()
{

}

LPCWSTR StrConvert::CharToLPCWSTR(char* tmp)
{

    size_t origsize = sizeof(tmp) + 1;
    const size_t newsize = (size_t)100;
    size_t convertedChars = (size_t)0;
    wchar_t *wcstring = (wchar_t *)malloc(255);
    int t = sizeof(wchar_t)*(sizeof(tmp)-1);
    mbstowcs_s(&convertedChars, wcstring, origsize, tmp, _TRUNCATE);
    return wcstring;

}

char* StrConvert::ConstToChar(const char* tmp)
{
    char* index = new char[255];
    strcpy_s(index,250,tmp);
    return index;
}

char* StrConvert::IntegerToString(int temp)
{
    char *str = new char[10];
    int num = 0;
    char index;
    while(temp != 0)
    {
        str[num++] = temp%10 + '0';
        temp = temp/10;
    }

    for(int i=0; i<num/2; i++)
    {
        index = str[i];
        str[i] = str[num-1-i];
        str[num-1-i] = index;
    }
    char* result = new char[num+1];
    for(int i=0; i<num; i++)
        result[i] = str[i];
    result[num] = '\0';
    return result;
}

void StrConvert::split(string& s, string& delim, vector<string>* ret)
{
    size_t last = 0;
    size_t index=s.find_first_of(delim,last);
    while (index!=string::npos)
    {
        ret->push_back(s.substr(last,index-last));
        last=index+1;
        index=s.find_first_of(delim,last);
    }
    if (index-last>0)
    {
        ret->push_back(s.substr(last,index-last));
    }
}

string StrConvert::DoubleToStr(double tmp)
{
    stringstream ss;
    string str;
    ss << tmp;
    ss >> str;
    return str;
}

void StrConvert::CharToTchar (const char * _char, TCHAR * tchar)
{
    int iLength ;

    iLength = MultiByteToWideChar (CP_ACP, 0, _char, strlen (_char) + 1, NULL, 0) ;
    MultiByteToWideChar (CP_ACP, 0, _char, strlen (_char) + 1, tchar, iLength) ;
}


char* StrConvert::WCharToChar(WCHAR *s){

   int w_nlen=WideCharToMultiByte(CP_ACP,0,s,-1,NULL,0,NULL,false);

  char *ret=new char[w_nlen];

  memset(ret,0,w_nlen);

  WideCharToMultiByte(CP_ACP,0,s,-1,ret,w_nlen,NULL,false);

 return ret;

}
