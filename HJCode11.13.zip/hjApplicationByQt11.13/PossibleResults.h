﻿#ifndef PossibleResults_H
#define PossibleResults_H

#include<string>
using namespace std;
class PossibleResults{
private:
	string type;
	double reliability;
public:
	string getType(){
		return this->type;
	}
	void setType(string type){
		this->type = type;
	}

	double getReliability(){
		return this->reliability;
	}

	void setReliability(double reliability){
		this->reliability = reliability;
	}
};
#endif
