﻿#ifndef MYLABEL_H
#define MYLABEL_H
#include <QWidget>
#include <QLabel>
#include <QPointF>
#include <QRectF>
#include <QApplication>
#include <QPainter>
#include <QPicture>
#pragma execution_character_set("utf-8")

class myLabel : public QLabel
{
    Q_OBJECT

public:
    explicit myLabel(QWidget *parent = 0);
    myLabel(const QString &text, QWidget *parent=0, Qt::WindowFlags f=0);
    ~myLabel();
    void showRec();
    void cancelShowRec();
    QRectF getRec();
    QPixmap loadPixmap, capturePixmap;
    QPicture loadPicture;
    float labelWidth, labelHeight;
    float recWidth = 62;//红框的长
    float recHeight = 40;//红框的高

    float sRecWidth = 2;//切片框的长与高
    float sRecHeight = 2;

    float getx();
    void addRec(double x, double y);//每有一个切片，就增加一个框
    void moveRec(double x, double y);
    void resizeRec(double x, double y);
    QPointF recPosition();
    int scaleFlag = 10;//默认是10，用来控制兴趣域放大区的缩放,只能从1放大到20
    int recNum = 0;//所有切片的数量，可以知道要画多少个框

    QPainterPath recPath;//把所有切片框出来
    QPainterPath whitePath;//一定空白的路径，用来更新原来的方框

Q_SIGNALS:
    void signalCompleteCature(QPixmap catureImage);

protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
    void wheelEvent(QWheelEvent *);

private slots:
    void onWheelUp();
    void onWheelDown();
    void onTimeout();
    void onSignalDrag(QPointF dragBeginPoint, QPointF dragEndPoint, int bWidth, int type);

private:
    bool isShowRec = false;
//    QPointF leftPoint;//矩形的左上角点坐标
    QPointF beginPoint;//移动前鼠标坐标
    QPointF endPoint;//移动后鼠标坐标
    QPainterPath path;//定位框
//    qreal factorx, factory;
//    QRectF selectedRec;
    float extrax, extray;//修正后实际矩形位置和鼠标移动矩形位置之前的差异
    float increaseWidth = 12;
    float decreaseWidth = 12;
    float increaseHeight = recHeight/recWidth*increaseWidth;
    float decreaseHeight = recHeight/recWidth*decreaseWidth;
    double pastX=0;
    double pastY=0;
    double pastPathX=0;
    double pastPathY=0;
//    QPainter painter;
};



#endif // MYLABEL_H
