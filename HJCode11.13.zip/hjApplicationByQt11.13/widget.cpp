﻿#include "widget.h"
#include "ui_widget.h"

#include <QImage>
#include <QMessageBox>
#include <QPixmap>
#include <QString>
#include <QGridLayout>
#include <QPushButton>
#include <QFileDialog>
#include <QtXml/QDomDocument>
#include <QListWidget>
#include <QListWidgetItem>
#include <QDebug>
#include <QHeaderView>
#include <QDesktopServices>
#include <string>
#include <vector>
#include <QCursor>
#include <QImageReader>
#include <QDesktopWidget>
#include <QTimer>
#include <QBuffer>
#include <iostream>
using namespace std;

typedef struct MyData
{
    ShipSlic* myArray;
    int first;
    int end;
}MYDATA;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->label->setText("没有任务");
    ui->info->setText("经纬度");
    ui->label->setStyleSheet("color:rgb(255, 255, 255);");
    ui->info->setStyleSheet("color:rgb(255, 255, 255);");
    ui->pic1->setScaledContents(true);
    ui->pic2->setScaledContents(true);
    setWindowState(Qt::WindowMaximized);//默认窗口打开最大化
    ui->pic1->resize(QSize(0,0));
    ui->widget1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->pic2->resize(QSize(0,0));
    ui->widget2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->sliceTable->verticalHeader()->setVisible(false);//隐藏切片表格行表头
    ui->sliceTable->horizontalHeader()->setStretchLastSection(true);//设置切片表格充满表宽度
    ui->sliceTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);//设置第7列自适应内容
    ui->sliceTable->setSelectionBehavior(QAbstractItemView::SelectRows);//每次选中即选一行
    ui->sliceTable->setEditTriggers(QAbstractItemView::NoEditTriggers);//设置切片表格不可编辑
    ui->sliceList->setViewMode(QListWidget::IconMode);//将List设置成图片形式
    ui->sliceList->setIconSize(QSize(90,90));
    ui->sliceList->setResizeMode(QListWidget::Adjust);
    ui->sliceList->setMovement(QListView::Static);//切片不可被拖动
    ui->sliceList->setMouseTracking(true);//跟踪鼠标
    ui->sliceTable->setStyleSheet("QTableWidget::item:selected{color:white;background:#046ca5;}");
    ui->sliceList->setStyleSheet("QListWidget {show-decoration-selected: 1;}"
                                     "QListWidget::item:alternate {background: #EEEEEE;}"
                                     "QListWidget::item:selected {border: 1px solid #6398b6;}"
                                     "QListWidget::item:selected:!active {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #76b2d4, stop: 1 #6398b6);}"
                                     "QListWidget::item:selected:active {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #538dae, stop: 1 #6398b6);}"
                                     "QListWidget::item:hover {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #FAFBFE, stop: 1 #DCDEF1);}");
//    ui->dkBtn->setStyleSheet("QPushButton{background-color: red; border-style: outset;border-width: 2px;border-radius: 10px;border-color: beige;}");
    connect(ui->sliceList, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked(QListWidgetItem*)));
    connect(ui->sliceList, SIGNAL(itemClicked(QListWidgetItem*)), this, SLOT(slotItemClicked(QListWidgetItem*)));
    connect(ui->pic1, SIGNAL(signalCompleteCature(QPixmap)), this, SLOT(onCompleteCature(QPixmap)));
    connect(ui->pic2, SIGNAL(signalMouseMove(QPointF)), this, SLOT(onMouseMove(QPointF)));
    connect(ui->pic2, SIGNAL(signalWheelUp()), ui->pic1, SLOT(onWheelUp()));
    connect(ui->pic2, SIGNAL(signalWheelDown()), ui->pic1, SLOT(onWheelDown()));
    connect(ui->pic2, SIGNAL(signalSliceCapture(QPixmap,QPointF,QPointF)), this, SLOT(onSliceCapture(QPixmap,QPointF,QPointF)));
    connect(ui->pic2, SIGNAL(signalDrag(QPointF,QPointF,int,int)), ui->pic1, SLOT(onSignalDrag(QPointF,QPointF,int,int)));

    tmp[0] = 1;
    lockFileName = "";
    topw=0;
    bottomw=0;
    leftj=0;
    rightj=0;
    // picWidth=0;
    // picHeight=0;
    folder = "C:/sharefolder/";
    overLapping = 200;

    whiteImage = QImage(QSize(233,233),QImage::Format_ARGB32_Premultiplied);
    whiteImage.fill(Qt::transparent);    //把方框图变透明
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_dkBtn_clicked()
{
   forbidUI();
   ui->label->setText("正在打开任务，请耐心等候，勿进行其它操作");
   QString fileQStr = QFileDialog::getExistingDirectory(this,
                                                        tr("Select Task"),
                                                         folder);

   if(fileQStr.isEmpty())
   {
       cancelForbidUI();
       if(tmp[0]==3)
       {
           ui->label->setText(QString::fromStdString(lockFileName));
       }
       else
       {
           ui->label->setText(QString::fromStdString("没有任务"));
       }
       return;
   }

   if(tmp[0] == 3)//已经有任务被打开了
   {
       bool mark = tools.cancelLock(lockFileName);
       //mark为false时则提醒用户已经断网啦
       if(mark==false)
       {
           QMessageBox::information(this,
                                    tr("错误"),
                                    tr("服务器无法连接。six"));
           cancelForbidUI();
           QWidget::setCursor(Qt::ArrowCursor);
           return;
       }
       qDebug()<<"执行方框图清空程序";
       recImage = whiteImage;//更新方框图
       ui->pic1->recPath = ui->pic1->whitePath;
       qDebug()<<"whitePath是否为空"<<ui->pic1->recPath.isEmpty();
       qDebug()<<"recPath是否为空"<<ui->pic1->whitePath.isEmpty();
   }
   QWidget::setCursor(Qt::WaitCursor);
   QFileInfo file(fileQStr);
   QString fileBaseName = file.fileName();
   string fileName = fileBaseName.toStdString()+"/";

   bool mark;
   sdr = tools.loadFiles(fileName,tmp,mark);
   blockNumber = sdr.getBlockNumber();

   //mark 为false，则表示没联网，告示用户并返回
   if(mark == false)
   {
       ui->label->setText("无法接连服务器，请稍后重试");
       QMessageBox::information(this,
                                tr("错误"),
                                tr("服务器无法连接。one "));
       cancelForbidUI();
       QWidget::setCursor(Qt::ArrowCursor);
       return;
   }

   QApplication::processEvents();

   if(tmp[0] == 0)
   {
       ui->label->setText("该任务已在另一个客户端打开，请重新打开任务");
       QMessageBox::information(this,
                                tr("错误"),
                                tr("该任务已在另一个客户端打开"));
       cancelForbidUI();
       QWidget::setCursor(Qt::ArrowCursor);
       return;
   }

   QString dstFile(folder+fileBaseName+"/result.tiff");
   QFileInfo dstFileInfo(dstFile);
   if(!dstFileInfo.isFile())
   {
       ui->label->setText("文件对象错误");
       QMessageBox::information(this,
                                tr("错误"),
                                tr("选择的任务出现错误。"));
       cancelForbidUI();
       QWidget::setCursor(Qt::ArrowCursor);
       return;
   }


   lockFileName = fileBaseName.toStdString();

   QApplication::processEvents();

   try
   {
       QString srcFileName = folder + fileBaseName+"/"+fileBaseName+".tiff";
       QFileInfo srcFileInfo(srcFileName);
       if(!srcFileInfo.isFile())
       {
           srcFileName = folder + fileBaseName+"/"+fileBaseName+".TIF";
       }
       QByteArray tmp3 = srcFileName.toLatin1();
       qDebug()<<"srcfileName"<<srcFileName;
       char *srcfile = tmp3.data();

       readPic(srcfile);
       showPic1(dstFile);
       //getAdfGeoTransformByXXY(120.155,22.7058,120.417,22.6611,120.11,22.4912,120.371,22.4466,39376,35546);
       //leftj:  120.106   topw:  22.7048   rightj:  ƒ120.421   bottomw:  22.4503
       QApplication::processEvents();

       slices = sdr.getSlices();
       Map = tools.getSliceInf(sdr);//获得标注数组
       showTable(slices);//显示列表
       QApplication::processEvents();

       sliceFolder = folder + fileBaseName+"/slices";
       listSlicePic(sliceFolder);//展示切片图像

   }catch(exception)
   {
        ui->label->setText("出现异常");
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("出现异常"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
   }

   ui->label->setText(fileBaseName);
   QWidget::setCursor(Qt::ArrowCursor);
   cancelForbidUI();
   tmp[0] = 3;//已经打开任务了
   AddRec();
}

//void Widget::onTime()
//{
////    if(tmp[0] == 3)
////    {
//////        qDebug()<<ui->widget1->size();
////        QImage imgScaled = imgAll.scaled(ui->widget1->size(),Qt::KeepAspectRatio);
////        ui->pic1->resize(imgScaled.size());
////        ui->pic1->move((ui->widget1->width()-ui->pic1->width())/2,(ui->widget1->height()-ui->pic1->height())/2);
////        ui->pic1->labelWidth = imgScaled.width();
////        ui->pic1->labelHeight = imgScaled.height();
////        ui->pic1->setPixmap(QPixmap::fromImage(imgScaled));
////    }
//}

void Widget::showPic1(QString fileName)
{
   QImage* img=new QImage;
   if( !(img->load(fileName)) )
   {
       QMessageBox::information(this,
                                tr("error"),
                                tr("failed to open image"));
       delete img;
       return;
   }
   if(adfGeoTransform[1] == 1 && adfGeoTransform[5] == 1)
   {
       nXSize = img->width();
       nYSize = img->height();
       blockHeight = ((double)nYSize) / blockNumber;
       qDebug()<<"nYSize       "<<nYSize<<"           blockNumber:"<<blockNumber<<"  blockHeight:"<<blockHeight<<endl;
   }

//   qDebug()<<"img的图像长宽，验证是否与gdal里的信息一致"<<img->width()<<img->height();
//   获取屏幕大小
   QApplication::processEvents();
   QDesktopWidget *dsk = QApplication::desktop();
   //QSize dskSize(dsk->width(), dsk->height());
   //qDebug()<<"dsk: "<<dsk->width()<<dsk->height();
   //qDebug()<<"img: "<<img->size();
   imgAll = img->scaled(ui->widget1->size(),Qt::KeepAspectRatio);
   QApplication::processEvents();
   ui->pic1->resize(imgAll.size());
   //qDebug()<<"ui->widget1: "<<ui->widget1->size();
   //qDebug()<<"ui->pic1: "<<ui->pic1->size();
   //qDebug()<<"imgScaled: "<<imgScaled.size();
   ui->pic1->labelWidth = imgAll.width();
   ui->pic1->labelHeight = imgAll.height();
   ui->pic1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);"
                           "background-color:white;");
   ui->widget1->setStyleSheet("");
   ui->pic2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);"
                           "background-color:white;");
   ui->widget2->setStyleSheet("");
   ui->pic1->move((ui->widget1->width()-ui->pic1->width())/2,(ui->widget1->height()-ui->pic1->height())/2);
   ui->pic1->setPixmap(QPixmap::fromImage(imgAll));
   QApplication::processEvents();
   ui->pic1->showRec();

   qDebug()<<"ui.pic1.size"<<ui->pic1->size();
   QSize newSize(dsk->width()*7,dsk->height()*7);
   baseImage = img->scaled(newSize,Qt::KeepAspectRatio);
   //baseImage = *img;
   recImage = QImage(baseImage.size(),QImage::Format_ARGB32_Premultiplied);
   recImage.fill(Qt::transparent);    //把方框图变透明
   QApplication::processEvents();
   ui->pic1->loadPixmap = QPixmap::fromImage(baseImage);
//   ui->pic1->repaint();
//   ui->pic2->repaint();
}

void Widget::readPic(const char* srcfile)
{
    //qDebug()<<srcfile;
    //获取图片经纬度信息
    GDALAllRegister();
    CPLSetConfigOption("GDAL_FILENAME_IS_UTF8", "NO");   //为了支持中文路径
    GDALDataset *poDataset = (GDALDataset *)GDALOpen(srcfile, GA_ReadOnly);   //打开影像
    //projRef将会存储test.tif中的坐标信息
    //qDebug()<<"2333";
    const char* projRef = poDataset->GetProjectionRef();
    //adfGeoTransform存储一些基准点的坐标和每一个pixel表示的长度等
//    double adfGeoTransform[6];
    poDataset->GetGeoTransform(adfGeoTransform);
    //qDebug()<< adfGeoTransform[1] << adfGeoTransform[5];

    if(adfGeoTransform[1] == 1 && adfGeoTransform[5] == 1)
    {
        ui->info->setText("没有经纬度信息");
        ui->zjBtn->setEnabled(false);
        return;
    }
    ui->pic2->showJW();

    dTemp = adfGeoTransform[1] * adfGeoTransform[5] - adfGeoTransform[2] *adfGeoTransform[4];
    qDebug()<<"最开始算到的dTemp: "<<dTemp;

    //下面获得波段信息
    GDALRasterBand *poBand;
    poBand = poDataset->GetRasterBand(1);

    //获得图像左右、上下的像素点
    nXSize = poBand->GetXSize();
    nYSize = poBand->GetYSize();
    //qDebug()<<"像素点信息——nXSize: "<<nXSize<<"  nYSize: "<<nYSize;
    blockHeight = ((double)nYSize) / blockNumber;
    qDebug()<<"hely       "<<blockHeight<<endl;
    //adfGeoTransform中（这里简称GT），GT[0],GT[3]是左上角坐标，GT[1],GT[5]是图像总向横向分辨率
    leftj = adfGeoTransform[0];
    topw = adfGeoTransform[3];
    rightj = adfGeoTransform[0]+ nXSize * adfGeoTransform[1];
    bottomw = adfGeoTransform[3]+ nYSize * adfGeoTransform[5];
//    qDebug()<<"坐标信息——leftj: "<<leftj<<"  topw: "<<topw<<"  rightj: "<<rightj<<"  bottomw: "<<bottomw;

    //将坐标信息转化为经纬度信息，需要用到proj_api.h
//    OGRSpatialReference fRef, tRef;//放到头文件里作为全局变量定义了
    char *tmp = NULL;
    //获得projRef的一份拷贝
    //由于projRef是const char*,下面的一个函数不接受，所以需要转换成非const
    tmp = (char *)malloc(strlen(projRef) + 1);
    strcpy_s(tmp, strlen(projRef)+1, projRef);

    //设置原始的坐标参数，和初始图像一致
    fRef.importFromWkt(&tmp);
    //设置转换后的坐标
    tRef.SetWellKnownGeogCS("WGS84");

    //坐标转换
    //OGRCoordinateTransformation *coordTrans;//放到头文件里作为全局变量定义了
    coordTrans = OGRCreateCoordinateTransformation(&fRef, &tRef);
    coordTransInverse = OGRCreateCoordinateTransformation(&tRef, &fRef);
    coordTrans->Transform(1, &leftj, &topw);
    coordTrans->Transform(1, &rightj, &bottomw);
    qDebug()<<"经纬度信息——leftj: "<<leftj<<"  topw: "<<topw<<"  rightj: "<<rightj<<"  bottomw: "<<bottomw;


    picWidth = poDataset->GetRasterXSize();
    picHeight = poDataset->GetRasterYSize();
    return;
}

void Widget::getMouseJ(double mouseX)
{
    double finalX = mouseX/ui->pic2->width()*ui->pic1->recWidth + ui->pic1->recPosition().x();//鼠标所在的点在大图上的x位置
//    //qDebug()<<" mouseX:"<< mouseX << " ui->pic2->width() "<< ui->pic2->width() <<" ui->pic1->recWidth:"<< ui->pic1->recWidth << " ui->pic1->recPosition().x() : "<< ui->pic1->recPosition().x();
    mouseJ = nXSize * finalX / ui->pic1->width();
}

void Widget::getMouseW(double mouseY)
{
    double finalY = mouseY/ui->pic2->height()*ui->pic1->recHeight + ui->pic1->recPosition().y();//鼠标所在的点在大图上的y位置
//    //qDebug()<<" mouseY:"<< mouseY << " ui->pic2->height() "<< ui->pic2->height() <<" ui->pic1->recheight:"<< ui->pic1->recHeight << " ui->pic1->recPosition().y() : "<< ui->pic1->recPosition().y();
    mouseW = nYSize * finalY / ui->pic1->height();
//    //qDebug()<<" nYSize: "<<nYSize <<" finalY:"<<finalY <<" ui->pic1->width(): "<<ui->pic1->width() ;
}

double Widget::getJ(double x)
{
    double finalX = x/ui->pic2->width()*ui->pic1->recWidth + ui->pic1->recPosition().x();//点在大图上的x位置
    double j = nXSize * finalX / ui->pic1->width();
    return j;
}

double Widget::getW(double y)
{
    double finalY = y/ui->pic2->height()*ui->pic1->recHeight + ui->pic1->recPosition().y();//点在大图上的y位置
    double w = nYSize * finalY / ui->pic1->height();
    return w;
}

void Widget::onMouseMove(QPointF mousePoint)
{
    double mouseX = mousePoint.x();
    double mouseY = mousePoint.y();
    getMouseJ(mouseX);
    getMouseW(mouseY);
    mouseJ = adfGeoTransform[0]+ mouseJ * adfGeoTransform[1];
    mouseW = adfGeoTransform[3]+ mouseW * adfGeoTransform[5];
//    //qDebug()<<" mouseJ:"<< mouseJ << " mouseW : "<< mouseW;
    coordTrans->Transform(1, &mouseJ, &mouseW);
    ui->info->setText(QString::number(mouseJ) + "," + QString::number(mouseW));
}


void Widget::onCompleteCature(QPixmap captureImage)
{
   QPixmap imgScaled = captureImage.scaled(ui->widget2->size(), Qt::KeepAspectRatio);
   ui->pic2->resize(imgScaled.size());
   ui->pic2->move((ui->widget2->width()-ui->pic2->width())/2,(ui->widget2->height()-ui->pic2->height())/2);
//    ui->pic2->setPixmap(imgScaled);
   ui->pic2->loadPixmap = imgScaled;
   ui->pic2->update();
}

void Widget::showTable(ShipSlic *slices)
{
   ui->sliceTable->clearContents();
   ui->sliceTable->setRowCount(0);
   for(int i=0; i<sdr.getDetectNumber(); i++)
   {
       string shipname = slices[i].getValidationName();
       string lefttop = slices[i].getLefttop();
       string leftbottom = slices[i].getLeftbottom();
       string righttop = slices[i].getRighttop();
       string rightbottom = slices[i].getRightbottom();
       string centerlonlat = slices[i].getCenterLonLat();
       //qDebug()<<"number"<<sdr.getDetectNumber();
       //cout<<"输出第"<<i<<"个切片"<<shipname<<"的经纬度："<<slices[i].getX()<<"\t"<<slices[i].getY()<<endl;
       //qDebug()<<"输出第"<<i<<"个切片的经纬度："<<slices[i].getX()<<"\t"<<slices[i].getY();
       listSlice(shipname, centerlonlat, lefttop, leftbottom, righttop, rightbottom);
   }
}

void Widget::listSlice(string shipname, string centerlonlat, string lefttop, string leftbottom, string righttop, string rightbottom)
{
   int rowCount = ui->sliceTable->rowCount();//获取表单行数
   ui->sliceTable->insertRow(rowCount);//插入新行

   QTableWidgetItem *shipName = new QTableWidgetItem();
   QTableWidgetItem *centerLonLat = new QTableWidgetItem();
   QTableWidgetItem *leftTop = new QTableWidgetItem();
   QTableWidgetItem *leftBottom = new QTableWidgetItem();
   QTableWidgetItem *rightTop = new QTableWidgetItem();
   QTableWidgetItem *rightBottom = new QTableWidgetItem();

   shipName->setText(QString::fromStdString(shipname));
   centerLonLat->setText(QString::fromStdString(centerlonlat));
   leftTop->setText(QString::fromStdString(lefttop));
   leftBottom->setText(QString::fromStdString(leftbottom));
   rightTop->setText(QString::fromStdString(righttop));
   rightBottom->setText(QString::fromStdString(rightbottom));

   ui->sliceTable->setItem(rowCount,0,shipName);
   ui->sliceTable->setItem(rowCount,1,centerLonLat);
   ui->sliceTable->setItem(rowCount,2,leftTop);
   ui->sliceTable->setItem(rowCount,3,leftBottom);
   ui->sliceTable->setItem(rowCount,4,rightTop);
   ui->sliceTable->setItem(rowCount,5,rightBottom);
}

void Widget::listSlicePic(QString filePath)
{
   ui->sliceList->clear();
   QDir dir(filePath);
   if(!dir.exists()){
       //qDebug()<<dir;
       //qDebug()<<"wrong path";
       QMessageBox::information(this,
                                tr("error"),
                                tr("The slice folder does not exist."));
       return;
   }
   dir.setFilter(QDir::Files | QDir::NoSymLinks);
   QFileInfoList list = dir.entryInfoList();
   int file_count = list.count();
   if(file_count <= 0){
       //qDebug()<<"no file!";
       QMessageBox::information(this,
                                tr("error"),
                                tr("The slice folder is empty"));
       return;
   }
   for(int i=0;i<file_count ;i++){
       QFileInfo fileInfo = list.at(i);
       QString fileName=fileInfo.fileName();
       QPixmap slicePixmap(fileInfo.filePath());
       QListWidgetItem *tmp = new QListWidgetItem(QIcon(slicePixmap.scaled(QSize(110,110))),fileName);
       //qDebug()<<"fileName: "<<fileName<<"  map[fileName]: "<<Map[fileName.toStdString()]<<"  Probability: "<<slices[Map[fileName.toStdString()]].getProbability();
       string fileNameStr = fileName.toStdString();
       if(slices[Map[fileNameStr]].getProbability()==0)//为1时表示是船，背景为海蓝，为0时表示是虚警，背景为白
       {
           tmp->setBackgroundColor(Qt::white);
       }
       else
       {
           tmp->setBackgroundColor(QColor(45, 114, 152));
       }
       tmp->setSizeHint(QSize(130,130));
       ui->sliceList->addItem(tmp);
//       ui->pic1->addRec(getSPosX(slices[Map[fileNameStr]].getX()),getSPosY(slices[Map[fileNameStr]].getY()));
//       qDebug()<<"fileName: "<<fileName;
//       double recX = getRecPosX(slices[Map[fileNameStr]].getX());
//       double recY = getRecPosY(slices[Map[fileNameStr]].getY());
   //    qDebug()<<setprecision(6)<<slices[Map[fileNameStr]].getX()<<"   fgasf     "<<slices[Map[fileNameStr]].getY()<<endl;
//       double recWidth = getRecLength(slices[Map[fileNameStr]].getLength());
//       double recHeight = getRecLength(slices[Map[fileNameStr]].getWidth());
//       qDebug()<<recX<<recY<<recWidth<<recHeight;
//       drawRecImage(recX,recY,200,200);
       QApplication::processEvents();
   }
//   createImageWithOverlay(baseImage, recImage);
}

void Widget::AddRecInThread(Widget *_widget)
{
//    MYDATA* mydata = (MYDATA*)lpParameter;
//    ShipSlic* mymap = mydata->myArray;

    int threadID = _widget->threadId++;
    int temp = (int) _widget->sdr.getDetectNumber()/4;
    int total = _widget->sdr.getDetectNumber();
    for (int i=0; i<=temp; i++){
        int j = 4*i+threadID;
        if(j>=total)
            continue;
        //int j=i;
        //qDebug()<<"线程ID号为 "<<threadID<<"当前正在执行第"<<j<<"个切片";
        double x = _widget->slices[j].getX();
        double y = _widget->slices[j].getY();
        double topLeftX = _widget->slices[j].getTopLeftX();
        double topLeftY = _widget->slices[j].getTopLeftY();
        double bottomRightX = _widget->slices[j].getBottomRightX();
        double bottomRightY = _widget->slices[j].getBottomRightY();

        _widget->recInfo[j][0] = _widget->getPixel(topLeftX);
        _widget->recInfo[j][1] = _widget->getPixel(_widget->blockY2allY(j));//缩略图里的信息
        _widget->recInfo[j][2] = _widget->getRecLength(topLeftX);
        _widget->recInfo[j][3] = _widget->getRecLength(_widget->blockY2allY(j));//放大图里的信息
        _widget->recInfo[j][4] = _widget->getRecLength(fabs(bottomRightX - topLeftX));
        _widget->recInfo[j][5] = _widget->getRecLength(fabs(bottomRightY - topLeftY));//放大图里的方框宽与高
        double tmp = _widget->getRecLength(fabs(bottomRightY - topLeftY));
        qDebug()<<"t: "<<j
              <<fabs(bottomRightY - topLeftY)<<"\t"<<tmp
             <<"\t画框的高: "<<_widget->recInfo[j][5];

        //cout<<setprecision(9)<<"ValidationName: "<<ValidationName<<"     centerLonLat: "<<centerLon<<","<<centerLat<<"        leftTop: "<<leftTop<<"            rightBottom: "<<rightBottom<<endl;
        //cout<<"j:"<<j<<"ValidationName: "<<_widget->slices[j].getValidationName()<<"topLeftX:"<<topLeftX
           //<<"blockY2allY(j):"<<_widget->blockY2allY(j)<<"recInfo[t][2]: "<<_widget->recInfo[j][2]<<"         recInfo[t][3]:"<<_widget->recInfo[j][3]<<endl;
        //qDebug()<<"width: "<<_widget->recInfo[j][4]<<"  height:"<<_widget->recInfo[j][5];
        //_widget->drawRecImage(recX,recY,200,200);
    }
}

void Widget::AddRec()
{
    ui->label->setText("正在绘制切片");

    const int THREAD_NUM = 4;
    HANDLE handle[THREAD_NUM];
    threadId = 0;

    for(int t=0; t<THREAD_NUM; t++)
    {
        handle[t] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)AddRecInThread, this, 0, NULL);
    }
    for(int t=0; t<THREAD_NUM; t++)
    {
        CloseHandle(handle[t]);
    }

    addRecInSmall();
    addRecInBig();

    ui->label->setText(QString::fromStdString(lockFileName));
    threadId = 0;
}

void Widget::addRecInSmall()//在缩略图中加方框
{
    for(int t=0; t<sdr.getDetectNumber(); t++)
    {
        addRecInPic1(recInfo[t][0],recInfo[t][1]);
        //qDebug()<<"gj";
    }
}

void Widget::addRecInBig()//在兴趣域放大区中加方框
{
    for(int t=0; t<sdr.getDetectNumber(); t++)
    {
        drawRecImage(recInfo[t][2],recInfo[t][3],recInfo[t][4],recInfo[t][5]);
    }
    createImageWithOverlay(baseImage, recImage);
}

void Widget::reCalcul()//重新计算缩略图中的数值以便画框
{
    ui->label->setText("正在绘制切片");

    for(int j=0; j<sdr.getDetectNumber(); j++)
    {
        double x = slices[j].getX();
        double y = slices[j].getY();

        recInfo[j][0] = getSPosX(x,y);
        recInfo[j][1] = getSPosY(x,y);//缩略图里的信息

    }
    addRecInSmall();
    ui->label->setText(QString::fromStdString(lockFileName));
}

void Widget::addRecInPic1(double x, double y)
{
    ui->pic1->addRec(x,y);
}

void Widget::drawRecImage(int x, int y, int width, int height)
{
    QPainter painter;
    painter.begin(&recImage);
    painter.setPen(QPen(QColor(0,107,22),3));
    painter.drawRect(x,y,width,height);
    painter.end();
//    ui->pic1->loadPixmap = QPixmap::fromImage(recImage);
}

void Widget::createImageWithOverlay(QImage underImage, QImage overlayImage)
{

    overlayImage = overlayImage.scaled(baseImage.size(),Qt::KeepAspectRatioByExpanding);

    QImage imageWithOverlay = QImage(overlayImage);
    QPainter painter(&imageWithOverlay);

    painter.setCompositionMode(QPainter::CompositionMode_DestinationOver);
    painter.drawImage(0, 0, underImage);

    painter.end();

    ui->pic1->loadPixmap = QPixmap::fromImage(imageWithOverlay);
}

void Widget::slotItemDoubleClicked(QListWidgetItem *item)
{
//  qDebug()<<item->text();
    string fileName = item->text().toStdString();
    QTableWidgetItem *tmp = ui->sliceTable->item(Map[fileName], 0);
    //qDebug()<<"Map[fileName]: "<<Map[fileName];
    ui->sliceTable->setCurrentItem(tmp);
    // 这儿需要写代码做一个判断，原来是什么，需要变色
   if(slices[Map[fileName]].getProbability()==0)
   {
       item->setBackgroundColor(QColor(45, 114, 152));
       slices[Map[fileName]].setProbability(1);
//       //qDebug()<<QString::fromStdString(fileName)<<": "<<slices[Map[fileName]].getProbability();
   }
   else
   {
       item->setBackgroundColor(Qt::white);
       slices[Map[fileName]].setProbability(0);
//       //qDebug()<<QString::fromStdString(fileName)<<": "<<slices[Map[fileName]].getProbability();
   }
   if(ui->pic2->isShowJW == true)
   {
       ui->pic1->moveRec(getPosX(slices[Map[fileName]].getX(),slices[Map[fileName]].getY()),getPosY(slices[Map[fileName]].getX(),slices[Map[fileName]].getY()));
   }
}

void Widget::slotItemClicked(QListWidgetItem *item)
{
    string fileName = item->text().toStdString();
    QTableWidgetItem *tmp = ui->sliceTable->item(Map[fileName], 0);
    //qDebug()<<"Map[fileName]: "<<Map[fileName];
    ui->sliceTable->setCurrentItem(tmp);
    if(ui->pic2->isShowJW == true)
    {
        cout<<"fileName: "<<fileName<<endl;
        qDebug()<<"这是第"<<Map[fileName]<<"个切片，从它获取到的经纬度为："<<slices[Map[fileName]].getX()<<"\t"<<slices[Map[fileName]].getY();
        //qDebug()<<"输出每个切片的经纬度："<<slices[i].getX()<<"\t"<<slices[i].getY();
        ui->pic1->moveRec(getPosX(slices[Map[fileName]].getX(),slices[Map[fileName]].getY()),getPosY(slices[Map[fileName]].getX(),slices[Map[fileName]].getY()));
    }
}

//double getPixels(double &jnum,double &wnum)//根据经纬度获得在原图中的像素位置
//{
//    coordTransInverse->Transform(1, &jnum, &wnum);

//}


double Widget::getPosX(double jnum, double wnum)
{
    qDebug()<<"初始值："<<jnum<<"\t"<<wnum;
    coordTransInverse->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform[5] * (jnum - adfGeoTransform[0]) -adfGeoTransform[2] * (wnum - adfGeoTransform[3])) / dTemp + 0.5;
    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize*ui->pic1->labelWidth - ui->pic1->recWidth/2 ;

    //double jj = fabs(rightj - leftj);
    //double x = ui->pic1->labelWidth/jj * fabs(jnum - leftj) - ui->pic1->recWidth/2;
    //qDebug()<<"ui->pic1->labelWidth:"<<ui->pic1->labelWidth<< "   jj:"<<jj<<"   fabs(jnum - leftj): "<<fabs(jnum - leftj)<<"  ui->pic1->recWidth/2: "<<ui->pic1->recWidth/2;
    //qDebug()<<"jnum:"<<jnum <<"  x:"<<x;
    return x;

}

double Widget::getPosY(double jnum, double wnum)
{
    coordTransInverse->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform[1]*(wnum - adfGeoTransform[3]) -adfGeoTransform[4]*(jnum - adfGeoTransform[0])) / dTemp + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize*ui->pic1->labelWidth - ui->pic1->recHeight/2 ;

    //double ww = fabs(topw - bottomw);
    //double y = ui->pic1->labelHeight/ww * fabs(wnum - topw) - ui->pic1->recHeight/2;
    //qDebug()<<"ui->pic1->labelHeight:"<<ui->pic1->labelHeight<< "   ww:"<<ww<<"   fabs(wnum - topw): "<<fabs(wnum - topw)<<"  ui->pic1->recWidth/2: "<<ui->pic1->recHeight/2;
    //qDebug()<<"wnum:"<<wnum <<"  y:"<<y ;
    return y;

}

double Widget::getSPosX(double jnum, double wnum)
{
    //qDebug()<<"初始jnum: "<<jnum;
    coordTransInverse->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform[5] * (jnum - adfGeoTransform[0]) -adfGeoTransform[2] * (wnum - adfGeoTransform[3])) / dTemp + 0.5;
    double x = Xpixel/nXSize*ui->pic1->labelWidth - ui->pic1->sRecWidth/2 ;


    //double jj = fabs(rightj - leftj);
    //double x = ui->pic1->labelWidth/jj * fabs(jnum - leftj) - ui->pic1->sRecWidth/2;
    //qDebug()<<"nXSize"<<nXSize<<"ui->pic1->labelWidth:"<<ui->pic1->labelWidth<<"  ui->pic1->recWidth/2: "<<ui->pic1->recWidth/2;
    //qDebug()<<"jnum:"<<jnum <<"  x:"<<x;
    return x;

}

double Widget::getSPosY(double jnum,double wnum)
{

    coordTransInverse->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform[1]*(wnum - adfGeoTransform[3]) -adfGeoTransform[4]*(jnum - adfGeoTransform[0])) / dTemp + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize*ui->pic1->labelWidth - ui->pic1->sRecHeight/2 ;

    //double ww = fabs(topw - bottomw);
    //double y = ui->pic1->labelHeight/ww * fabs(wnum - topw) - ui->pic1->sRecHeight/2;
    //qDebug()<<"ui->pic1->labelHeight:"<<ui->pic1->labelHeight<< "   ww:"<<ww<<"   fabs(wnum - topw): "<<fabs(wnum - topw)<<"  ui->pic1->recWidth/2: "<<ui->pic1->recHeight/2;
    //qDebug()<<"wnum:"<<wnum <<"  y:"<<y ;
    return y;
}

double Widget::getPixel(double pixel)//根据像素位置得到在缩略图中的位置
{
    double sPixel = pixel/nXSize*ui->pic1->labelWidth;
    return sPixel;
}

double Widget::getRecPosX(double jnum,double wnum)
{
    coordTransInverse->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform[5] * (jnum - adfGeoTransform[0]) -adfGeoTransform[2] * (wnum - adfGeoTransform[3])) / dTemp + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize*recImage.width();
    //qDebug()<<"验证大图坐标是否换算成正确的方框图坐标: "<<Xpixel;
    //qDebug()<<"  nsize: "<<nXSize<<"        recImage.width(): "<<recImage.width();
    return x;
}

double Widget::getRecPosY(double jnum, double wnum)
{
    coordTransInverse->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform[1]*(wnum - adfGeoTransform[3]) -adfGeoTransform[4]*(jnum - adfGeoTransform[0])) / dTemp + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize*recImage.width();
    return y;
}


double Widget::getRecLength(double length)//由像素点得到标框长度
{
    double recLength = length * recImage.width() /nXSize ;
    //qDebug()<<"Pos: "<<length<<"     recImage.width: "<<recImage.width()<<"    nXSize: "<<nXSize<<"   recLength: "<<recLength;
    return recLength;
}



void Widget::on_ztBtn_clicked()
{
   forbidUI();
   if(tmp[0]!=3)//没有任务被打开
   {
       QMessageBox::information(this,
                                tr("error"),
                                tr("当前没有可制图的任务。"));
       cancelForbidUI();
       return;
   }
   QWidget::setCursor(Qt::WaitCursor);
   bool mark = tools.draft(sdr);//制图通知
   //mark为false时则提醒用户已经断网啦
   if(mark==false)
   {
       QMessageBox::information(this,
                                tr("错误"),
                                tr("服务器无法连接。two"));
       cancelForbidUI();
       QWidget::setCursor(Qt::ArrowCursor);
       return;
   }

   QWidget::setCursor(Qt::ArrowCursor);
   cancelForbidUI();
   QMessageBox::information(this,
                            tr("information"),
                            tr("Success."));
   return;
}

void Widget::on_tjBtn_clicked()
{
   forbidUI();
   if(tmp[0]!=3)//没有任务被打开
   {
       QMessageBox::information(this,
                                tr("error"),
                                tr("当前没有可提交的任务。"));
       cancelForbidUI();
       return;
   }
   QWidget::setCursor(Qt::WaitCursor);
   sdr.setSlices(slices);
   tools.setSliceInf(sdr);
   bool mark = tools.complete();//切片虚警标注完成，完成xml文件的上传
   //mark为false时则提醒用户已经断网啦
   if(mark==false)
   {
       ui->label->setText("无法接连服务器，请稍后重试");
       QMessageBox::information(this,
                                tr("错误"),
                                tr("服务器无法连接。three"));
       cancelForbidUI();
       QWidget::setCursor(Qt::ArrowCursor);
       return;
   }
   QWidget::setCursor(Qt::ArrowCursor);
   cancelForbidUI();
   QMessageBox::information(this,
                            tr("information"),
                            tr("Success."));
   return;
}

void Widget::forbidUI()
{
   ui->dkBtn->setEnabled(false);
   ui->tjBtn->setEnabled(false);
   ui->ztBtn->setEnabled(false);
   ui->gbBtn->setEnabled(false);
   ui->zjBtn->setEnabled(false);
   disconnect(ui->sliceList, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked(QListWidgetItem*)));
}

void Widget::cancelForbidUI()
{
   ui->dkBtn->setEnabled(true);
   ui->tjBtn->setEnabled(true);
   ui->ztBtn->setEnabled(true);
   ui->gbBtn->setEnabled(true);
   if(ui->pic2->isShowJW == true)
   {
        ui->zjBtn->setEnabled(true);
   }
   connect(ui->sliceList, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked(QListWidgetItem*)));
}

void Widget::on_gbBtn_clicked()
{
    bool mark = tools.cancelLock(lockFileName);
    //mark为false时则提醒用户已经断网啦
    if(mark==false)
    {
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("服务器无法连接。four"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }
    tmp[0] = 1;
    ui->pic2->cancelShowJW();
    ui->zjBtn->setEnabled(false);
    ui->label->setText("");
    ui->info->setText("经纬度");
    ui->pic1->resize(QSize(0,0));
    ui->widget1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->pic2->resize(QSize(0,0));
    ui->widget2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->pic1->cancelShowRec();
//    ui->pic1->scaleFlag = 10;
    ui->sliceList->clear();
    ui->sliceTable->clearContents();
    ui->sliceTable->setRowCount(0);
    adfGeoTransform[1] = 1;
    adfGeoTransform[5] = 1;
    lockFileName = "";
    recImage = whiteImage;
    ui->pic1->recPath = ui->pic1->whitePath;
    blockNumber = -1;
    blockHeight = -1;

}

void Widget::closeEvent(QCloseEvent *event)
{
    QMessageBox::StandardButton button;

    button=QMessageBox::question(this,tr("退出程序"),QString(tr("确认退出程序")),QMessageBox::Yes|QMessageBox::No);
    if(button==QMessageBox::No)
    {
        event->ignore(); // 忽略退出信号，程序继续进行
    }
    else if(button==QMessageBox::Yes)
    {
        if( tmp[0] != 1)
        {
            bool mark = tools.cancelLock(lockFileName);
            tmp[0] = 1;
            //mark为false时则提醒用户已经断网啦
            if(mark==false)
            {
                QMessageBox::information(this,
                                         tr("错误"),
                                         tr("服务器无法连接。five"));
                cancelForbidUI();
                QWidget::setCursor(Qt::ArrowCursor);
                return;
            }
        }
        event->accept(); // 接受退出信号，程序退出
    }
}

void Widget::on_zjBtn_clicked()
{
    ui->pic2->isShowRec = true;
    ui->pic2->toRepaint();
}

void Widget::onSliceCapture(QPixmap captureImage, QPointF topLeft, QPointF bottomRight)
{
//    qDebug()<<"接受到了信号";
    QMessageBox::StandardButton button;
    button=QMessageBox::question(this,tr("新增切片"),QString(tr("是否确认增加此切片？")),QMessageBox::No|QMessageBox::Yes);
    if(button==QMessageBox::No)
    {
        ui->pic2->isFinishCapture = false;
        return;
    }
    else if(button==QMessageBox::Yes)
    {
        ui->pic2->isFinishCapture = false;
        //我要获取这些信息：复制得到的图片，矩形左上和右下坐标并换算成经纬度
        double topLeftX = topLeft.x();
        double topLeftY= topLeft.y();
        double bottomRightX = bottomRight.x();
        double bottomRightY = bottomRight.y();
        double topLeftJ = getJ(topLeftX);
        double topLeftW = getW(topLeftY);
        double bottomRightJ = getJ(bottomRightX);
        double bottomRightW = getW(bottomRightY);
        string topLeftPixels = doubleToString(topLeftW) + "," + doubleToString(topLeftJ);
        string bottomRightPixels = doubleToString(bottomRightW) + "," + doubleToString(bottomRightJ);

        double recWidth = getRecLength(fabs(bottomRightJ-topLeftJ));
        double recHeight = getRecLength(fabs(bottomRightW-topLeftW));//因为是像素值，得先进行处理
        topLeftJ  = adfGeoTransform[0]+ topLeftJ  * adfGeoTransform[1];
        bottomRightJ  = adfGeoTransform[0]+ bottomRightJ  * adfGeoTransform[1];
        topLeftW = adfGeoTransform[3]+ topLeftW * adfGeoTransform[5];
        bottomRightW = adfGeoTransform[3]+ bottomRightW * adfGeoTransform[5];

        coordTrans->Transform(1, &topLeftJ, &topLeftW);
        coordTrans->Transform(1, &bottomRightJ, &bottomRightW);//至此，所有经纬度信息处理完毕

        double centerJ = (topLeftJ + bottomRightJ)/2;
        double centerW = (topLeftW + bottomRightW)/2;

        //接下来要做的：1.sliceList中新增一个，包括图像+名称；2.sliceTable中新增一个，包括N多信息; 3.用学长的接口，把他需要的数据给他; 4.新增切片保存到本地,给缩略图和放大图加框
        //qDebug()<<"for test";
        //完成2的内容
        string centerlonlat = doubleToString(centerJ) + "_" + doubleToString(centerW);
        string shipname = centerlonlat + ".tiff";
        string lefttop = doubleToString(topLeftJ) + "_" + doubleToString(topLeftW);
        string leftbottom = doubleToString(topLeftJ) + "_" + doubleToString(bottomRightW);
        string righttop = doubleToString(bottomRightJ) + "_" + doubleToString(topLeftW);
        string rightbottom = doubleToString(bottomRightJ) + "_" + doubleToString(bottomRightW);
//        Map[shipname] = sdr.getDetectNumber();
        listSlice(shipname, centerlonlat, lefttop, leftbottom, righttop, rightbottom);

        QString shipName = QString::fromStdString(shipname);

        ui->pic1->addRec(getSPosX(centerJ,centerW),getSPosY(centerJ,centerW));
        double recX = getRecPosX(topLeftJ, topLeftW);
        double recY = getRecPosY(topLeftJ,topLeftW);
        drawRecImage(recX,recY,recWidth,recHeight);
        createImageWithOverlay(baseImage, recImage);

        //完成1的内容
        addListItem(captureImage, shipName);

        //完成4的内容
        loadNewSlice(captureImage, shipName);

        string blockOrder = "-1";
        string Array[] = {lefttop, leftbottom, righttop, rightbottom, centerlonlat,topLeftPixels,bottomRightPixels,blockOrder};
        tools.AppendRecord(&sdr, Array);
        slices = sdr.getSlices();
        Map = tools.getSliceInf(sdr);//重新获得信息

    }
}

double Widget::blockY2allY(int i)//根据第几个切片由分块时的像素点Y坐标得到全图时的像素点Y坐标
{
    int blockOrder = slices[i].getBlockOrder();//切片在第几块上,我这里是从第0块开始计的，需要和师兄确认
    //blockHeight = nYSize/blockNumber;//最好在读图的时候把它就算出来
    int y = slices[i].getTopLeftY();
    double deviation;//由于重叠产生的偏差
    if( blockOrder == -1 )
    {
        return y;
    }
    else if( blockOrder == 0 )
    {
        deviation = 0;
    }
    else deviation = 100;
    double allY = y - deviation + blockOrder * blockHeight;
    //qDebug()<<"nYSize: "<<nYSize<<"blockNumber: "<<blockNumber<<"blockHeight: "<<blockHeight;
    qDebug()<<"i:" <<i<<"\t初始Y:"<<y<<"\tblockOrder: "<<blockOrder<<"\tdeviation: "<<deviation<<"\tblockHeight: "<<blockHeight<<"\tallY:"<<allY;
    return allY;
}

double Widget::allY2BlockY(double y)//由全图时的像素点Y坐标得到分块时的像素点Y坐标
{
    //这一部分暂时用不上
    int blockNumber;//分块的个数
    //blockHeight = nYSize/blockNumber;//最好在读图的时候把它就算出来
    int blockOrder;//切片在第几块上,我这里是从第0块开始计的，需要和师兄确认
    double deviation;//由于重叠产生的偏差
    if( blockOrder == -1 )
    {
        return y;
    }
    else if( blockOrder == 0 )
    {
        deviation = 0;
    }
    else deviation = 100;
    double BlockY = y - deviation + blockOrder * blockNumber;
    return BlockY;
}

void Widget::addListItem(QPixmap captureImage, QString fileName)
{
    QListWidgetItem *tmp = new QListWidgetItem(QIcon(captureImage.scaled(QSize(110,110))),fileName);
    //qDebug()<<"fileName: "<<fileName<<"  map[fileName]: "<<Map[fileName.toStdString()]<<"  Probability: "<<slices[Map[fileName.toStdString()]].getProbability();
    tmp->setBackgroundColor(QColor(45, 114, 152));
    tmp->setSizeHint(QSize(130,130));
    ui->sliceList->addItem(tmp);
}

void Widget::loadNewSlice(QPixmap capturePixmap, QString fileName)
{
    capturePixmap.save( sliceFolder+"/" + fileName,0,-1);
}

string Widget::doubleToString(double num)
{
    char str[256];
    sprintf(str, "%lf", num);
    string result = str;
    return result;
}

void Widget::paintEvent(QPaintEvent *)
{
    if(tmp[0] == 3)
    {
//        qDebug()<<ui->widget1->size();
        QImage imgScaled = imgAll.scaled(ui->widget1->size(),Qt::KeepAspectRatio);
        ui->pic1->resize(imgScaled.size());
        ui->pic1->move((ui->widget1->width()-ui->pic1->width())/2,(ui->widget1->height()-ui->pic1->height())/2);
        ui->pic1->labelWidth = imgScaled.width();
        ui->pic1->labelHeight = imgScaled.height();
        ui->pic1->setPixmap(QPixmap::fromImage(imgScaled));
        //ui->pic1->recPath = ui->pic1->whitePath;
        //reCalcul();
    }
}
