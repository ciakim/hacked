﻿#ifndef STRCONVERT_H
#define STRCONVERT_H
#include<qt_windows.h>
#include<string>
#include<vector>
using namespace std;
class StrConvert
{
public:

    StrConvert();

    LPCWSTR CharToLPCWSTR(char* tmp);

    char* ConstToChar(const char* tmp);

    char* IntegerToString(int temp);

    void split(string& s, string& delim, vector<string>* ret);

    string DoubleToStr(double tmp);

    void CharToTchar (const char * _char, TCHAR * tchar);

    char* WCharToChar(WCHAR *s);
};

#endif // STRCONVERT_H
