﻿#include "ftpmanager.h"
#include <WinInet.h>
#include "strconvert.h"
#include <iostream>
#include <QDir>
#pragma comment(lib,"WinInet.lib")
using namespace std;
FTPManager::FTPManager()
{
    szServer = TEXT("10.0.0.13");

    result = "result/";

    szUser = TEXT("f321");

    szPwd = TEXT("123456");

    lcDirectory = "c:/sharefolder/";
}
bool FTPManager::Connection(){

    hIntSession = InternetOpen(TEXT(""), INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);

    if(hIntSession == NULL){
        cout<<"ftp communication fail"<<endl;
        return false;
    }

    hFtpSession = InternetConnect(hIntSession,szServer,INTERNET_DEFAULT_FTP_PORT, szUser, szPwd, INTERNET_SERVICE_FTP, INTERNET_FLAG_PASSIVE, 0);

    if(hFtpSession == NULL){
        InternetCloseHandle(hIntSession);
        cout<<"ftp communication fail"<<endl;
        return false;
    }
    return true;
}

bool FTPManager::CloseConnection(){
    try{
        InternetCloseHandle(hFtpSession);
        InternetCloseHandle(hIntSession);
    }catch(string e){
        return false;
    }
    return true;
}

vector<string> FTPManager::getRemoteDirections(string filepath){

    int tmp = 0;
    vector<string> files;
    Connection();
    WIN32_FIND_DATA wfd = { 0 };
    HINTERNET hFindFile = NULL;
    if (hFtpSession != NULL)
    {
        StrConvert sc;
        TCHAR* tc = new TCHAR[255];
        sc.CharToTchar(filepath.c_str(),tc);
        if (FtpSetCurrentDirectory(hFtpSession, tc))    // 可以改为szDirectory   INTERNET_FLAG_RELOAD
        {
            hFindFile = FtpFindFirstFile(hFtpSession, NULL, &wfd, INTERNET_FLAG_RELOAD, 0);
        }

        if (hFindFile != NULL)
        {
            do
            {
                if(wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {

                    const char* c = sc.WCharToChar(wfd.cFileName);
                    files.push_back(c);
                    tmp++;

                }
            }
            while (InternetFindNextFile(hFindFile, (LPVOID)&wfd));
            InternetCloseHandle(hFindFile);
        }
    }
    CloseConnection();
    return files;
}


vector<string> FTPManager::getRemoteFilename(string filepath){
    int tmp = 0;
    vector<string> files;
    Connection();
    WIN32_FIND_DATA wfd = { 0 };
    HINTERNET hFindFile = NULL;
    if (hFtpSession != NULL){
         StrConvert sc;
         TCHAR* tc = new TCHAR[255];
         sc.CharToTchar((result + filepath).c_str(),tc);
         if (FtpSetCurrentDirectory(hFtpSession, tc))   // 可以改为szDirectory
               hFindFile = FtpFindFirstFile(hFtpSession, NULL, &wfd, INTERNET_FLAG_RELOAD, 0);
         if (hFindFile != NULL){
               do {
                    if(wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY){}
                    else{
                        //_bstr_t b(wfd.cFileName);
                        const char* c = sc.WCharToChar(wfd.cFileName);
                        files.push_back(c);
                        tmp++;
                    }
             } while (InternetFindNextFile(hFindFile, (LPVOID)&wfd));
             InternetCloseHandle(hFindFile);
      }
    }
    CloseConnection();
    return files;
}

int FTPManager::CheckDir(char* Dir)
{
    QDir dir(Dir);
    if (!dir.exists()){
        QString str = Dir;
        dir.mkdir(str);
    }
    return 0;
}

bool FTPManager::removeFile(vector<string> files, string remotepath){

    bool mark = Connection();
    if(!mark) return mark;
    StrConvert sc;
    TCHAR* tc = new TCHAR[255];
    sc.CharToTchar((result + remotepath).c_str(),tc);

    bSuccess = FtpSetCurrentDirectory(hFtpSession, tc);

    if(!bSuccess){

        InternetCloseHandle(hFtpSession);

        InternetCloseHandle(hIntSession);

        return false;
    }

    int size = files.size();

    for(int i=0; i<size; i++){

        QString s = files[i].c_str();
        const wchar_t* code = reinterpret_cast<const wchar_t*>(s.utf16());
        LPCWSTR remotefile = code;

        bSuccess = FtpDeleteFile(hFtpSession, remotefile);
        if(!bSuccess) return false;
    }

    CloseConnection();

    return true;

}

bool FTPManager::uploadFile(vector<string> files, string remotepath, string localpath){

    if(!Connection()) return false;
    StrConvert sc;
    TCHAR* tc = new TCHAR[255];
    sc.CharToTchar(remotepath.c_str(),tc);
    bSuccess = FtpSetCurrentDirectory(hFtpSession, tc);

    if(!bSuccess){

        InternetCloseHandle(hFtpSession);

        InternetCloseHandle(hIntSession);

        return false;
    }

    int size = files.size();

    for(int i=0; i<size; i++){

        QString s = files[i].c_str();
        const wchar_t* code = reinterpret_cast<const wchar_t*>(s.utf16());
        LPCWSTR remotefile = code;
        cout<<files[i]<<endl;
        QString sp = (localpath + files[i]).c_str();

        const wchar_t* encode = reinterpret_cast<const wchar_t*>(sp.utf16());
        LPCWSTR localfile = encode;
        bool temp = FtpPutFile(hFtpSession, localfile, remotefile ,FTP_TRANSFER_TYPE_BINARY, 0);
        cout<<temp<<endl;
    }
    CloseConnection();

    return true;
}

//下载文件
bool FTPManager::downloadFile(vector<string> &files, string filepath){

    //qDebug()<<<<endl;
    Connection();
    StrConvert sc;

    TCHAR* tc = new TCHAR[255];
    sc.CharToTchar((result + filepath).c_str(),tc);

    bSuccess = FtpSetCurrentDirectory(hFtpSession, tc);

    if(!bSuccess){

        InternetCloseHandle(hFtpSession);

        InternetCloseHandle(hIntSession);

        return false;
    }

    int size = files.size();

    for(int i=0; i<size; i++){

        char *tmp = new char[100];
        strcpy_s(tmp,100, files[i].c_str());

        char* localPath = new char[255];
        strcpy_s(localPath, 255, lcDirectory.c_str());
        strcat_s(localPath, 255, filepath.c_str());
        //查看文件夹是否存在，不存在则创建文件夹
        if(i == 0)
            CheckDir(localPath);

        strcat_s(localPath, 255, tmp);

        QString sp = localPath;

        const wchar_t* encode = reinterpret_cast<const wchar_t*>(sp.utf16());
        LPCWSTR wszClassName = encode;

        QString s = tmp;
        const wchar_t* code = reinterpret_cast<const wchar_t*>(s.utf16());
        LPCWSTR filename = code;
        FtpGetFile(hFtpSession, filename, wszClassName, TRUE, FILE_ATTRIBUTE_NORMAL, FTP_TRANSFER_TYPE_BINARY, 0);
    }

    CloseConnection();

    return true;
}
