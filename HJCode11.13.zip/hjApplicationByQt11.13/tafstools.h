﻿#ifndef TAFSTOOLS_H
#define TAFSTOOLS_H

#include <qt_windows.h>
#include <QFileInfoList>
#include "ShipDectResult.h"
#include "strconvert.h"
#include <string>
#include "ftpmanager.h"
#include "tinyxml.h"
#include <sstream>
#include <string>
#include <map>
#include <QString>
using namespace std;

class TAFSTools
{
private:
        TCHAR* szCurDir;
        string draftDirectory;        //远程路径
        string lcDirectory;		   //本地路径
        string resultDirectory;
        FTPManager ftp;
        string xmlFile;
        string image;
        ShipDectResult sdr;
        StrConvert sc;
public:
        TAFSTools();
        bool SetNode(TiXmlElement* element, string key, string value);
        bool AppendRecord(ShipDectResult* sdr, string* Array);
        ShipDectResult loadFiles(string path,int* tmp, bool& mark);   //图像加载
        bool setSliceInf(ShipDectResult sdr);   //切片信息更新
        bool draft(ShipDectResult sdr);          //制图
        QFileInfoList findFolders(string path);
        string createNoticeXML(ShipDectResult sdr, string detxml);
        ShipDectResult AnalysisShipDectResultXML(string xmlFile);
        string findXML(vector<string> files);
        void UpdateShipDectResultXML(char* inputFile,ShipDectResult* sdr);
        bool complete();
        string ftoa(double value);
        void delete_dir(string path);
        char* check(const char* tmp);
        map<string,int> getSliceInf(ShipDectResult sdr);
        bool removeFolderContent(const QString folderDir);
        bool cancelLock(string remotepath);
};

#endif // TAFSTOOLS_H
