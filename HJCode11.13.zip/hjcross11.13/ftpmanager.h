﻿#ifndef FTPMANAGER_H
#define FTPMANAGER_H

#include <qt_windows.h>
#include <WinInet.h>
#include <vector>
#include <string>
using namespace std;

class FTPManager
{
private:
    BOOL bSuccess;

    HINTERNET hIntSession;

    HINTERNET hFtpSession;

    LPCWSTR szServer;

    LPCWSTR szUser;

    LPCWSTR szPwd;

    LPCWSTR draftDirectory;

    DWORD dwCurDir;

    string lcDirectory;

public:
    FTPManager();
        //远程连接
    bool Connection();
        //获得ftp文件夹下的文件名
    vector<string> getRemoteFilename(string filepath);
        //上传文件
    bool CloseConnection();

    bool uploadFile(vector<string> files, string remotepath, string localpath);

    bool downloadFile(vector<string> &files, string filepath);

    bool removeFile(vector<string> files, string remotepath);

    vector<string> getRemoteDirections(string filepath);

    int CheckDir(char* Dir);
};

#endif // FTPMANAGER_H
