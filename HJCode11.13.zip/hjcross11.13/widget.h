﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QListWidget>
#include <QCloseEvent>
#include "TAFSTools.h"
#include "mylabel.h"
#include "gdal_priv.h"
#include "proj_api.h"
#include "ogr_spatialref.h"
#include <math.h>
#include <QDesktopWidget>
#include <QApplication>

#pragma execution_character_set("utf-8")
using namespace std;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    void showPic1(QString fileName);
    void showPic2(QString fileName);
    void showTable1(ShipSlic *slices);
    void showTable2(ShipSlic *slices);
    void listTable1(string shipname, string centerlonlat, string lefttop, string leftbottom, string righttop, string rightbottom);
    void listTable2(string shipname, string centerlonlat, string lefttop, string leftbottom, string righttop, string rightbottom);
    void listSlicePic1(QString filePath);
    void listSlicePic2(QString filePath);
    void openXML(QString fileName);
    void exponential_16to8(const char *inFilename, const char *dstFilename);
    void forbidUI();
    void cancelForbidUI();
    int search1(string fileName);
    int search2(string fileName);

    void closeEvent(QCloseEvent *event);


    int* tmp1 = new int[1];//tmp[1]=3,已经有任务打开，需要关闭；为0，该任务有锁；为2，该任务已经被下载；默认为1
    int* tmp2 = new int[1];

    OGRSpatialReference fRef1, tRef1, fRef2, tRef2;
    int nXSize1, nYSize1, nXSize2, nYSize2;
    OGRCoordinateTransformation *coordTrans1, *coordTrans2;
    OGRCoordinateTransformation *coordTransInverse1, *coordTransInverse2;
    double topw1, bottomw1, leftj1, rightj1;
    double topw2, bottomw2, leftj2, rightj2;//获得图片经纬度
    double mouseJ1, mouseW1, mouseJ2, mouseW2; //获得鼠标经纬度
//    double picWidth, picHeight;
    double adfGeoTransform1[6];
    double adfGeoTransform2[6];
    double dTemp1;//用于经纬度变坐标
    double dTemp2;//用于经纬度变坐标
    QString sliceFolder1;//用来记录切片应该被保存的文件夹
    QString sliceFolder2;//用来记录切片应该被保存的文件夹
    double getPixel1(double pixel);//根据像素位置得到在缩略图中的位置
    double getPixel2(double pixel);
    double getRecLength1(double lenght);//根据像素点获得在方框图中的位置&长度
    double getRecLength2(double lenght);//根据像素点获得在方框图中的位置&长度
    double getPosX1(double jnum,double wnum);//根据切片经纬度在缩略图中定位
    double getPosY1(double jnum,double wnum);
    double getPosX2(double jnum,double wnum);//根据切片经纬度在缩略图中定位
    double getPosY2(double jnum,double wnum);
    void getMouseJ1(double mouseX);//根据鼠标位置获取该位置经纬度
    void getMouseW1(double mouseY);
    void getMouseJ2(double mouseX);//根据鼠标位置获取该位置经纬度
    void getMouseW2(double mouseY);
    double getJ1(double x);//任意的坐标来算经纬度，这里是用于新增切片的
    double getW1(double y);
    double getJ2(double x);//任意的坐标来算经纬度，这里是用于新增切片的
    double getW2(double y);
    double getSPosX1(double jnum,double wnum);//根据切片经纬度在缩略图中定位小框
    double getSPosY1(double jnum,double wnum);
    double getSPosX2(double jnum,double wnum);//根据切片经纬度在缩略图中定位小框
    double getSPosY2(double jnum,double wnum);
    double getRecPosX1(double jnum,double wnum);//根据切片经纬度在方框图中定位（获取的是中心点位置）
    double getRecPosY1(double jnum,double wnum);
    double getRecPosX2(double jnum,double wnum);//根据切片经纬度在方框图中定位（获取的是中心点位置）
    double getRecPosY2(double jnum,double wnum);
    QImage baseImage1;//原始图像，也是背景图
    QImage baseImage2;//原始图像，也是背景图
    QImage recImage1;//标志着船的方框图，也是覆盖图
    QImage recImage2;//标志着船的方框图，也是覆盖图
    QImage whiteImage;//一块用来用画方框的白画布
    void AddRec1();//把整个加方框的过程单独写一个函数
    void AddRec2();//把整个加方框的过程单独写一个函数
    void drawRecImage1(int x, int y, int width, int height);//给recImage添加方框,注意这里的xy是中心点坐标
    void drawRecImage2(int x, int y, int width, int height);//给recImage添加方框,注意这里的xy是中心点坐标
    void createImageWithOverlay1(QImage underImage, QImage overlayImage);//将两张图重叠显示
    void createImageWithOverlay2(QImage underImage, QImage overlayImage);//将两张图重叠显示

    void readPic1(const char* srcfile);
    void readPic2(const char* srcfile);

    void addListItem1(QPixmap captureImage, QString fileName);
    void addListItem2(QPixmap captureImage, QString fileName);
    void loadNewSlice1(QPixmap capturePixmap, QString fileName);
    void loadNewSlice2(QPixmap capturePixmap, QString fileName);
    string doubleToString(double num);


    double recInfo1[5000][6];
    double recInfo2[5000][6];
    int threadId1;
    int threadId2;
    void addRecInPic1(double x, double y);
    void addRecInPic2(double x, double y);
    static void AddRec1InThread(Widget *_widget);
    static void AddRec2InThread(Widget *_widget);

    double blockHeight1;//每一个分块的高度
    double blockHeight2;
    double overLapping1;//每一个分块重叠的像素
    double overLapping2;
    int blockNumber1;//每一张图片里分块的个数
    int blockNumber2;
    double blockY2allY1(int i,int y);//由分块时的像素点Y坐标得到全图时的像素点Y坐标
    double blockY2allY2(int i,int y);

private slots:
    void onCompleteCature1(QPixmap captureImage);
    void onCompleteCature2(QPixmap captureImage);
    void onMouseMove1(QPointF mousePoint);
    void onMouseMove2(QPointF mousePoint);//跟踪鼠标在兴趣域放大区中的位置，根据位置在界面上显示经纬度
    void onSliceCapture1(QPixmap catureImage, QPointF topLeft, QPointF bottomRight);
    void onSliceCapture2(QPixmap catureImage, QPointF topLeft, QPointF bottomRight);//确定了要增加的切片后要执行的操作
    void on_dk1Btn_clicked();
    void on_dk2Btn_clicked();
    void on_tjBtn_clicked();
    void on_zj1Btn_clicked();
    void on_zj2Btn_clicked();
    void on_ztBtn_clicked();
    void on_gbBtn_clicked();

private:
    Ui::Widget *ui;  
    TAFSTools tools;
    map<string, int> Map1;//标注数组，为1时表示是船，背景为白色，为0时表示是虚警，背景为海蓝
    ShipDectResult sdr1;
    ShipSlic *slices1;
    map<string, int> Map2;//标注数组，为1时表示是船，背景为白色，为0时表示是虚警，背景为海蓝
    ShipDectResult sdr2;
    ShipSlic *slices2;
    int type = 0;//设置当前状态，为0时在下载，为1时在提交，为2时在制图
    string lockFileName1, lockFileName2;
    QString folder;//记录文件所在的文件夹
    QImage imgAll1, imgAll2;

protected:
    void paintEvent(QPaintEvent *);

public slots:
    void slotItemDoubleClicked1(QListWidgetItem *item);
    void slotItemDoubleClicked2(QListWidgetItem *item);
    void slotItemClicked1(QListWidgetItem *item);
    void slotItemClicked2(QListWidgetItem *item);
//    void onTime();
};

#endif // WIDGET_H
