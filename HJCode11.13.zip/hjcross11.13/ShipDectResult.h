﻿#ifndef ShipDectResult_H
#define ShipDectResult_H

#include "ShipSlic.h"
#include <iostream>
using namespace std;
class ShipDectResult{
	private:
		string satellite;
		string imagingtime;
		string resolution;
		string name;
		string ID;
		string description;
		int detectNumber;
        int blockNumber;
		ShipSlic* slices;
	public:

		string getSatellite(){
			return this->satellite;
		}

		void setSatellite(string satellite){
			this->satellite = satellite;
		}

		string getImagingtime(){
			return this->imagingtime;
		}

		void setImagingtime(string imagingtime){
			this->imagingtime = imagingtime;
		}

		string getResolution(){
			return this->resolution;
		}

		void setResolution(string resolution){
			this->resolution = resolution;
		}

		string getName(){
			return this->name;
		}

		void setName(string name){
			this->name = name;
		}

		string getID(){
			return this->ID;
		}

		void setID(string ID){
			this->ID = ID;
		}

		string getDescription(){
			return this->description;
		}

		void setDetectNumber(int detectNumber){
			this->detectNumber = detectNumber;
		}

		int getDetectNumber(){
			return this->detectNumber;
		}

		void setDescription(string description){
			this->description = description;
		}

        ShipSlic* getSlices(){
			return this->slices;
		}

		void setSlices(ShipSlic* slices){
			this->slices = slices;
		}

        int getBlockNumber(){
            return this->blockNumber;
        }

        void setBlockNumber(int blockNumber){
            this->blockNumber = blockNumber;
        }
};
#endif
