﻿#ifndef ShipSlic_H
#define ShipSlic_H
#include <sstream>
#include <iostream>
#include <iomanip>
#include <math.h>
#include "PossibleResults.h"
using namespace std;
class ShipSlic{
    private:
        string resultID;
        string location;
        string centerLonLat;
        double length;
        double width;
        double area;
        double angle;
        double probability;
        string resultImagePath;
        string validationName;
        string lefttop;
        string leftbottom;
        string righttop;
        string rightbottom;
        double topLeftX;
        double topLeftY;
        double bottomRightX;
        double bottomRightY;
        int blockOrder;
        PossibleResults pr;
        double x;
        double y;
    public:
        double getX(){
            return this->x;
        }

        double getY(){
            return this->y;
        }

        string getResultID(){
            return this->resultID;
        }

        void setResultID(string resultID){
            this->resultID = resultID;
        }

        string getLocation(){
            return this->location;
        }

        void setLocation(string location){
            this->location = location;
        }

        string getCenterLonLat(){
            return this->centerLonLat;
        }

        void setCenterLonLat(string centerLonLat){
            x = atof(centerLonLat.substr(0,centerLonLat.find(",")).c_str());

            if(centerLonLat.find(", ") < centerLonLat.size()){
                y = atof(centerLonLat.substr(centerLonLat.find(", ")+2, centerLonLat.size()).c_str());
            }else if(centerLonLat.find(",") < centerLonLat.size()){
                y = atof(centerLonLat.substr(centerLonLat.find(",")+1, centerLonLat.size()).c_str());
            }
            this->centerLonLat = centerLonLat;
        }

        double getLength(){
            return this->length;
        }

        void setLength(double length){
            this->length = length;
        }

        double getWidth(){
            return this->width;
        }

        void setWidth(double width){
            this->width = width;
        }

        double getArea(){
            return this->area;
        }

        void setArea(double area){
            this->area = area;
        }

        double getAngle(){
            return this->angle;
        }

        void setAngle(double angle){
            this->angle = angle;
        }

        double getProbability(){
            return this->probability;
        }

        void setProbability(double probability){
            this->probability = probability;
        }

        string getResultImagePath(){
            return this->resultImagePath;
        }

        void setResultImagePath(string resultImagePath){
            this->resultImagePath = resultImagePath;
        }

        string getValidationName(){
            return this->validationName;
        }

        void setValidationName(string validationName){
            this->validationName = validationName;
        }

        string getLefttop(){
            return this->lefttop;
        }

        void setLefttop(string lefttop){
            this->lefttop = lefttop;
        }

        string getLeftbottom(){
            return this->leftbottom;
        }

        void setLeftbottom(string leftbottom){
            this->leftbottom = leftbottom;
        }

        string getRighttop(){
            return this->righttop;
        }

        void setRighttop(string righttop){
            this->righttop = righttop;
        }

        string getRightbottom(){
            return this->rightbottom;
        }

        void setRightbottom(string rightbottom){
            this->rightbottom = rightbottom;
        }

        PossibleResults getPR(){
            return this->pr;
        }

        void setPR(PossibleResults pr){
            this->pr = pr;
        }

        void setTopLeftX(double topLeftX){
            this->topLeftX = topLeftX;
        }

        double getTopLeftX(){
            return this->topLeftX;
        }

        void setTopLeftY(double topLeftY){
            this->topLeftY = topLeftY;
        }

        double getTopLeftY(){
            return this->topLeftY;
        }

        void setBottomRightX(double bottomRightX){
            this->bottomRightX = bottomRightX;
        }

        double getBottomRightX(){
            return this->bottomRightX;
        }

        void setBottomRightY(double bottomRightY){
            this->bottomRightY = bottomRightY;
        }

        double getBottomRightY(){
            return this->bottomRightY;
        }

        int getBlockOrder(){
            return this->blockOrder;
        }

        void setBlockOrder(int blockOrder){
            this->blockOrder = blockOrder;
        }
};
#endif
