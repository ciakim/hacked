﻿#include "widget.h"
#include "ui_widget.h"

#include <QImage>
#include <QMessageBox>
#include <QPixmap>
#include <QString>
#include <QGridLayout>
#include <QPushButton>
#include <QFileDialog>
#include <QtXml/QDomDocument>
#include <QListWidget>
#include <QListWidgetItem>
#include <QDebug>
#include <QHeaderView>
#include <QFont>
#include <QTimer>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QFont font("Times", 10, QFont::Bold);
    ui->table1->setFont(QFont("Helvetica", 11, QFont::Thin));
    ui->table2->setFont(QFont("Helvetica", 11, QFont::Thin));
    ui->label1->setText("没有任务");
    ui->label1->setStyleSheet("color:rgb(255, 255, 255);");
    ui->info1->setStyleSheet("color:rgb(255, 255, 255);");
    ui->info2->setStyleSheet("color:rgb(255, 255, 255);");
//    ui->info1->setWordWrap(true);
//    ui->info2->setWordWrap(true);
    ui->info1->setText("经纬度");
    ui->info2->setText("经纬度");
    ui->pic1->setScaledContents(true);
    ui->pic2->setScaledContents(true);
    ui->pic1->setScaledContents(true);
    ui->pic2->setScaledContents(true);
//    ui->info1->setFont(font);
//    ui->info2->setFont(font);
    ui->label2->setText("没有任务");
    ui->label2->setStyleSheet("color:rgb(255, 255, 255);");
    ui->pic1->resize(QSize(0,0));
    ui->widget1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->pic2->resize(QSize(0,0));
    ui->widget2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->picb1->resize(QSize(0,0));
    ui->widgetb1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->picb2->resize(QSize(0,0));
    ui->widgetb2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    setWindowState(Qt::WindowMaximized);
    ui->pic1->setScaledContents(true);
    ui->pic2->setScaledContents(true);//图片内容随控件大小缩放
    ui->picb1->setScaledContents(true);
    ui->picb2->setScaledContents(true);//图片内容随控件大小缩放
    ui->table1->verticalHeader()->setVisible(false);//隐藏切片表格行表头
    ui->table1->horizontalHeader()->setStretchLastSection(true);//设置切片表格充满表宽度
    ui->table1->setSelectionBehavior(QAbstractItemView::SelectRows);//每次选中即选一行
    ui->table1->setEditTriggers(QAbstractItemView::NoEditTriggers);//设置切片表格不可编辑
    ui->table2->verticalHeader()->setVisible(false);//隐藏切片表格行表头
    ui->table2->horizontalHeader()->setStretchLastSection(true);//设置切片表格充满表宽度
    ui->table2->setSelectionBehavior(QAbstractItemView::SelectRows);//每次选中即选一行
    ui->table2->setEditTriggers(QAbstractItemView::NoEditTriggers);//设置切片表格不可编辑

    ui->list1->setViewMode(QListWidget::IconMode);//将List设置成图片形式
    ui->list1->setIconSize(QSize(90,90));
    ui->list1->setResizeMode(QListWidget::Adjust);\
    ui->list1->setMovement(QListView::Static);//切片不可被拖动
    ui->list1->setMouseTracking(true);//跟踪鼠标
    ui->list2->setViewMode(QListWidget::IconMode);//将List设置成图片形式
    ui->list2->setIconSize(QSize(90,90));
    ui->list2->setResizeMode(QListWidget::Adjust);\
    ui->list2->setMovement(QListView::Static);//切片不可被拖动
    ui->list2->setMouseTracking(true);//跟踪鼠标

    ui->table1->setStyleSheet("QTableWidget::item:selected{color:white;background:#046ca5;}");
    ui->table2->setStyleSheet("QTableWidget::item:selected{color:white;background:#046ca5;}");
    ui->list1->setStyleSheet("QListWidget {show-decoration-selected: 1;}"
                                     "QListWidget::item:alternate {background: #EEEEEE;}"
                                     "QListWidget::item:selected {border: 1px solid #6398b6;}"
                                     "QListWidget::item:selected:!active {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #76b2d4, stop: 1 #6398b6);}"
                                     "QListWidget::item:selected:active {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #538dae, stop: 1 #6398b6);}"
                                     "QListWidget::item:hover {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #FAFBFE, stop: 1 #DCDEF1);}");
    ui->list2->setStyleSheet("QListWidget {show-decoration-selected: 1;}"
                                     "QListWidget::item:alternate {background: #EEEEEE;}"
                                     "QListWidget::item:selected {border: 1px solid #6398b6;}"
                                     "QListWidget::item:selected:!active {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #76b2d4, stop: 1 #6398b6);}"
                                     "QListWidget::item:selected:active {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #538dae, stop: 1 #6398b6);}"
                                     "QListWidget::item:hover {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,stop: 0 #FAFBFE, stop: 1 #DCDEF1);}");

//    ui->dk1Btn->setStyleSheet("QPushButton{background-color:white;color: black;border-radius: 10px;border: 2px groove gray;border-style: outset;}"
//                             "QPushButton:hover{background-color:#046ca5; color: black;}"
//                             "QPushButton:pressed{background-color:#00456b; border-style: inset; }" );
//    ui->dk2Btn->setStyleSheet("QPushButton{background-color:white;color: black;border-radius: 10px;border: 2px groove gray;border-style: outset;}"
//                             "QPushButton:hover{background-color:#046ca5; color: black;}"
//                             "QPushButton:pressed{background-color:#00456b; border-style: inset; }" );
//    ui->zcBtn->setStyleSheet("QPushButton{background-color:white;color: black;border-radius: 10px;border: 2px groove gray;border-style: outset;}"
//                             "QPushButton:hover{background-color:#046ca5; color: black;}"
//                             "QPushButton:pressed{background-color:#00456b; border-style: inset; }" );
//    ui->tjBtn->setStyleSheet("QPushButton{background-color:white;color: black;border-radius: 10px;border: 2px groove gray;border-style: outset;}"
//                             "QPushButton:hover{background-color:#046ca5; color: black;}"
//                             "QPushButton:pressed{background-color:#00456b; border-style: inset; }" );
    connect(ui->pic1, SIGNAL(signalCompleteCature(QPixmap)), this, SLOT(onCompleteCature1(QPixmap)));
    connect(ui->pic2, SIGNAL(signalCompleteCature(QPixmap)), this, SLOT(onCompleteCature2(QPixmap)));
    connect(ui->list1, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked1(QListWidgetItem*)));
    connect(ui->list2, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked2(QListWidgetItem*)));
    connect(ui->list1, SIGNAL(itemClicked(QListWidgetItem*)), this, SLOT(slotItemClicked1(QListWidgetItem*)));
    connect(ui->list2, SIGNAL(itemClicked(QListWidgetItem*)), this, SLOT(slotItemClicked2(QListWidgetItem*)));
    connect(ui->picb1, SIGNAL(signalMouseMove(QPointF)), this, SLOT(onMouseMove1(QPointF)));
    connect(ui->picb2, SIGNAL(signalMouseMove(QPointF)), this, SLOT(onMouseMove2(QPointF)));
    connect(ui->picb1, SIGNAL(signalWheelUp()), ui->pic1, SLOT(onWheelUp()));
    connect(ui->picb2, SIGNAL(signalWheelUp()), ui->pic2, SLOT(onWheelUp()));
    connect(ui->picb1, SIGNAL(signalWheelDown()), ui->pic1, SLOT(onWheelDown()));
    connect(ui->picb2, SIGNAL(signalWheelDown()), ui->pic2, SLOT(onWheelDown()));
    connect(ui->picb1, SIGNAL(signalSliceCapture(QPixmap,QPointF,QPointF)), this, SLOT(onSliceCapture1(QPixmap,QPointF,QPointF)));
    connect(ui->picb2, SIGNAL(signalSliceCapture(QPixmap,QPointF,QPointF)), this, SLOT(onSliceCapture2(QPixmap,QPointF,QPointF)));
    connect(ui->picb1, SIGNAL(signalDrag(QPointF,QPointF,int,int)), ui->pic1, SLOT(onSignalDrag(QPointF,QPointF,int,int)));
    connect(ui->picb2, SIGNAL(signalDrag(QPointF,QPointF,int,int)), ui->pic2, SLOT(onSignalDrag(QPointF,QPointF,int,int)));
//    QTimer *timer = new QTimer(this);
//    connect(timer, SIGNAL(timeout()), this, SLOT(onTime()));
//    timer->start(500);

    folder = "C:/sharefolder/";
    lockFileName1 = "";
    lockFileName2 = "";
    topw1=0;
    bottomw1=0;
    leftj1=0;
    rightj1=0;
    topw2=0;
    bottomw2=0;
    leftj2=0;
    rightj2=0;
    tmp1[0] = 1;
    tmp2[0] = 1;
    whiteImage = QImage(QSize(233,233),QImage::Format_ARGB32_Premultiplied);
    whiteImage.fill(Qt::transparent);    //把方框图变透明
}

Widget::~Widget()
{
    delete ui;
}

//void Widget::onTime()
//{

//    ui->dk1Btn->repaint();
//    ui->dk2Btn->repaint();
//    ui->zj1Btn->repaint();
//    ui->zj2Btn->repaint();
//    ui->ztBtn->repaint();
//    ui->tjBtn->repaint();
//    ui->label1->repaint();
//    ui->label2->repaint();
////    ui->info1->repaint();
////    ui->info2->repaint();
//    ui->pic1->repaint();
////    ui->pic2->repaint();
//    ui->widgetb1->repaint();
//    ui->widgetb2->repaint();
//    if(tmp1[0] == 3)
//    {
//        QImage imgScaled = imgAll1.scaled(ui->widget1->size(),Qt::KeepAspectRatio);
////        ui->pic1->setPixmap(QPixmap::fromImage(imgScaled));
//        ui->pic1->resize(imgScaled.size());
////        ui->pic1->move((ui->widget1->width()-ui->pic1->width())/2,(ui->widget1->height()-ui->pic1->height())/2);
//        ui->pic1->labelWidth = imgScaled.width();
//        ui->pic1->labelHeight = imgScaled.height();
//    }
//    if(tmp2[0] == 3)
//    {
//        QImage imgScaled = imgAll2.scaled(ui->widget2->size(),Qt::KeepAspectRatio);
////        ui->pic2->setPixmap(QPixmap::fromImage(imgScaled));
//        ui->pic2->resize(imgScaled.size());
////        ui->pic2->move((ui->widget2->width()-ui->pic2->width())/2,(ui->widget2->height()-ui->pic2->height())/2);
//        ui->pic2->labelWidth = imgScaled.width();
//        ui->pic2->labelHeight = imgScaled.height();
//    }
//    ui->dk1Btn->update();
//    ui->dk2Btn->update();
//    ui->zj1Btn->update();
//    ui->zj2Btn->update();
//    ui->tjBtn->update();
//    ui->label1->update();
//    ui->label2->update();
//    ui->info1->update();
//    ui->info2->update();
//    ui->pic1->update();
//    ui->pic2->update();

//}

void Widget::paintEvent(QPaintEvent *)
{
    if(tmp1[0] == 3)
    {
        QImage imgScaled = imgAll1.scaled(ui->widget1->size(),Qt::KeepAspectRatio);
//        ui->pic1->setPixmap(QPixmap::fromImage(imgScaled));
        ui->pic1->resize(imgScaled.size());
//        ui->pic1->move((ui->widget1->width()-ui->pic1->width())/2,(ui->widget1->height()-ui->pic1->height())/2);
        ui->pic1->labelWidth = imgScaled.width();
        ui->pic1->labelHeight = imgScaled.height();
        ui->pic1->setPixmap(QPixmap::fromImage(imgScaled));
    }
    if(tmp2[0] == 3)
    {
        QImage imgScaled = imgAll2.scaled(ui->widget2->size(),Qt::KeepAspectRatio);
//        ui->pic2->setPixmap(QPixmap::fromImage(imgScaled));
        ui->pic2->resize(imgScaled.size());
//        ui->pic2->move((ui->widget2->width()-ui->pic2->width())/2,(ui->widget2->height()-ui->pic2->height())/2);
        ui->pic2->labelWidth = imgScaled.width();
        ui->pic2->labelHeight = imgScaled.height();
        ui->pic2->setPixmap(QPixmap::fromImage(imgScaled));
    }
}


void Widget::showPic1(QString fileName)
{
    QImage* img=new QImage;
    if( !(img->load(fileName)) )
    {
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("该文件不存在"));
        delete img;
        return;
    }
    if(adfGeoTransform1[1] == 1 && adfGeoTransform1[5] == 1)
    {
        nXSize1 = img->width();
        nYSize1 = img->height();
        blockHeight1 = ((double)nYSize1) / blockNumber1;
        //qDebug()<<"nYSize       "<<nYSize<<"           blockNumber:"<<blockNumber<<"  blockHeight:"<<blockHeight<<endl;
    }

    QDesktopWidget *dsk = QApplication::desktop();

    imgAll1 = img->scaled(ui->widget1->size(),Qt::KeepAspectRatio);
    QApplication::processEvents();
    ui->pic1->resize(imgAll1.size());
    ui->pic1->labelWidth = imgAll1.width();
    ui->pic1->labelHeight = imgAll1.height();
    ui->pic1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);"
                            "background-color:white;");
    ui->widget1->setStyleSheet("");
    ui->picb1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);"
                            "background-color:white;");
    ui->widgetb1->setStyleSheet("");
    ui->pic1->setPixmap(QPixmap::fromImage(imgAll1));
    QApplication::processEvents();
    qDebug()<<"pic1->size(): "<<ui->pic1->size();
    ui->pic1->showRec();

    baseImage1 = img->scaled(QSize(dsk->width()*7,dsk->height()*7),Qt::KeepAspectRatioByExpanding);
    recImage1 = QImage(baseImage1.size(),QImage::Format_ARGB32_Premultiplied);
    recImage1.fill(Qt::transparent);    //把方框图变透明
    QApplication::processEvents();
    ui->pic1->loadPixmap = QPixmap::fromImage(baseImage1);
    ui->pic1->repaint();
    ui->picb1->repaint();
}

void Widget::readPic1(const char* srcfile)
{
    //qDebug()<<srcfile;
    //获取图片经纬度信息
    GDALAllRegister();
    CPLSetConfigOption("GDAL_FILENAME_IS_UTF8", "NO");   //为了支持中文路径
    GDALDataset *poDataset = (GDALDataset *)GDALOpen(srcfile, GA_ReadOnly);   //打开影像
    //projRef将会存储test.tif中的坐标信息
    //qDebug()<<"2333";
    const char* projRef = poDataset->GetProjectionRef();
    //adfGeoTransform存储一些基准点的坐标和每一个pixel表示的长度等
//    double adfGeoTransform[6];
    poDataset->GetGeoTransform(adfGeoTransform1);
    //qDebug()<< adfGeoTransform[1] << adfGeoTransform[5];

    if(adfGeoTransform1[1] == 1 && adfGeoTransform1[5] == 1)
    {
        ui->info1->setText("没有经纬度信息");
        ui->zj1Btn->setEnabled(false);
        return;
    }
    ui->picb1->showJW();

    dTemp1 = adfGeoTransform1[1] * adfGeoTransform1[5] - adfGeoTransform1[2] *adfGeoTransform1[4];

    //下面获得波段信息
    GDALRasterBand *poBand;
    poBand = poDataset->GetRasterBand(1);

    //获得图像左右、上下的像素点
    nXSize1 = poBand->GetXSize();
    nYSize1 = poBand->GetYSize();
    //qDebug()<<"像素点信息——nXSize: "<<nXSize<<"  nYSize: "<<nYSize;
    blockHeight1 = nYSize1/blockNumber1;

    //adfGeoTransform中（这里简称GT），GT[0],GT[3]是左上角坐标，GT[1],GT[5]是图像总向横向分辨率
    leftj1 = adfGeoTransform1[0];
    topw1 = adfGeoTransform1[3];
    rightj1 = adfGeoTransform1[0]+ nXSize1 * adfGeoTransform1[1];
    bottomw1 = adfGeoTransform1[3]+ nYSize1 * adfGeoTransform1[5];
    //qDebug()<<"坐标信息——leftj: "<<leftj<<"  topw: "<<topw<<"  rightj: "<<rightj<<"  bottomw: "<<bottomw;

    //将坐标信息转化为经纬度信息，需要用到proj_api.h
//    OGRSpatialReference fRef, tRef;//放到头文件里作为全局变量定义了
    char *tmp = NULL;
    //获得projRef的一份拷贝
    //由于projRef是const char*,下面的一个函数不接受，所以需要转换成非const
    tmp = (char *)malloc(strlen(projRef) + 1);
    strcpy_s(tmp, strlen(projRef)+1, projRef);

    //设置原始的坐标参数，和初始图像一致
    fRef1.importFromWkt(&tmp);
    //设置转换后的坐标
    tRef1.SetWellKnownGeogCS("WGS84");

    //坐标转换
    //OGRCoordinateTransformation *coordTrans;//放到头文件里作为全局变量定义了
    coordTrans1 = OGRCreateCoordinateTransformation(&fRef1, &tRef1);
    coordTransInverse1 = OGRCreateCoordinateTransformation(&tRef1, &fRef1);
    coordTrans1->Transform(1, &leftj1, &topw1);
    coordTrans1->Transform(1, &rightj1, &bottomw1);
    //qDebug()<<"经纬度信息——leftj: "<<leftj<<"  topw: "<<topw<<"  rightj: "<<rightj<<"  bottomw: "<<bottomw;

    GDALClose(poDataset);
    return;
}

void Widget::showPic2(QString fileName)
{
    QImage* img=new QImage;
    if( !(img->load(fileName)) )
    {
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("该文件不存在"));
        delete img;
        return;
    }

    if(adfGeoTransform2[1] == 1 && adfGeoTransform2[5] == 1)
    {
        nXSize2 = img->width();
        nYSize2 = img->height();
        blockHeight2 = ((double)nYSize2) / blockNumber2;
        //qDebug()<<"nYSize       "<<nYSize<<"           blockNumber:"<<blockNumber<<"  blockHeight:"<<blockHeight<<endl;
    }

    QDesktopWidget *dsk = QApplication::desktop();
    imgAll2 = img->scaled(ui->widget2->size(),Qt::KeepAspectRatio);
    QApplication::processEvents();
    ui->pic2->resize(imgAll2.size());
    ui->pic2->labelWidth = imgAll2.width();
    ui->pic2->labelHeight = imgAll2.height();
    ui->pic2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);"
                            "background-color:white;");
    ui->widget2->setStyleSheet("");
    ui->picb2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);"
                            "background-color:white;");
    ui->widgetb2->setStyleSheet("");
    ui->pic2->setPixmap(QPixmap::fromImage(imgAll2));
    QApplication::processEvents();
    ui->pic2->showRec();
    QApplication::processEvents();

    baseImage2 = img->scaled(QSize(dsk->width()*7,dsk->height()*7),Qt::KeepAspectRatioByExpanding);
    recImage2 = QImage(baseImage2.size(),QImage::Format_ARGB32_Premultiplied);
    qDebug()<<"recImage是不是为空："<<recImage2.isNull();
    recImage2.fill(Qt::transparent);    //把方框图变透明
    QApplication::processEvents();
    ui->pic2->loadPixmap = QPixmap::fromImage(baseImage2);
    ui->pic2->repaint();
    ui->picb2->repaint();
}

void Widget::readPic2(const char* srcfile)
{
    //qDebug()<<srcfile;
    //获取图片经纬度信息
    GDALAllRegister();
    CPLSetConfigOption("GDAL_FILENAME_IS_UTF8", "NO");   //为了支持中文路径
    GDALDataset *poDataset = (GDALDataset *)GDALOpen(srcfile, GA_ReadOnly);   //打开影像
    //projRef将会存储test.tif中的坐标信息
    //qDebug()<<"2333";
    const char* projRef = poDataset->GetProjectionRef();
    //adfGeoTransform存储一些基准点的坐标和每一个pixel表示的长度等
//    double adfGeoTransform[6];
    poDataset->GetGeoTransform(adfGeoTransform2);
    //qDebug()<< adfGeoTransform[1] << adfGeoTransform[5];

    if(adfGeoTransform2[1] == 1 && adfGeoTransform2[5] == 1)
    {
        ui->info2->setText("没有经纬度信息");
        ui->zj2Btn->setEnabled(false);
        return;
    }
    ui->picb2->showJW();

    dTemp2 = adfGeoTransform2[1] * adfGeoTransform2[5] - adfGeoTransform2[2] *adfGeoTransform2[4];

    //下面获得波段信息
    GDALRasterBand *poBand;
    poBand = poDataset->GetRasterBand(1);

    //获得图像左右、上下的像素点
    nXSize2 = poBand->GetXSize();
    nYSize2 = poBand->GetYSize();
    //qDebug()<<"像素点信息——nXSize: "<<nXSize<<"  nYSize: "<<nYSize;
    blockHeight2 = nYSize2/blockNumber2;

    //adfGeoTransform中（这里简称GT），GT[0],GT[3]是左上角坐标，GT[1],GT[5]是图像总向横向分辨率
    leftj2 = adfGeoTransform2[0];
    topw2 = adfGeoTransform2[3];
    rightj2 = adfGeoTransform2[0]+ nXSize2 * adfGeoTransform2[1];
    bottomw2 = adfGeoTransform2[3]+ nYSize2 * adfGeoTransform2[5];
    //qDebug()<<"坐标信息——leftj: "<<leftj<<"  topw: "<<topw<<"  rightj: "<<rightj<<"  bottomw: "<<bottomw;

    //将坐标信息转化为经纬度信息，需要用到proj_api.h
//    OGRSpatialReference fRef, tRef;//放到头文件里作为全局变量定义了
    char *tmp = NULL;
    //获得projRef的一份拷贝
    //由于projRef是const char*,下面的一个函数不接受，所以需要转换成非const
    tmp = (char *)malloc(strlen(projRef) + 1);
    strcpy_s(tmp, strlen(projRef)+1, projRef);

    //设置原始的坐标参数，和初始图像一致
    fRef2.importFromWkt(&tmp);
    //设置转换后的坐标
    tRef2.SetWellKnownGeogCS("WGS84");

    //坐标转换
    //OGRCoordinateTransformation *coordTrans;//放到头文件里作为全局变量定义了
    coordTrans2 = OGRCreateCoordinateTransformation(&fRef2, &tRef2);
    coordTransInverse2 = OGRCreateCoordinateTransformation(&tRef2, &fRef2);
    coordTrans2->Transform(1, &leftj2, &topw2);
    coordTrans2->Transform(1, &rightj2, &bottomw2);
    //qDebug()<<"经纬度信息——leftj: "<<leftj<<"  topw: "<<topw<<"  rightj: "<<rightj<<"  bottomw: "<<bottomw;

    GDALClose(poDataset);
    return;
}

void Widget::on_dk1Btn_clicked()
{
    bool result = tools.Preload();
    //mark为false时则提醒用户已经断网啦
    if(result==false)
    {
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("服务器无法连接。"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }
    forbidUI();
    ui->label1->setText("正在打开任务，请耐心等候，勿进行其它操作");


    QApplication::processEvents();
    QString fileQStr = QFileDialog::getExistingDirectory(this,
                                                tr("Select Task"),
                                                "c:/CrossValidation/multispectral");
    if(fileQStr.isEmpty())
    {
        cancelForbidUI();
        if(tmp1[0]==3)
        {
            ui->label1->setText(QString::fromStdString(lockFileName1));
        }
        else
        {
            ui->label1->setText(QString::fromStdString("没有任务"));
        }
        return;
    }

    QFileInfo file = QFileInfo(fileQStr);
    QString fileBaseName = file.fileName();
    string tmp = fileBaseName.toStdString();
    if(lockFileName2.length()>0)
    {
        string cprTmp1 = tmp.substr(0,tmp.length()-4);
        string cprTmp2 = lockFileName2.substr(0,lockFileName2.length()-4);
        if(cprTmp1.compare(cprTmp2))
        {
            QMessageBox::StandardButton button;
            button=QMessageBox::question(this,tr("警告"),QString(tr("打开图像可能与全色图像不对应，是否继续打开")),QMessageBox::Yes|QMessageBox::No);
            if(button==QMessageBox::No)
            {
                cancelForbidUI();
                ui->label1->setText(QString::fromStdString(lockFileName1));
                return;
            }
        }
    }

    if(tmp1[0] == 3)//已经有任务被打开了
    {
        bool result = tools.cancelLock(lockFileName1);
        if(result==false)
        {
            QMessageBox::information(this,
                                     tr("错误"),
                                     tr("服务器无法连接"));
            cancelForbidUI();
            QWidget::setCursor(Qt::ArrowCursor);
            return;
        }
        qDebug()<<"删除遗留文件";
        recImage1 = whiteImage;//更新方框图
        ui->pic1->recPath = ui->pic1->whitePath;
    }

    QWidget::setCursor(Qt::WaitCursor);

    string fileName = fileBaseName.toStdString()+"/";
    bool mark;
    sdr1 = tools.loadFiles(fileName,tmp1,mark);
    blockNumber1 = sdr1.getBlockNumber();

    //如果mark为false，则告示用户没联网并返回
    if(mark == false)
    {
        ui->label1->setText("无法接连服务器，请稍后重试");
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("服务器无法连接。"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }

    if(tmp1[0] == 0)
    {
       ui->label1->setText("该任务已在另一个客户端打开，请重新打开任务");
       QMessageBox::information(this,
                                tr("错误"),
                                tr("该任务已在另一个客户端打开"));
       cancelForbidUI();
       QWidget::setCursor(Qt::ArrowCursor);
       return;
    }

    QString dstFile(folder+fileBaseName+"/result.tiff");
    QFileInfo dstFileInfo(dstFile);
    if(!dstFileInfo.isFile())
    {
        ui->label1->setText("文件对象错误");
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("选择的任务出现错误。"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }

    lockFileName1 = fileBaseName.toStdString();


    QString inFile(folder+fileBaseName+"/"+fileBaseName+".tiff");
    QFileInfo inFileInfo(inFile);
    if(!inFileInfo.isFile())
    {
        inFile = folder+fileBaseName+"/"+fileBaseName+".TIF";
    }
    QByteArray tmp11 = inFile.toLatin1();
    char *inFilename = tmp11.data();
    readPic1(inFilename);
    QApplication::processEvents();
//    qDebug()<<inFilename;

    QByteArray tmp22 = dstFile.toLatin1();
    char *dstFilename = tmp22.data();
    qDebug()<<dstFilename;

//    exponential_16to8(inFilename, dstFilename);
    try{
        slices1 = sdr1.getSlices();
        QApplication::processEvents();
        Map1 = tools.getSliceInf(sdr1);//获得标注数组
        QApplication::processEvents();
        showPic1(dstFile);
        qDebug()<<"No Problem!";
        QApplication::processEvents();
        showTable1(slices1);//显示列表
        sliceFolder1=folder+fileBaseName+"/slices";
        listSlicePic1(sliceFolder1);//展示切片图像
    }catch(exception)
    {
        ui->label2->setText("没有任务");
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("出现异常"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }


    QApplication::processEvents();
    QWidget::setCursor(Qt::ArrowCursor);
    cancelForbidUI();
    ui->label1->setText(fileBaseName);
    tmp1[0] = 3;//已经打开图像了
    AddRec1();
//    ui->pic1->repaint();
//    ui->picb1->repaint();
}

void Widget::onCompleteCature1(QPixmap captureImage)
{
    QPixmap imgScaled = captureImage.scaled(ui->widgetb1->size(), Qt::KeepAspectRatio);
    ui->picb1->resize(imgScaled.size());
    ui->picb1->move((ui->widgetb1->width()-ui->picb1->width())/2,(ui->widgetb1->height()-ui->picb1->height())/2);
//    ui->picb1->setPixmap(imgScaled);
    ui->picb1->loadPixmap = imgScaled;
    ui->picb1->update();
}

void Widget::onCompleteCature2(QPixmap captureImage)
{
    QPixmap imgScaled = captureImage.scaled(ui->widgetb2->size(), Qt::KeepAspectRatio);
    ui->picb2->resize(imgScaled.size());
    ui->picb2->move((ui->widgetb2->width()-ui->picb2->width())/2,(ui->widgetb2->height()-ui->picb2->height())/2);
//    ui->picb2->setPixmap(imgScaled);
    ui->picb2->loadPixmap = imgScaled;
    ui->picb2->update();
}

void Widget::on_dk2Btn_clicked()
{
    bool result = tools.Preload();
    if(result==false)
    {
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("服务器无法连接。"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }
    forbidUI();
    ui->label2->setText("正在打开任务，请耐心等候，勿进行其它操作");
    qDebug()<<"dfewafsd"<<endl;


    QApplication::processEvents();
    QString fileQStr = QFileDialog::getExistingDirectory(this,
                                                tr("Select Task"),
                                                "c:/CrossValidation/panchromatic");
    if(fileQStr.isEmpty())
    {
        cancelForbidUI();
        if(tmp2[0]==3)
        {
            ui->label2->setText(QString::fromStdString(lockFileName2));
        }
        else
        {
            ui->label2->setText(QString::fromStdString("没有任务"));
        }
        return;
    }

    QFileInfo file = QFileInfo(fileQStr);
    QString fileBaseName = file.fileName();

    if(tmp2[0] == 3)//已经有任务被打开了
    {
        bool result = tools.cancelLock(lockFileName2);
        if(result==false)
        {
            QMessageBox::information(this,
                                     tr("错误"),
                                     tr("服务器无法连接。"));
            cancelForbidUI();
            QWidget::setCursor(Qt::ArrowCursor);
            return;
        }
        recImage2 = whiteImage;//更新方框图
        ui->pic2->recPath = ui->pic2->whitePath;
        qDebug()<<"删除遗留文件";
    }

    string tmp = fileBaseName.toStdString();
    if(lockFileName1.length()>0)
    {
        string cprTmp1 = tmp.substr(0,tmp.length()-4);
        string cprTmp2 = lockFileName1.substr(0,lockFileName1.length()-4);
        if(cprTmp1.compare(cprTmp2))
        {
            QMessageBox::StandardButton button;
            button=QMessageBox::question(this,tr("警告"),QString(tr("打开图像可能与多光谱图像不对应，是否继续打开")),QMessageBox::Yes|QMessageBox::No);
            if(button==QMessageBox::No)
            {
                cancelForbidUI();
                ui->label2->setText(QString::fromStdString(lockFileName2));
                return;
            }
        }
    }

    QWidget::setCursor(Qt::WaitCursor);
    QApplication::processEvents();
    string fileName = file.fileName().toStdString()+"/";
    bool mark;
    sdr2 = tools.loadFiles(fileName, tmp2, mark);
    blockNumber2 = sdr2.getBlockNumber();

    //如果mark为false，则告示用户没联网并返回
    if(mark == false)
    {
        ui->label2->setText("无法接连服务器，请稍后重试");
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("服务器无法连接。"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }

    QApplication::processEvents();

    if(tmp2[0] == 0)
    {
       ui->label2->setText("该任务已在另一个客户端打开，请重新打开任务");
       QMessageBox::information(this,
                                tr("错误"),
                                tr("该任务已在另一个客户端打开"));
       cancelForbidUI();
       QWidget::setCursor(Qt::ArrowCursor);
       return;
    }


    QString dstFile(folder+fileBaseName+"/result.tiff");
    QFileInfo dstFileInfo(dstFile);
    if(!dstFileInfo.isFile())
    {
        ui->label2->setText("文件对象错误");
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("选择的任务出现错误。"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }

    lockFileName2 = fileBaseName.toStdString();


    QString inFile(folder+fileBaseName+"/"+fileBaseName+".tiff");
    QFileInfo inFileInfo(inFile);
    if(!inFileInfo.isFile())
    {
        inFile = folder+fileBaseName+"/"+fileBaseName+".TIF";
    }
    QByteArray tmp11 = inFile.toLatin1();
    char *inFilename = tmp11.data();
    readPic2(inFilename);
    QApplication::processEvents();


    QByteArray tmp22 = dstFile.toLatin1();
    char *dstFilename = tmp22.data();
    qDebug()<<dstFilename;

//    exponential_16to8(inFilename, dstFilename);
    try{
        slices2 = sdr2.getSlices();
        QApplication::processEvents();
        Map2 = tools.getSliceInf(sdr2);//获得标注数组
        QApplication::processEvents();
        showPic2(dstFile);
        QApplication::processEvents();
        showTable2(slices2);//显示列表
        QApplication::processEvents();
        sliceFolder2=folder+fileBaseName+"/slices";
        QApplication::processEvents();
        listSlicePic2(sliceFolder2);//展示切片图像
    }catch(exception)
    {
        ui->label2->setText("没有任务");
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("出现异常"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }

    QApplication::processEvents();
    QWidget::setCursor(Qt::ArrowCursor);
    cancelForbidUI();
    ui->label2->setText(fileBaseName);
    tmp2[0] = 3;
    AddRec2();
}

void Widget::getMouseJ1(double mouseX)
{
    double finalX = mouseX/ui->picb1->width()*ui->pic1->recWidth + ui->pic1->recPosition().x();//鼠标所在的点在大图上的x位置
//    //qDebug()<<" mouseX:"<< mouseX << " ui->pic2->width() "<< ui->pic2->width() <<" ui->pic1->recWidth:"<< ui->pic1->recWidth << " ui->pic1->recPosition().x() : "<< ui->pic1->recPosition().x();
    mouseJ1 = nXSize1 * finalX / ui->pic1->width();
}

void Widget::getMouseW1(double mouseY)
{
    double finalY = mouseY/ui->picb1->height()*ui->pic1->recHeight + ui->pic1->recPosition().y();//鼠标所在的点在大图上的y位置
//    //qDebug()<<" mouseY:"<< mouseY << " ui->pic2->height() "<< ui->pic2->height() <<" ui->pic1->recheight:"<< ui->pic1->recHeight << " ui->pic1->recPosition().y() : "<< ui->pic1->recPosition().y();
    mouseW1 = nYSize1 * finalY / ui->pic1->height();
//    //qDebug()<<" nYSize: "<<nYSize <<" finalY:"<<finalY <<" ui->pic1->width(): "<<ui->pic1->width() ;
}

void Widget::getMouseJ2(double mouseX)
{
    double finalX = mouseX/ui->picb2->width()*ui->pic2->recWidth + ui->pic2->recPosition().x();//鼠标所在的点在大图上的x位置
//    //qDebug()<<" mouseX:"<< mouseX << " ui->pic2->width() "<< ui->pic2->width() <<" ui->pic1->recWidth:"<< ui->pic1->recWidth << " ui->pic1->recPosition().x() : "<< ui->pic1->recPosition().x();
    mouseJ2 = nXSize2 * finalX / ui->pic2->width();
}

void Widget::getMouseW2(double mouseY)
{
    double finalY = mouseY/ui->picb2->height()*ui->pic2->recHeight + ui->pic2->recPosition().y();//鼠标所在的点在大图上的y位置
//    //qDebug()<<" mouseY:"<< mouseY << " ui->pic2->height() "<< ui->pic2->height() <<" ui->pic1->recheight:"<< ui->pic1->recHeight << " ui->pic1->recPosition().y() : "<< ui->pic1->recPosition().y();
    mouseW2 = nYSize2 * finalY / ui->pic2->height();
//    //qDebug()<<" nYSize: "<<nYSize <<" finalY:"<<finalY <<" ui->pic1->width(): "<<ui->pic1->width() ;
}

void Widget::onMouseMove1(QPointF mousePoint)
{
    double mouseX = mousePoint.x();
    double mouseY = mousePoint.y();
    getMouseJ1(mouseX);
    getMouseW1(mouseY);
    mouseJ1 = adfGeoTransform1[0]+ mouseJ1 * adfGeoTransform1[1];
    mouseW1 = adfGeoTransform1[3]+ mouseW1 * adfGeoTransform1[5];
//    //qDebug()<<" mouseJ:"<< mouseJ << " mouseW : "<< mouseW;
    coordTrans1->Transform(1, &mouseJ1, &mouseW1);
    ui->info1->setText(QString::number(mouseJ1) + "," + QString::number(mouseW1));
}

void Widget::onMouseMove2(QPointF mousePoint)
{
    //qDebug()<<"接收到了picb2鼠标移动的信号";
    double mouseX = mousePoint.x();
    double mouseY = mousePoint.y();
    getMouseJ2(mouseX);
    getMouseW2(mouseY);
    mouseJ2 = adfGeoTransform2[0]+ mouseJ2 * adfGeoTransform2[1];
    mouseW2 = adfGeoTransform2[3]+ mouseW2 * adfGeoTransform2[5];
    //qDebug()<<" 投影坐标——mouseJ:"<< mouseJ2 << " mouseW : "<< mouseW2;
    coordTrans2->Transform(1, &mouseJ2, &mouseW2);
    //qDebug()<<" 真实经纬度——mouseJ:"<< mouseJ2 << " mouseW : "<< mouseW2;
    ui->info2->setText(QString::number(mouseJ2) + "," + QString::number(mouseW2));
}

void Widget::showTable1(ShipSlic *slices)
{
  ui->table1->clearContents();
  ui->table1->setRowCount(0);
  for(int i=0; i<sdr1.getDetectNumber(); i++)
    {
        string shipname = slices[i].getValidationName();
        string lefttop = slices[i].getLefttop();
        string leftbottom = slices[i].getLeftbottom();
        string righttop = slices[i].getRighttop();
        string rightbottom = slices[i].getRightbottom();
        string centerlonlat = slices[i].getCenterLonLat();
        listTable1(shipname, centerlonlat, lefttop, leftbottom, righttop, rightbottom);
    }
}

void Widget::showTable2(ShipSlic *slices)
{
  ui->table2->clearContents();
  ui->table2->setRowCount(0);
  for(int i=0; i<sdr2.getDetectNumber(); i++)
    {
        string shipname = slices[i].getValidationName();
        string lefttop = slices[i].getLefttop();
        string leftbottom = slices[i].getLeftbottom();
        string righttop = slices[i].getRighttop();
        string rightbottom = slices[i].getRightbottom();
        string centerlonlat = slices[i].getCenterLonLat();
        listTable2(shipname, centerlonlat, lefttop, leftbottom, righttop, rightbottom);
    }
}

void Widget::listTable1(string shipname, string centerlonlat, string lefttop, string leftbottom, string righttop, string rightbottom)
{
    int rowCount = ui->table1->rowCount();//获取表单行数
    ui->table1->insertRow(rowCount);//插入新行
    QTableWidgetItem *shipName = new QTableWidgetItem();
    QTableWidgetItem *centerLonLat = new QTableWidgetItem();
    QTableWidgetItem *leftTop = new QTableWidgetItem();
    QTableWidgetItem *leftBottom = new QTableWidgetItem();
    QTableWidgetItem *rightTop = new QTableWidgetItem();
    QTableWidgetItem *rightBottom = new QTableWidgetItem();

    shipName->setText(QString::fromStdString(shipname));
    centerLonLat->setText(QString::fromStdString(centerlonlat));
    leftTop->setText(QString::fromStdString(lefttop));
    leftBottom->setText(QString::fromStdString(leftbottom));
    rightTop->setText(QString::fromStdString(righttop));
    rightBottom->setText(QString::fromStdString(rightbottom));

    ui->table1->setItem(rowCount,0,shipName);
    ui->table1->setItem(rowCount,1,centerLonLat);
    ui->table1->setItem(rowCount,2,leftTop);
    ui->table1->setItem(rowCount,3,leftBottom);
    ui->table1->setItem(rowCount,4,rightTop);
    ui->table1->setItem(rowCount,5,rightBottom);
}

void Widget::listTable2(string shipname, string centerlonlat, string lefttop, string leftbottom, string righttop, string rightbottom)
{
    int rowCount = ui->table2->rowCount();//获取表单行数
    ui->table2->insertRow(rowCount);//插入新行
    QTableWidgetItem *shipName = new QTableWidgetItem();
    QTableWidgetItem *centerLonLat = new QTableWidgetItem();
    QTableWidgetItem *leftTop = new QTableWidgetItem();
    QTableWidgetItem *leftBottom = new QTableWidgetItem();
    QTableWidgetItem *rightTop = new QTableWidgetItem();
    QTableWidgetItem *rightBottom = new QTableWidgetItem();

    shipName->setText(QString::fromStdString(shipname));
    centerLonLat->setText(QString::fromStdString(centerlonlat));
    leftTop->setText(QString::fromStdString(lefttop));
    leftBottom->setText(QString::fromStdString(leftbottom));
    rightTop->setText(QString::fromStdString(righttop));
    rightBottom->setText(QString::fromStdString(rightbottom));

    ui->table2->setItem(rowCount,0,shipName);
    ui->table2->setItem(rowCount,1,centerLonLat);
    ui->table2->setItem(rowCount,2,leftTop);
    ui->table2->setItem(rowCount,3,leftBottom);
    ui->table2->setItem(rowCount,4,rightTop);
    ui->table2->setItem(rowCount,5,rightBottom);
}
void Widget::listSlicePic1(QString filePath)
{
    ui->list1->clear();
    QDir dir(filePath);
    if(!dir.exists()){
        qDebug()<<dir;
        qDebug()<<"wrong path";
        QMessageBox::information(this,
                                 tr("error"),
                                 tr("The slice folder does not exist."));
        return;
    }
    dir.setFilter(QDir::Files | QDir::NoSymLinks);
    QFileInfoList list = dir.entryInfoList();
    int file_count = list.count();
    if(file_count <= 0){
        qDebug()<<"no file!";
        QMessageBox::information(this,
                                 tr("error"),
                                 tr("The slice folder is empty"));
        return;
    }
    for(int i=0;i<file_count ;i++){
        QFileInfo fileInfo = list.at(i);
        QString fileName=fileInfo.fileName();
//        qDebug()<<fileName;
//        qDebug()<<fileInfo.filePath();
        QPixmap slicePixmap(fileInfo.filePath());
        QListWidgetItem *tmp = new QListWidgetItem(QIcon(slicePixmap.scaled(QSize(110,110))),fileName);
        //qDebug()<<"fileName: "<<fileName<<" map[fileName]: "<<Map1[fileName.toStdString()]<<"probability: "<<slices1[Map1[fileName.toStdString()]].getProbability();
        if(slices1[Map1[fileName.toStdString()]].getProbability()==0)//为1时表示是船，背景为白色，为0时表示是虚警，背景为海蓝
        {
            tmp->setBackgroundColor(Qt::white);
        }
        else
        {
            tmp->setBackgroundColor(QColor(45, 114, 152));
        }
        tmp->setSizeHint(QSize(120,120));
        ui->list1->addItem(tmp);
        QApplication::processEvents();
    }
}

void Widget::listSlicePic2(QString filePath)
{
    ui->list2->clear();
    QDir dir(filePath);
    if(!dir.exists()){
        qDebug()<<dir;
        qDebug()<<"wrong path";
        QMessageBox::information(this,
                                 tr("error"),
                                 tr("The slice folder does not exist."));
        return;
    }
    dir.setFilter(QDir::Files | QDir::NoSymLinks);
    QFileInfoList list = dir.entryInfoList();
    int file_count = list.count();
    if(file_count <= 0){
        qDebug()<<"no file!";
        QMessageBox::information(this,
                                 tr("error"),
                                 tr("The slice folder is empty"));
        return;
    }
    for(int i=0;i<file_count ;i++){
        QFileInfo fileInfo = list.at(i);
        QString fileName=fileInfo.fileName();
//        qDebug()<<fileName;
//        qDebug()<<fileInfo.filePath();
        QPixmap slicePixmap(fileInfo.filePath());
        QListWidgetItem *tmp = new QListWidgetItem(QIcon(slicePixmap.scaled(QSize(110,110))),fileName);
        qDebug()<<"fileName: "<<fileName<<" map[fileName]: "<<Map2[fileName.toStdString()]<<"probability: "<<slices2[Map2[fileName.toStdString()]].getProbability();
        if(slices2[Map2[fileName.toStdString()]].getProbability()==0)//为1时表示是船，背景为白色，为0时表示是虚警，背景为海蓝
        {
            tmp->setBackgroundColor(Qt::white);
        }
        else
        {
            tmp->setBackgroundColor(QColor(45, 114, 152));
        }
        tmp->setSizeHint(QSize(120,120));
        ui->list2->addItem(tmp);
    }
}

void Widget::AddRec1InThread(Widget *_widget)
{
//    MYDATA* mydata = (MYDATA*)lpParameter;
//    ShipSlic* mymap = mydata->myArray;
    int threadID = _widget->threadId1++;
    int temp = (int) _widget->sdr1.getDetectNumber()/4;
    int total = _widget->sdr1.getDetectNumber();
    for (int i=0; i<=temp; i++){
        int j = 4*i+threadID;
        if(j>=total)
            continue;
        double topLeftX = _widget->slices1[j].getTopLeftX();
        double topLeftY = _widget->slices1[j].getTopLeftY();
        double bottomRightX = _widget->slices1[j].getBottomRightX();
        double bottomRightY = _widget->slices1[j].getBottomRightY();

        _widget->recInfo1[j][0] = _widget->getPixel1(topLeftX);
        _widget->recInfo1[j][1] = _widget->getPixel1(_widget->blockY2allY1(j,topLeftY));//缩略图里的信息
        _widget->recInfo1[j][2] = _widget->getRecLength1(topLeftX);
        _widget->recInfo1[j][3] = _widget->getRecLength1(_widget->blockY2allY1(j,topLeftY));//放大图里的信息
        _widget->recInfo1[j][4] = _widget->getRecLength1(fabs(bottomRightX - topLeftX));
        _widget->recInfo1[j][5] = _widget->getRecLength1(fabs(_widget->blockY2allY1(j,bottomRightY) - _widget->blockY2allY1(j,topLeftY)));//放大图里的方框宽与高

    }
}

void Widget::AddRec2InThread(Widget *_widget)
{
//    MYDATA* mydata = (MYDATA*)lpParameter;
//    ShipSlic* mymap = mydata->myArray;
    int threadID = _widget->threadId2++;
    qDebug()<<threadID<<endl;
    int temp = (int) _widget->sdr2.getDetectNumber()/4;
    int total = _widget->sdr2.getDetectNumber();
    for (int i=0; i<=temp; i++){
        int j = 4*i+threadID;
        if(j>=total)
            continue;
        double topLeftX = _widget->slices2[j].getTopLeftX();
        double topLeftY = _widget->slices2[j].getTopLeftY();
        double bottomRightX = _widget->slices2[j].getBottomRightX();
        double bottomRightY = _widget->slices2[j].getBottomRightY();

        _widget->recInfo2[j][0] = _widget->getPixel2(topLeftX);
        _widget->recInfo2[j][1] = _widget->getPixel2(_widget->blockY2allY2(j,topLeftY));//缩略图里的信息
        _widget->recInfo2[j][2] = _widget->getRecLength2(topLeftX);
        _widget->recInfo2[j][3] = _widget->getRecLength2(_widget->blockY2allY2(j,topLeftY));//放大图里的信息
        _widget->recInfo2[j][4] = _widget->getRecLength2(fabs(bottomRightX - topLeftX));
        _widget->recInfo2[j][5] = _widget->getRecLength2(fabs(bottomRightY - topLeftY));//放大图里的方框宽与高
    }
}

void Widget::AddRec1()
{
    ui->label1->setText("正在绘制切片");

    QWidget::setCursor(Qt::WaitCursor);
    const int THREAD_NUM = 4;
    HANDLE handle[THREAD_NUM];
    threadId1 = 0;

    for(int t=0; t<THREAD_NUM; t++)
    {
        handle[t] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)AddRec1InThread, this, 0, NULL);
    }
    for(int t=0; t<THREAD_NUM; t++)
    {
        CloseHandle(handle[t]);
    }

    for(int t=0; t<sdr1.getDetectNumber(); t++)
    {
        addRecInPic1(recInfo1[t][0],recInfo1[t][1]);
        drawRecImage1(recInfo1[t][2],recInfo1[t][3],recInfo1[t][4],recInfo1[t][5]);
        QApplication::processEvents();
    }
    createImageWithOverlay1(baseImage1, recImage1);
    threadId1 = 0;
    QWidget::setCursor(Qt::ArrowCursor);

    ui->label1->setText(QString::fromStdString(lockFileName1));
}

void Widget::AddRec2()
{
    ui->label2->setText("正在绘制切片");

    QWidget::setCursor(Qt::WaitCursor);
    const int THREAD_NUM = 4;
    HANDLE handle[THREAD_NUM];
    threadId2 = 0;

    for(int t=0; t<THREAD_NUM; t++)
    {
        handle[t] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)AddRec2InThread, this, 0, NULL);
    }
    for(int t=0; t<THREAD_NUM; t++)
    {
        CloseHandle(handle[t]);
    }

    for(int t=0; t<sdr2.getDetectNumber(); t++)
    {
        //qDebug()<<"t:"<<t<<"\trecInfo: "<<recInfo2[t][0]<<recInfo2[t][1]<<recInfo2[t][2]
                  //<<recInfo2[t][3]<<recInfo2[t][4]<<recInfo2[t][5];
        addRecInPic2(recInfo2[t][0],recInfo2[t][1]);
        drawRecImage2(recInfo2[t][2],recInfo2[t][3],recInfo2[t][4],recInfo2[t][5]);
        QApplication::processEvents();
    }

    //drawRecImage2(0,0,200,200);
    createImageWithOverlay2(baseImage2, recImage2);
    threadId2 = 0;

    QWidget::setCursor(Qt::ArrowCursor);
    ui->label2->setText(QString::fromStdString(lockFileName2));
}

void Widget::addRecInPic1(double x, double y)
{
    ui->pic1->addRec(x,y);
}

void Widget::addRecInPic2(double x, double y)
{
    ui->pic2->addRec(x,y);
}

void Widget::drawRecImage1(int x, int y, int width, int height)
{
    QPainter painter;
    painter.begin(&recImage1);
    painter.setPen(QPen(QColor(0,107,22),3));
    painter.drawRect(x,y,width,height);
    painter.end();

//    ui->pic1->loadPixmap = QPixmap::fromImage(recImage);
}

void Widget::drawRecImage2(int x, int y, int width, int height)
{
    QPainter painter;
    painter.begin(&recImage2);
    painter.setPen(QPen(QColor(0,107,22),3));
    painter.drawRect(x,y,width,height);
    //qDebug()<<"我以起点为"<<x<<"和"<<y<<"画一个长方形，长为"<<width<<"，宽为"<<height;
    painter.end();
//    ui->pic1->loadPixmap = QPixmap::fromImage(recImage);
}

void Widget::createImageWithOverlay1(QImage underImage, QImage overlayImage)
{
    overlayImage = overlayImage.scaled(baseImage1.size(),Qt::KeepAspectRatioByExpanding);

    QImage imageWithOverlay = QImage(overlayImage);
    QPainter painter(&imageWithOverlay);

    painter.setCompositionMode(QPainter::CompositionMode_DestinationOver);
    painter.drawImage(0, 0, underImage);

    painter.end();

    ui->pic1->loadPixmap = QPixmap::fromImage(imageWithOverlay);
    qDebug()<<"createImageWithOverlay1";
}

void Widget::createImageWithOverlay2(QImage underImage, QImage overlayImage)
{
    overlayImage = overlayImage.scaled(baseImage2.size(),Qt::KeepAspectRatioByExpanding);

    QImage imageWithOverlay = QImage(overlayImage);
    QPainter painter(&imageWithOverlay);

    painter.setCompositionMode(QPainter::CompositionMode_DestinationOver);
    painter.drawImage(0, 0, underImage);

    painter.end();

    ui->pic2->loadPixmap = QPixmap::fromImage(imageWithOverlay);
    //ui->pic2->loadPixmap = QPixmap::fromImage(recImage2);
}

double Widget::getJ1(double x)
{
    double finalX = x/ui->picb1->width()*ui->pic1->recWidth + ui->pic1->recPosition().x();//点在大图上的x位置
    double j = nXSize1 * finalX / ui->pic1->width();
    return j;
}

double Widget::getW1(double y)
{
    double finalY = y/ui->picb1->height()*ui->pic1->recHeight + ui->pic1->recPosition().y();//点在大图上的y位置
    double w = nYSize1 * finalY / ui->pic1->height();
    return w;
}

double Widget::getJ2(double x)
{
    double finalX = x/ui->picb2->width()*ui->pic2->recWidth + ui->pic2->recPosition().x();//点在大图上的x位置
    double j = nXSize2 * finalX / ui->pic2->width();
    return j;
}

double Widget::getW2(double y)
{
    double finalY = y/ui->picb2->height()*ui->pic2->recHeight + ui->pic2->recPosition().y();//点在大图上的y位置
    double w = nYSize2 * finalY / ui->pic2->height();
    return w;
}

double Widget::getPosX1(double jnum, double wnum)
{
    coordTransInverse1->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform1[5] * (jnum - adfGeoTransform1[0]) -adfGeoTransform1[2] * (wnum - adfGeoTransform1[3])) / dTemp1 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize1*ui->pic1->labelWidth - ui->pic1->recWidth/2 ;
    return x;

}

double Widget::getPosY1(double jnum, double wnum)
{
    coordTransInverse1->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform1[1]*(wnum - adfGeoTransform1[3]) -adfGeoTransform1[4]*(jnum - adfGeoTransform1[0])) / dTemp1 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize1 *ui->pic1->labelWidth - ui->pic1->recHeight/2 ;
    return y;
}

double Widget::getPosX2(double jnum, double wnum)
{
    coordTransInverse2->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform2[5] * (jnum - adfGeoTransform2[0]) -adfGeoTransform2[2] * (wnum - adfGeoTransform2[3])) / dTemp2 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize2 * ui->pic2->labelWidth - ui->pic2->recWidth/2 ;
    return x;

}

double Widget::getPosY2(double jnum, double wnum)
{
    coordTransInverse2->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform2[1]*(wnum - adfGeoTransform2[3]) -adfGeoTransform2[4]*(jnum - adfGeoTransform2[0])) / dTemp2 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize2 *ui->pic2->labelWidth - ui->pic2->recHeight/2 ;
    return y;
}

double Widget::getSPosX1(double jnum, double wnum)
{
    coordTransInverse1->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform1[5] * (jnum - adfGeoTransform1[0]) -adfGeoTransform1[2] * (wnum - adfGeoTransform1[3])) / dTemp1 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize1 * ui->pic1->labelWidth - ui->pic1->sRecWidth/2 ;
    return x;

}

double Widget::getSPosY1(double jnum, double wnum)
{
    coordTransInverse1->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform1[1]*(wnum - adfGeoTransform1[3]) -adfGeoTransform1[4]*(jnum - adfGeoTransform1[0])) / dTemp1 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize1 * ui->pic1->labelWidth - ui->pic1->sRecHeight/2 ;
    return y;
}

double Widget::getSPosX2(double jnum, double wnum)
{
    coordTransInverse2->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform2[5] * (jnum - adfGeoTransform2[0]) -adfGeoTransform2[2] * (wnum - adfGeoTransform2[3])) / dTemp2 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize2 * ui->pic2->labelWidth - ui->pic2->sRecWidth/2 ;
    return x;

}

double Widget::getSPosY2(double jnum, double wnum)
{
    coordTransInverse2->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform2[1]*(wnum - adfGeoTransform2[3]) -adfGeoTransform2[4]*(jnum - adfGeoTransform2[0])) / dTemp2 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize2 * ui->pic2->labelWidth - ui->pic2->sRecHeight/2 ;
    return y;
}

double Widget::getPixel1(double pixel)//根据像素位置得到在缩略图中的位置
{
    double sPixel = pixel/nXSize1*ui->pic1->labelWidth;
    return sPixel;
}

double Widget::getPixel2(double pixel)//根据像素位置得到在缩略图中的位置
{
    double sPixel = pixel/nXSize2*ui->pic2->labelWidth;
    return sPixel;
}

double Widget::getRecPosX1(double jnum,double wnum)
{
    coordTransInverse1->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform1[5] * (jnum - adfGeoTransform1[0]) -adfGeoTransform1[2] * (wnum - adfGeoTransform1[3])) / dTemp1 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize1*recImage1.width();
    return x;
}

double Widget::getRecPosY1(double jnum,double wnum)
{
    coordTransInverse1->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform1[1]*(wnum - adfGeoTransform1[3]) -adfGeoTransform1[4]*(jnum - adfGeoTransform1[0])) / dTemp1 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize1*recImage1.width();
    return y;
}

double Widget::getRecPosX2(double jnum,double wnum)
{
    coordTransInverse2->Transform(1, &jnum, &wnum);
    double Xpixel= (adfGeoTransform2[5] * (jnum - adfGeoTransform2[0]) -adfGeoTransform2[2] * (wnum - adfGeoTransform2[3])) / dTemp2 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的jnum: "<<jnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Xpixel: "<<Xpixel;
    double x = Xpixel/nXSize2*recImage2.width();
    return x;
}

double Widget::getRecPosY2(double jnum,double wnum)
{
    coordTransInverse2->Transform(1, &jnum, &wnum);
    double Ypixel= (adfGeoTransform2[1]*(wnum - adfGeoTransform2[3]) -adfGeoTransform2[4]*(jnum - adfGeoTransform2[0])) / dTemp2 + 0.5;
//    qDebug()<<"验证经纬度换算成坐标是否正确的wnum: "<<wnum;
//    qDebug()<<"验证经纬度换算成坐标是否正确的Ypixel: "<<Ypixel;
    double y = Ypixel/nXSize2*recImage2.width();
    return y;
}

double Widget::getRecLength1(double length)//由像素点得到标框长度
{
    double recLength = length * recImage1.width() /nXSize1 ;
    //qDebug()<<"Pos: "<<length<<"     recImage.width: "<<recImage1.width()<<"    nXSize: "<<nXSize1<<"   recLength: "<<recLength;
    return recLength;
}

double Widget::getRecLength2(double length)//由像素点得到标框长度
{
    double recLength = length * recImage2.width() /nXSize2 ;
    return recLength;
}

void Widget::slotItemDoubleClicked1(QListWidgetItem *item)
{
    //    qDebug()<<item->text();
    string fileName = item->text().toStdString();
    QTableWidgetItem *tmp = ui->table1->item(Map1[fileName], 0);
    ui->table1->setCurrentItem(tmp);
    //这儿需要写代码做一个判断，原来是什么，需要变色
    if(slices1[Map1[fileName]].getProbability()==0)
    {
        item->setBackgroundColor(QColor(45, 114, 152));
        slices1[Map1[fileName]].setProbability(1);
        qDebug()<<QString::fromStdString(fileName)<<" from list1: "<<slices1[Map1[fileName]].getProbability();
    }
    else
    {
        item->setBackgroundColor(Qt::white);
        slices1[Map1[fileName]].setProbability(0);
        qDebug()<<QString::fromStdString(fileName)<<" from list1: "<<slices1[Map1[fileName]].getProbability();
    }
    qDebug()<<"ui->list2->count(): "<<ui->list2->count();
//    qDebug()<<"list2最近的切片图像是: "<<slices2[search1(item->text().toStdString())].getValidationName();

    if(ui->list2->count()>0)
    {
        QString toFind = QString::fromStdString(slices2[search1(item->text().toStdString())].getValidationName());
        for( int i=0;i<ui->list2->count();i++)
        {
            if(ui->list2->item(i)->text() == toFind)
            {
                ui->list2->setCurrentRow(i);
                break;
            }
        }
    }
    if(ui->picb1->isShowJW == true)
    {
        ui->pic1->moveRec(getPosX1(slices1[Map1[fileName]].getX(),slices1[Map1[fileName]].getY()),getPosY1(slices1[Map1[fileName]].getX(),slices1[Map1[fileName]].getY()));
    }
}

int Widget::search1(string fileName)
{
    double x1 = slices1[Map1[fileName]].getX();
    double y1 = slices1[Map1[fileName]].getY();
    double x2 = slices2[0].getX();
    double y2 = slices2[0].getY();
    double distance = (x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
    int result=0;
    for(int i = 1; i < sdr2.getDetectNumber(); i++)
    {
        x2 = slices2[i].getX();
        y2 = slices2[i].getY();
        double tmp = (x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
        if(tmp < distance)
        {
            result = i;
            distance = tmp;
        }
    }
    return result;
}

int Widget::search2(string fileName)
{
    double x2 = slices2[Map2[fileName]].getX();
    double y2 = slices2[Map2[fileName]].getY();
    double x1 = slices1[0].getX();
    double y1 = slices1[0].getY();
    double distance = (x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
    int result=0;
    for(int i = 1; i < sdr1.getDetectNumber(); i++)
    {
        x1 = slices1[i].getX();
        y1 = slices1[i].getY();
        double tmp = (x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
        if(tmp < distance)
        {
            result = i;
            distance = tmp;
        }
    }
    return result;
}

void Widget::slotItemDoubleClicked2(QListWidgetItem *item)
{
    //    qDebug()<<item->text();
    string fileName = item->text().toStdString();
    QTableWidgetItem *tmp = ui->table2->item(Map2[fileName], 0);
    ui->table2->setCurrentItem(tmp);
    //这儿需要写代码做一个判断，原来是什么，需要变色
    if(slices2[Map2[fileName]].getProbability()==0)
    {
        item->setBackgroundColor(QColor(45, 114, 152));
        slices2[Map2[fileName]].setProbability(1);
        qDebug()<<QString::fromStdString(fileName)<<" from list2: "<<slices2[Map2[fileName]].getProbability();
    }
    else
    {
        item->setBackgroundColor(Qt::white);
        slices2[Map2[fileName]].setProbability(0);
        qDebug()<<QString::fromStdString(fileName)<<" from list2: "<<slices2[Map2[fileName]].getProbability();
    }
    qDebug()<<"ui->list1->count(): "<<ui->list1->count();
//    qDebug()<<"list1最近的切片图像是： "<<slices1[search2(item->text().toStdString())].getValidationName();

    if(ui->list1->count()>0)
    {
        QString toFind = QString::fromStdString(slices1[search2(item->text().toStdString())].getValidationName());
        for( int i=0;i<ui->list1->count();i++)
        {
            if(ui->list1->item(i)->text() == toFind)
            {
                ui->list1->setCurrentRow(i);
                break;
            }
        }
    }
    if(ui->picb2->isShowJW == true)
    {
        ui->pic2->moveRec(getPosX2(slices2[Map2[fileName]].getX(),slices2[Map2[fileName]].getY()),getPosY2(slices2[Map2[fileName]].getX(),slices2[Map2[fileName]].getY()));
    }
}

void Widget::slotItemClicked1(QListWidgetItem *item)
{
    string fileName = item->text().toStdString();
    QTableWidgetItem *tmp = ui->table1->item(Map1[fileName], 0);
    //qDebug()<<"Map[fileName]: "<<Map[fileName];
    if(ui->list2->count()>0)
    {
        QString toFind = QString::fromStdString(slices2[search1(item->text().toStdString())].getValidationName());
        for( int i=0;i<ui->list2->count();i++)
        {
            if(ui->list2->item(i)->text() == toFind)
            {
                ui->list2->setCurrentRow(i);
                break;
            }
        }
    }
    ui->table1->setCurrentItem(tmp);
    if(ui->picb1->isShowJW == true)
    {
        ui->pic1->moveRec(getPosX1(slices1[Map1[fileName]].getX(),slices1[Map1[fileName]].getY()),getPosY1(slices1[Map1[fileName]].getX(),slices1[Map1[fileName]].getY()));
    }
}

void Widget::slotItemClicked2(QListWidgetItem *item)
{
    string fileName = item->text().toStdString();
    QTableWidgetItem *tmp = ui->table2->item(Map2[fileName], 0);
    //qDebug()<<"Map[fileName]: "<<Map[fileName];
    ui->table2->setCurrentItem(tmp);
    qDebug()<<item->text()<<"   "<<Map2[fileName];
    if(ui->list1->count()>0)
    {
        //qDebug()<<"oops!";
        QString toFind = QString::fromStdString(slices1[search2(item->text().toStdString())].getValidationName());
        for( int i=0;i<ui->list1->count();i++)
        {
            if(ui->list1->item(i)->text() == toFind)
            {
                ui->list1->setCurrentRow(i);
                break;
            }
        }
    }
    if(ui->picb2->isShowJW == true)
    {
        ui->pic2->moveRec(getPosX2(slices2[Map2[fileName]].getX(),slices2[Map2[fileName]].getY()),getPosY2(slices2[Map2[fileName]].getX(),slices2[Map2[fileName]].getY()));
    }
}

void Widget::on_tjBtn_clicked()
{
    forbidUI();
    if(tmp1[0]!=3||tmp2[0]!=3)//没有任务被打开
    {
        QMessageBox::information(this,
                                 tr("error"),
                                 tr("当前没有可提交的任务或可提交的任务不完整。"));
        cancelForbidUI();
        return;
    }
    QWidget::setCursor(Qt::WaitCursor);
    sdr1.setSlices(slices1);
    sdr2.setSlices(slices2);
    tools.setSliceInf(sdr1, false);
    tools.setSliceInf(sdr2, true);
    bool result = tools.complete();//切片虚警标注完成，完成xml文件的上传
    if(result==false)
    {
        QMessageBox::information(this,
                                 tr("错误"),
                                 tr("服务器无法连接。"));
        cancelForbidUI();
        QWidget::setCursor(Qt::ArrowCursor);
        return;
    }

    QWidget::setCursor(Qt::ArrowCursor);
    cancelForbidUI();
    QMessageBox::information(this,
                             tr("information"),
                             tr("Success."));
    return;
}

void Widget::forbidUI()
{
    ui->dk1Btn->setEnabled(false);
    ui->tjBtn->setEnabled(false);
    ui->dk2Btn->setEnabled(false);
    ui->zj1Btn->setEnabled(false);
    ui->zj2Btn->setEnabled(false);
    ui->ztBtn->setEnabled(false);
    ui->gbBtn->setEnabled(false);
    disconnect(ui->list1, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked1(QListWidgetItem*)));
    disconnect(ui->list2, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked2(QListWidgetItem*)));
}

void Widget::cancelForbidUI()
{
    ui->dk1Btn->setEnabled(true);
    ui->tjBtn->setEnabled(true);
    ui->dk2Btn->setEnabled(true);
    ui->ztBtn->setEnabled(true);
    ui->gbBtn->setEnabled(true);
    if(ui->picb1->isShowJW == true)
        ui->zj1Btn->setEnabled(true);
    if(ui->picb2->isShowJW == true)
        ui->zj2Btn->setEnabled(true);
    connect(ui->list1, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked1(QListWidgetItem*)));
    connect(ui->list2, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(slotItemDoubleClicked2(QListWidgetItem*)));
}


void Widget::closeEvent(QCloseEvent *event)
{
    QMessageBox::StandardButton button;

    button=QMessageBox::question(this,tr("退出程序"),QString(tr("确认退出程序")),QMessageBox::Yes|QMessageBox::No);
    if(button==QMessageBox::No)
    {
        event->ignore(); // 忽略退出信号，程序继续进行
    }
    else if(button==QMessageBox::Yes)
    {
        if( tmp1[0] != 1)
        {
            bool result = tools.cancelLock(lockFileName1);
            if(result==false)
            {
                QMessageBox::information(this,
                                         tr("错误"),
                                         tr("服务器无法连接。"));
                cancelForbidUI();
                QWidget::setCursor(Qt::ArrowCursor);
                return;
            }
            tmp1[0] = 1;
        }
        if( tmp2[0] != 1)
        {
            bool result = tools.cancelLock(lockFileName2);
            if(result==false)
            {
                QMessageBox::information(this,
                                         tr("错误"),
                                         tr("服务器无法连接。"));
                cancelForbidUI();
                QWidget::setCursor(Qt::ArrowCursor);
                return;
            }
            tmp2[0] = 1;
        }
        event->accept(); // 接受退出信号，程序退出
    }
}

void Widget::on_zj1Btn_clicked()
{
    ui->picb1->isShowRec = true;
    ui->picb1->toRepaint();
}

void Widget::on_zj2Btn_clicked()
{
    ui->picb2->isShowRec = true;
    ui->picb2->toRepaint();
}

void Widget::onSliceCapture1(QPixmap captureImage, QPointF topLeft, QPointF bottomRight)
{
    qDebug()<<"接受到了信号";
    QMessageBox::StandardButton button;
    button=QMessageBox::question(this,tr("新增切片"),QString(tr("是否确认增加多光谱图像中的此切片？")),QMessageBox::No|QMessageBox::Yes);
    if(button==QMessageBox::No)
    {
        ui->picb1->isFinishCapture = false;
        return;
    }
    else if(button==QMessageBox::Yes)
    {
        ui->picb1->isFinishCapture = false;
        //我要获取这些信息：复制得到的图片，矩形左上和右下坐标并换算成经纬度
        double topLeftX = topLeft.x();
        double topLeftY= topLeft.y();
        double bottomRightX = bottomRight.x();
        double bottomRightY = bottomRight.y();
        double topLeftJ = getJ1(topLeftX);
        double topLeftW = getW1(topLeftY);
        double bottomRightJ = getJ1(bottomRightX);
        double bottomRightW = getW1(bottomRightY);

        string topLeftPixels = doubleToString(topLeftW) + "," + doubleToString(topLeftJ);
        string bottomRightPixels = doubleToString(bottomRightW) + "," + doubleToString(bottomRightJ);

        double recWidth = getRecLength1(fabs(bottomRightJ-topLeftJ));
        double recHeight = getRecLength1(fabs(bottomRightW-topLeftW));//因为是像素值，得先进行处理


        topLeftJ  = adfGeoTransform1[0]+ topLeftJ  * adfGeoTransform1[1];
        bottomRightJ  = adfGeoTransform1[0]+ bottomRightJ  * adfGeoTransform1[1];
        topLeftW = adfGeoTransform1[3]+ topLeftW * adfGeoTransform1[5];
        bottomRightW = adfGeoTransform1[3]+ bottomRightW * adfGeoTransform1[5];
        coordTrans1->Transform(1, &topLeftJ, &topLeftW);
        coordTrans1->Transform(1, &bottomRightJ, &bottomRightW);//至此，所有经纬度信息处理完毕

        double centerJ = (topLeftJ + bottomRightJ)/2;
        double centerW = (topLeftW + bottomRightW)/2;



        //接下来要做的：1.sliceList中新增一个，包括图像+名称；2.sliceTable中新增一个，包括N多信息; 3.用学长的接口，把他需要的数据给他; 4.新增切片保存到本地
        //qDebug()<<"for test";
        //完成2的内容
        string centerlonlat = doubleToString(centerJ) + "_" + doubleToString(centerW);
        string shipname = centerlonlat + ".tiff";
        string lefttop = doubleToString(topLeftJ) + "_" + doubleToString(topLeftW);
        string leftbottom = doubleToString(topLeftJ) + "_" + doubleToString(bottomRightW);
        string righttop = doubleToString(bottomRightJ) + "_" + doubleToString(topLeftW);
        string rightbottom = doubleToString(bottomRightJ) + "_" + doubleToString(bottomRightW);
//        Map1[shipname] = sdr1.getDetectNumber();
        listTable1(shipname, centerlonlat, lefttop, leftbottom, righttop, rightbottom);

        QString shipName = QString::fromStdString(shipname);

        ui->pic1->addRec(getSPosX1(centerJ, centerW),getSPosY1(centerJ, centerW));
        double recX = getRecPosX1(topLeftJ, topLeftW);
        double recY = getRecPosY1(topLeftJ,topLeftW);
        drawRecImage1(recX,recY,recWidth,recHeight);
        createImageWithOverlay1(baseImage1, recImage1);

        //完成1的内容
        addListItem1(captureImage, shipName);

        //完成4的内容
        loadNewSlice1(captureImage, shipName);


        string blockOrder = "-1";
        string Array[] = {lefttop, leftbottom, righttop, rightbottom, centerlonlat,topLeftPixels,bottomRightPixels,blockOrder};
        tools.AppendRecord(&sdr1, Array,false);
        slices1 = sdr1.getSlices();
        Map1 = tools.getSliceInf(sdr1);//重新获得信息

    }
}

void Widget::onSliceCapture2(QPixmap captureImage, QPointF topLeft, QPointF bottomRight)
{
    qDebug()<<"接受到了信号";
    QMessageBox::StandardButton button;
    button=QMessageBox::question(this,tr("新增切片"),QString(tr("是否确认增加全色图像中的此切片？")),QMessageBox::No|QMessageBox::Yes);
    if(button==QMessageBox::No)
    {
        ui->picb1->isFinishCapture = false;
        return;
    }
    else if(button==QMessageBox::Yes)
    {
        ui->picb2->isFinishCapture = false;
        //我要获取这些信息：复制得到的图片，矩形左上和右下坐标并换算成经纬度
        double topLeftX = topLeft.x();
        double topLeftY= topLeft.y();
        double bottomRightX = bottomRight.x();
        double bottomRightY = bottomRight.y();
        double topLeftJ = getJ2(topLeftX);
        double topLeftW = getW2(topLeftY);
        double bottomRightJ = getJ2(bottomRightX);
        double bottomRightW = getW2(bottomRightY);
        qDebug()<<"新增切片在全图的像素坐标："<<topLeftJ<<topLeftW;

        string topLeftPixels = doubleToString(topLeftW) + "," + doubleToString(topLeftJ);
        string bottomRightPixels = doubleToString(bottomRightW) + "," + doubleToString(bottomRightJ);

        double recWidth = getRecLength2(fabs(bottomRightJ-topLeftJ));
        double recHeight = getRecLength2(fabs(bottomRightW-topLeftW));//因为是像素值，得先进行处理


        topLeftJ  = adfGeoTransform2[0]+ topLeftJ  * adfGeoTransform2[1];
        bottomRightJ  = adfGeoTransform2[0]+ bottomRightJ  * adfGeoTransform2[1];
        topLeftW = adfGeoTransform2[3]+ topLeftW * adfGeoTransform2[5];
        bottomRightW = adfGeoTransform2[3]+ bottomRightW * adfGeoTransform2[5];
        qDebug()<<"新增切片在全图的投影坐标："<<topLeftJ<<topLeftW;

        coordTrans2->Transform(1, &topLeftJ, &topLeftW);
        coordTrans2->Transform(1, &bottomRightJ, &bottomRightW);//至此，所有经纬度信息处理完毕
        qDebug()<<"新增切片的经纬度："<<topLeftJ<<topLeftW;

        double centerJ = (topLeftJ + bottomRightJ)/2;
        double centerW = (topLeftW + bottomRightW)/2;

        ui->pic2->addRec(getSPosX2(centerJ, centerW),getSPosY2(centerJ, centerW));
        double recX = getRecPosX2(topLeftJ, topLeftW);
        double recY = getRecPosY2(topLeftJ,topLeftW);
        drawRecImage2(recX,recY,recWidth,recHeight);
        createImageWithOverlay2(baseImage2, recImage2);



        //接下来要做的：1.sliceList中新增一个，包括图像+名称；2.sliceTable中新增一个，包括N多信息; 3.用学长的接口，把他需要的数据给他; 4.新增切片保存到本地
        //qDebug()<<"for test";
        //完成2的内容
        string centerlonlat = doubleToString(centerJ) + "_" + doubleToString(centerW);
        string shipname = centerlonlat + ".tiff";
        string lefttop = doubleToString(topLeftJ) + "_" + doubleToString(topLeftW);
        string leftbottom = doubleToString(topLeftJ) + "_" + doubleToString(bottomRightW);
        string righttop = doubleToString(bottomRightJ) + "_" + doubleToString(topLeftW);
        string rightbottom = doubleToString(bottomRightJ) + "_" + doubleToString(bottomRightW);
//        Map2[shipname] = sdr2.getDetectNumber();
        listTable2(shipname, centerlonlat, lefttop, leftbottom, righttop, rightbottom);

        QString shipName = QString::fromStdString(shipname);



        //完成1的内容
        addListItem2(captureImage, shipName);

        //完成4的内容
        loadNewSlice2(captureImage, shipName);

        string blockOrder = "-1";
        string Array[] = {lefttop, leftbottom, righttop, rightbottom, centerlonlat,topLeftPixels,bottomRightPixels,blockOrder};
        tools.AppendRecord(&sdr2, Array, true);
        slices2 = sdr2.getSlices();
        Map2 = tools.getSliceInf(sdr2);//重新获得信息

    }
}

double Widget::blockY2allY1(int i,int y)//根据第几个切片由分块时的像素点Y坐标得到全图时的像素点Y坐标
{
    int blockOrder = slices1[i].getBlockOrder();//切片在第几块上,我这里是从第0块开始计的，需要和师兄确认
    //blockHeight = nYSize/blockNumber;//最好在读图的时候把它就算出来
    double deviation;//由于重叠产生的偏差
    if( blockOrder == -1 )
    {
        return y;
    }
    else if( blockOrder == 0 )
    {
        deviation = 0;
    }
    else deviation = 100;
    double allY = y - deviation + blockOrder * blockHeight1;
    //qDebug()<<"nYSize: "<<nYSize<<"blockNumber: "<<blockNumber<<"blockHeight: "<<blockHeight;
    //qDebug()<<"i:" <<i<<"\t初始Y:"<<y<<"\tblockOrder: "<<blockOrder<<"\tdeviation: "<<deviation<<"\tblockHeight: "<<blockHeight2<<"\tallY:"<<allY;
    return allY;
}

double Widget::blockY2allY2(int i,int y)//根据第几个切片由分块时的像素点Y坐标得到全图时的像素点Y坐标
{
    int blockOrder = slices2[i].getBlockOrder();//切片在第几块上,我这里是从第0块开始计的，需要和师兄确认
    //blockHeight = nYSize/blockNumber;//最好在读图的时候把它就算出来
    double deviation;//由于重叠产生的偏差
    if( blockOrder == -1 )
    {
        return y;
    }
    else if( blockOrder == 0 )
    {
        deviation = 0;
    }
    else deviation = 100;
    double allY = y - deviation + blockOrder * blockHeight2;
    //qDebug()<<"nYSize: "<<nYSize<<"blockNumber: "<<blockNumber<<"blockHeight: "<<blockHeight;
    //qDebug()<<"i:" <<i<<"\t初始Y:"<<y<<"\tblockOrder: "<<blockOrder<<"\tdeviation: "<<deviation<<"\tblockHeight2: "<<blockHeight2<<"\tallY:"<<allY;
    return allY;
}

void Widget::addListItem1(QPixmap captureImage, QString fileName)
{
    QListWidgetItem *tmp = new QListWidgetItem(QIcon(captureImage.scaled(QSize(110,110))),fileName);
    //qDebug()<<"fileName: "<<fileName<<"  map[fileName]: "<<Map[fileName.toStdString()]<<"  Probability: "<<slices[Map[fileName.toStdString()]].getProbability();
    tmp->setBackgroundColor(QColor(45, 114, 152));
    tmp->setSizeHint(QSize(130,130));
    ui->list1->addItem(tmp);
}

void Widget::addListItem2(QPixmap captureImage, QString fileName)
{
    QListWidgetItem *tmp = new QListWidgetItem(QIcon(captureImage.scaled(QSize(110,110))),fileName);
    //qDebug()<<"fileName: "<<fileName<<"  map[fileName]: "<<Map[fileName.toStdString()]<<"  Probability: "<<slices[Map[fileName.toStdString()]].getProbability();
    tmp->setBackgroundColor(QColor(45, 114, 152));
    tmp->setSizeHint(QSize(130,130));
    ui->list2->addItem(tmp);
}

void Widget::loadNewSlice1(QPixmap capturePixmap, QString fileName)
{
    capturePixmap.save( sliceFolder1+"/" + fileName,0,-1);
}

void Widget::loadNewSlice2(QPixmap capturePixmap, QString fileName)
{
    capturePixmap.save( sliceFolder2+"/" + fileName,0,-1);
}

string Widget::doubleToString(double num)
{
    char str[256];
    sprintf(str, "%lf", num);
    string result = str;
    return result;
}


void Widget::on_ztBtn_clicked()
{
    forbidUI();
    if(tmp1[0]!=3||tmp2[0]!=3)//没有任务被打开
    {
        QMessageBox::information(this,
                                 tr("error"),
                                 tr("当前没有可制图的任务或可制图的任务不完整。"));
        cancelForbidUI();
        return;
    }
    QWidget::setCursor(Qt::WaitCursor);
//    bool result1 = tools.draft(sdr1);
//    if(result1==false)
//    {
//        QMessageBox::information(this,
//                                 tr("错误"),
//                                 tr("服务器无法连接。10"));
//        cancelForbidUI();
//        QWidget::setCursor(Qt::ArrowCursor);
//        return;
//    }
//    bool result2 = tools.draft(sdr2);//制图通知
//    if(result2==false)
//    {
//        QMessageBox::information(this,
//                                 tr("错误"),
//                                 tr("服务器无法连接。11"));
//        cancelForbidUI();
//        QWidget::setCursor(Qt::ArrowCursor);
//        return;
//    }
    QWidget::setCursor(Qt::ArrowCursor);
    cancelForbidUI();
    QMessageBox::information(this,
                             tr("information"),
                             tr("Success."));
    return;
}

void Widget::on_gbBtn_clicked()
{
    if(tmp1[0]==3)
    {
        bool result = tools.cancelLock(lockFileName1);
        if(result==false)
        {
            QMessageBox::information(this,
                                     tr("错误"),
                                     tr("服务器无法连接。"));
            cancelForbidUI();
            QWidget::setCursor(Qt::ArrowCursor);
            return;
        }
    }
    if(tmp2[0]==3)
    {
        bool result = tools.cancelLock(lockFileName2);
        if(result==false)
        {
            QMessageBox::information(this,
                                     tr("错误"),
                                     tr("服务器无法连接。"));
            cancelForbidUI();
            QWidget::setCursor(Qt::ArrowCursor);
            return;
        }
    }
    tmp1[0] = 1;
    tmp2[0] = 1;
    ui->picb1->cancelShowJW();
    ui->picb2->cancelShowJW();
    ui->zj1Btn->setEnabled(false);
    ui->zj2Btn->setEnabled(false);
    ui->label1->setText("");
    ui->label2->setText("");
    ui->info1->setText("经纬度");
    ui->info2->setText("经纬度");
    ui->pic1->resize(QSize(0,0));
    ui->widget1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->pic2->resize(QSize(0,0));
    ui->widget2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->picb1->resize(QSize(0,0));
    ui->widgetb1->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->picb2->resize(QSize(0,0));
    ui->widgetb2->setStyleSheet("border-width:1px;border-style:solid;border-color:rgb(255,255,255);");
    ui->pic1->isShowRec = false;
    ui->pic2->isShowRec = false;
    ui->list1->clear();
    ui->list2->clear();
    ui->table1->clearContents();
    ui->table2->clearContents();
    ui->table1->setRowCount(0);
    ui->table2->setRowCount(0);
    adfGeoTransform1[1] = 1;
    adfGeoTransform1[5] = 1;
    adfGeoTransform2[1] = 1;
    adfGeoTransform2[5] = 1;
    lockFileName1 = "";
    lockFileName2 = "";
    recImage1 = whiteImage;
    recImage2 = whiteImage;
    ui->pic1->recPath = ui->pic1->whitePath;
    ui->pic2->recPath = ui->pic2->whitePath;
}
