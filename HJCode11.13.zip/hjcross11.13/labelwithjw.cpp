﻿#include "labelwithjw.h"
#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <qDebug>
#include <QRectF>
#include <QPixmap>

LabelWithJW::LabelWithJW(QWidget *parent)
    :QLabel(parent)
    ,isMousePress(false)
{
    isFinishCapture = false;
}

LabelWithJW::LabelWithJW(const QString &text, QWidget *parent, Qt::WindowFlags f):QLabel(text,parent,f)
{

}

LabelWithJW::~LabelWithJW()
{

}

void LabelWithJW::toRepaint()
{
    repaint();
}

void LabelWithJW::paintEvent(QPaintEvent *event)
{
//    QLabel::paintEvent(event);//先调用父类的paintEvent为了显示'背景'!!!

    painter.begin(this);
    painter.setPen(QPen(QColor(45, 114, 152), 1, Qt::SolidLine, Qt::FlatCap));
    painter.drawPixmap(0,0,loadPixmap);
    if(!isShowRec)
    {
//        //qDebug()<<"oops!";
        painter.end();
        return;
    }
//    QPainter painter(this);

    QColor shadowColor = QColor(0, 0, 0, 100);
    painter.fillRect(loadPixmap.rect(), shadowColor);

    if(isMousePress||isFinishCapture)
    {
        QRect selectedRec = getRec().toRect();
        capturePixmap = loadPixmap.copy(selectedRec);
        painter.drawPixmap(selectedRec.topLeft(), capturePixmap);
        painter.drawRect(selectedRec);
    }
    painter.end();
}


void LabelWithJW::showJW()
{
    isShowJW = true;
    this->setMouseTracking(true);
}

void LabelWithJW::cancelShowJW()
{
    isShowJW = false;
    this->setMouseTracking(false);
}

void LabelWithJW::mousePressEvent(QMouseEvent *event)
{
    if(isShowRec == false)//如果增加切片这个功能开启，鼠标点击只能拖动
    {
        dragBeginPoint = event->pos();
        dragEndPoint = dragBeginPoint;
        isDrag = true;
        signalDrag(dragBeginPoint, dragEndPoint, this->width(), 1);
        return;
    }
    if(event->button() == Qt::LeftButton)
    {
        isMousePress = true;
        beginPoint = event->pos();
        endPoint = beginPoint;
    }
}

void LabelWithJW::mouseMoveEvent(QMouseEvent *event)
{
    //QCursor::pos();//获取全局鼠标的位置
    //event->pos();//获取局部鼠标位置
//    //qDebug()<<" event->pos(): "<<event->pos();
//    //qDebug()<<" QCursor::pos()): "<<QCursor::pos();
    if(isShowJW)
    {
        signalMouseMove(event->pos());
    }
    if(isShowRec == false && isDrag == true)//如果增加切片这个功能开启，鼠标点击是拖动效果
    {
        dragEndPoint = event->pos();
        signalDrag(dragBeginPoint, dragEndPoint, this->width(), 0);
        return;
    }
    if(isMousePress)
    {
        endPoint = event->pos();
        update();//拖动时有痕迹
    }
}

void LabelWithJW::mouseReleaseEvent(QMouseEvent *event)
{
    if(isShowRec == false && isDrag == true)
    {
        //qDebug()<<"这是一个鼠标离开时的信号";
        dragEndPoint = event->pos();
        signalDrag(dragBeginPoint, dragEndPoint, this->width(), 2);
        isDrag = false;
        return;
    }
    isFinishCapture = true;
    isMousePress = false;
    isShowRec = false;
    endPoint = event->pos();
    update();
    //qDebug()<<"发出了信号";
    QRectF selectedRec = getRec();
    signalSliceCapture(capturePixmap, selectedRec.topLeft(), selectedRec.bottomRight());
}

QRectF LabelWithJW::getRec()
{
//    qDebug()<<" beginPoint:"<<beginPoint <<"     endPoint:"<< endPoint;
    double x, y, width, height;
    width = qAbs(beginPoint.x() - endPoint.x());
    height = qAbs(beginPoint.y() - endPoint.y());
    x = beginPoint.x() < endPoint.x() ? beginPoint.x() : endPoint.x();
    y = beginPoint.y() < endPoint.y() ? beginPoint.y() : endPoint.y();

    QRectF selectedRect = QRectF(x, y, width, height);
    // 避免宽或高为零时拷贝截图有误;
    if (selectedRect.width() == 0)
    {
        selectedRect.setWidth(1);
    }
    if (selectedRect.height() == 0)
    {
        selectedRect.setHeight(1);
    }
    return selectedRect;
}

void LabelWithJW::wheelEvent(QWheelEvent *event)
{
    if(event->delta()>0)//如果滚轮往上滚
    {
        signalWheelUp();
    }
    else
    {
        signalWheelDown();
    }
}
